import { IObservable, map$$ } from '@lirx/core';
import { createComponent } from '../../../../../component/create/create-component';
import { compileStyleAsComponentStyle } from '../../../../../component/style/compile-style-as-component-style';
import { compileReactiveHTMLAsComponentTemplate } from '../../../../../component/template/compile-reactive-html-as-component-template';
import { ITypedSourcesMapEntry } from '../../../../../misc/typed-sources-map/types/typed-sources-map-entry.type';
import { MatRippleComponent } from '../../buttons/ripple/mat-ripple.component';

// @ts-ignore
import html from './mat-progress-bar.component.html?raw';
// @ts-ignore
import style from './mat-progress-bar.component.scss?inline';

/** SOURCES **/

type ISources = [
  ITypedSourcesMapEntry<'progress', number>,
];

/** DATA **/

interface IData {
  readonly percent$: IObservable<string>;
  readonly percentText$: IObservable<string>;
}

/**
 * COMPONENT: 'mat-progress-bar'
 */

export const MatProgressBarComponent = createComponent<HTMLElement, ISources, IData>({
  name: 'mat-progress-bar',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatRippleComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  sources: [
    ['progress', 0],
  ],
  init: ({ sources }): IData => {
    const progress$ = sources.get$('progress');

    const percent$ = map$$(progress$, (progress: number) => `${progress * 100}%`);
    const percentText$ = map$$(progress$, (progress: number) => `${Math.round(progress * 100)}%`);

    return {
      percent$,
      percentText$,
    };
  },
});
