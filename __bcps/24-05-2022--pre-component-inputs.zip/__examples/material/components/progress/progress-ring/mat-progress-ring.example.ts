import { bootstrap } from '../../../../../component/bootstrap';
import { createProgressAnimation } from '../progress-bar/misc/create-progress-animation';
import { MatProgressRingComponent } from './mat-progress-ring.component';

/** BOOTSTRAP FUNCTION **/

export function matProgressRingExample() {
  const progressRing = bootstrap(MatProgressRingComponent);

  progressRing.sources.set('progress', 0.75);
  progressRing.sources.set('radius', 100);
  progressRing.sources.set('stroke', 20);

  progressRing.setStyleProperty('--mat-progress-ring-color', { value: 'red' });

  createProgressAnimation(progressRing);
}
