import { $log, function$$, IObservable, map$$ } from '@lirx/core';
import { createComponent } from '../../../../../component/create/create-component';
import { compileStyleAsComponentStyle } from '../../../../../component/style/compile-style-as-component-style';
import { compileReactiveHTMLAsComponentTemplate } from '../../../../../component/template/compile-reactive-html-as-component-template';
import { ITypedSourcesMapEntry } from '../../../../../misc/typed-sources-map/types/typed-sources-map-entry.type';
import {
  ISetStyleProperty,
  ISetStylePropertyOrStringOrNull,
} from '../../../../../virtual-node/dom/nodes/static/element/style/style-property.type';
import { MatRippleComponent } from '../../buttons/ripple/mat-ripple.component';

// @ts-ignore
import html from './mat-progress-ring.component.html?raw';
// @ts-ignore
import style from './mat-progress-ring.component.scss?inline';

/** SOURCES **/

type ISources = [
  ITypedSourcesMapEntry<'progress', number>,
  ITypedSourcesMapEntry<'radius', number>,
  ITypedSourcesMapEntry<'stroke', number>,
];

/** DATA **/

interface IData {
  readonly strokeWidth$: IObservable<number>;
  readonly strokeDashOffset$: IObservable<ISetStylePropertyOrStringOrNull>;
  readonly strokeDashArray$: IObservable<string>;
  readonly radius$: IObservable<number>;
  readonly diameter$: IObservable<number>;
  readonly innerRadius$: IObservable<number>;
  readonly transform$: IObservable<string>;
}

// https://css-tricks.com/building-progress-ring-quickly/
// https://css-tricks.com/transforms-on-svg-elements/

/**
 * COMPONENT: 'mat-progress-ring'
 */

export const MatProgressRingComponent = createComponent<HTMLElement, ISources, IData>({
  name: 'mat-progress-ring',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatRippleComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  sources: [
    ['progress', 0],
    ['radius', 0],
    ['stroke', 0],
  ],
  init: ({ sources }): IData => {
    const progress$ = sources.get$('progress');
    const radius$ = sources.get$('radius');
    const stroke$ = sources.get$('stroke');

    /** SETUP SUBSCRIBE FUNCTIONS **/

    const strokeWidth$ = function$$(
      [stroke$, radius$],
      (stroke: number, radius: number): number => {
        return Math.min(stroke, radius);
      },
    );

    const innerRadius$ = function$$(
      [radius$, strokeWidth$],
      (radius: number, stroke: number): number => {
        return Math.max(0, radius - (stroke / 2));
      },
    );

    const circumference$ = map$$(innerRadius$, (radius: number): number => (radius * 2 * Math.PI));

    const strokeDashOffset$ = function$$(
      [circumference$, progress$],
      (circumference: number, progress: number): ISetStylePropertyOrStringOrNull => {
        return (circumference * (1 - progress)).toString(10);
      },
    );

    const strokeDashArray$ = map$$(circumference$, (circumference: number): string => `${circumference} ${circumference}`);

    const diameter$ = map$$(radius$, (radius: number): number => (radius * 2));

    const transform$ = map$$(radius$, (radius: number): string => `rotate(-90 ${radius} ${radius})`);

    return {
      strokeWidth$,
      strokeDashOffset$,
      strokeDashArray$,
      radius$,
      diameter$,
      innerRadius$,
      transform$,
    };
  },
});

