import { IObservable } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate } from '../../../../../component/template/compile-reactive-html-as-component-template';
import { compileStyleAsComponentStyle } from '../../../../../component/style/compile-style-as-component-style';
import { createComponent } from '../../../../../component/create/create-component';
import { ITypedSourcesMapEntry } from '../../../../../misc/typed-sources-map/types/typed-sources-map-entry.type';
import { MatRippleComponent } from '../ripple/mat-ripple.component';

// @ts-ignore
import html from './mat-button.component.html?raw';
// @ts-ignore
import style from './mat-button.component.scss?inline';

/** SOURCES **/

type ISources = [
  ITypedSourcesMapEntry<'disabled', boolean>,
];

/** DATA **/

interface IData {
  readonly disabled$: IObservable<boolean>;
}

/**
 * COMPONENT: 'mat-button'
 */

export const MatButtonComponent = createComponent<HTMLButtonElement, ISources, IData>({
  name: 'mat-button',
  extends: 'button',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatRippleComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  sources: [
    ['disabled', false],
  ],
  init: ({ node, sources }): IData => {
    const disabled$ = sources.get$('disabled');

    node.setReactiveProperty('disabled', disabled$);

    return {
      disabled$,
    };
  },
});
