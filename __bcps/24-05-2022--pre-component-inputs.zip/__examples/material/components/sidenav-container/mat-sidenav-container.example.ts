import { bootstrap } from '../../../../component/bootstrap';
import { MatSidenavContainerComponent } from './mat-sidenav-container.component';

/** BOOTSTRAP FUNCTION **/

export function matSidenavContainerExample() {
  const sidenav = bootstrap(MatSidenavContainerComponent);
}
