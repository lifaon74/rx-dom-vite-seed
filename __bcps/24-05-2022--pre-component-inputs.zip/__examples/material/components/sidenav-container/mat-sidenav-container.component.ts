import { function$$, IObservable, IObserver, map$$ } from '@lirx/core';
import { createComponent } from '../../../../component/create/create-component';
import { compileStyleAsComponentStyle } from '../../../../component/style/compile-style-as-component-style';
import { compileReactiveHTMLAsComponentTemplate } from '../../../../component/template/compile-reactive-html-as-component-template';
import { querySelectorOrThrow } from '../../../../misc/dom/query-selector-or-throw';
import { ITypedSourcesMapEntry } from '../../../../misc/typed-sources-map/types/typed-sources-map-entry.type';
import { MatRippleComponent } from '../buttons/ripple/mat-ripple.component';


// @ts-ignore
import html from './mat-sidenav-container.component.html?raw';
// @ts-ignore
import style from './mat-sidenav-container.component.scss?inline';


/** TYPES **/

// https://material.angular.io/components/sidenav/examples

export type IMatSidenavComponentMode =
  | 'over'
  | 'push'
  ;

export type IMatSidenavComponentPosition =
  | 'start'
  | 'end'
  ;

// export type IMatSidenavComponentUserCloseEvent = CustomEvent<'backdrop' | 'escape'>;
export type IMatSidenavComponentUserCloseType =
  | 'backdrop'
  | 'escape'
  ;


/** SOURCES **/

type ISources = [
  ITypedSourcesMapEntry<'mode', IMatSidenavComponentMode>,
  ITypedSourcesMapEntry<'position', IMatSidenavComponentPosition>,
  ITypedSourcesMapEntry<'hasBackdrop', boolean>,
  ITypedSourcesMapEntry<'enableUserClose', boolean>,
  ITypedSourcesMapEntry<'opened', boolean>,
  // output
  ITypedSourcesMapEntry<'userClose', IMatSidenavComponentUserCloseType>,
];

/** DATA **/

interface IData {
  readonly hasBackdrop$: IObservable<boolean>;
  readonly onClickBackdrop: IObserver<MouseEvent>;
  readonly onClickDrag: IObserver<MouseEvent>;
  readonly onKeyDownSidenav: IObserver<KeyboardEvent>;
}

/**
 * COMPONENT: 'mat-progress-bar'
 */

export const MatSidenavContainerComponent = createComponent<HTMLElement, ISources, IData>({
  name: 'mat-sidenav-container',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatRippleComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  sources: [
    ['mode', 'over'],
    ['position', 'start'],
    ['hasBackdrop', true],
    ['enableUserClose', false],
    ['opened', false],
    ['userClose'],
  ],
  readonlySources: ['userClose'],
  init: ({ node, sources }): IData => {
    const element: HTMLElement = node.elementNode;

    const enableUserClose = () => sources.get('enableUserClose');

    const mode$ = sources.get$('mode');
    const position$ = sources.get$('position');
    const hasBackdrop$ = sources.get$('hasBackdrop');
    const opened$ = sources.get$('opened');
    const $opened = sources.$set('opened');
    const opened = () => sources.get('opened');

    node.setReactiveClass('mat-opened', opened$);
    node.setReactiveClass('mat-has-backdrop', hasBackdrop$);

    const classList$ = function$$(
      [mode$, position$],
      (mode, position) => {
        return new Set([
          `mat-mode-${mode}`,
          `mat-position-${position}`,
        ]);
      },
    );
    node.setReactiveClassNamesList(classList$);


    const onClickBackdrop = (): void => {
      // dispatchCustomEvent(this, 'user-close', 'backdrop');

      if (enableUserClose()) {
        $opened(false);
      }
    };

    const onClickDrag = (): void => {
      $opened(!opened());
    };

    const onKeyDownSidenav = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        // dispatchCustomEvent(this, 'user-close', 'escape');

        if (enableUserClose()) {
          $opened(false);
          // (getActiveElement() as HTMLElement)?.blur?.();
        }
      }
    };

    // TODO improve later
    node.onConnected$(opened$)((opened: boolean): void => {
      if (opened) {
        queueMicrotask(() => {
          querySelectorOrThrow<HTMLElement>(element, `:scope > .sidenav > .content`).focus();
        });
      }
    });

    return {
      hasBackdrop$,

      onClickBackdrop,
      onClickDrag,
      onKeyDownSidenav,
    };
  },
});

