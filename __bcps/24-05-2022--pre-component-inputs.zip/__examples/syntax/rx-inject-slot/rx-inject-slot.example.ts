import { bootstrap } from '../../../component/bootstrap';
import { AppRxInjectSlotExampleAComponent } from './component/rx-inject-slot-example-a.component';


export function rxInjectSlotExample() {
  bootstrap(AppRxInjectSlotExampleAComponent);
}
