import { bootstrap } from '../../../component/bootstrap';
import { AppRxIfExampleComponent } from './component/rx-if-example.component';


export function rxIfExample() {
  bootstrap(AppRxIfExampleComponent);
}
