export function isEmptyString(input: string): boolean {
  return (input === '');
}
