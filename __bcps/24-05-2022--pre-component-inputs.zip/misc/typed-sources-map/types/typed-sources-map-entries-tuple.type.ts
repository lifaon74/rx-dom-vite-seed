import { IGenericTypedSourcesMapEntry } from './typed-sources-map-entry.type';

export type ITypedSourcesMapEntriesTuple = readonly IGenericTypedSourcesMapEntry[];
