import { debug } from './__debug/debug';
import { examples } from './__examples/examples';

function main(): void {
  // debug();
  examples();
}

window.onload = main;

