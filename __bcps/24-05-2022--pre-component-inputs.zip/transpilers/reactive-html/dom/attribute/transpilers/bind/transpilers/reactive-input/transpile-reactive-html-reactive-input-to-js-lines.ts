import { dashCaseToCamelCase } from '../../../../../../../../misc/case-converters/dash-case';
import { ILinesOrNull } from '../../../../../../../misc/lines/lines-or-null.type';
import { IHavingPrimaryTranspilersOptions } from '../../../../../../primary/primary-transpilers.type';
import { IBindProperty } from '../../extract-bind-property-from-reactive-html-attribute';

/**
 * Syntax:
 *  - standard: [input$]
 *  - prefixed: bind-input$
 */

export interface ITranspileReactiveHTMLReactiveInputToJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  bindProperty: IBindProperty;
}

export function transpileReactiveHTMLReactiveInputToJSLines(
  {
    bindProperty,
    transpilers,
  }: ITranspileReactiveHTMLReactiveInputToJSLinesOptions,
): ILinesOrNull {
  if (bindProperty.name.endsWith('$')) {
    const {
      transpileSetReactiveInputToJSLines,
      transpileToObservableToJSLines,
    } = transpilers;

    const name: string = dashCaseToCamelCase(bindProperty.name.slice(0, -1));

    return [
      `// reactive input '${name}'`,
      ...transpileSetReactiveInputToJSLines({
        node: ['node'],
        name: [JSON.stringify(name)],
        value: transpileToObservableToJSLines({ value: [bindProperty.value] }),
      }),
    ];
  } else {
    return null;
  }
}

