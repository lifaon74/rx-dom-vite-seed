import { IObservable, IObserver } from '@lirx/core';
import { HTML_NAMESPACE_URI_CONSTANT } from '../../../../../misc/namespace-uri/html-namespace-uri.constant';
import { ITypedSourcesMap } from '../../../../../misc/typed-sources-map/implementations/typed-sources-map';
import {
  InferTypedSourcesMapEntriesTupleKeys,
} from '../../../../../misc/typed-sources-map/types/infer-typed-sources-map-entries-tuple-keys.infer';
import {
  InferTypedSourcesMapEntriesTupleValueFromKey,
} from '../../../../../misc/typed-sources-map/types/infer-typed-sources-map-entries-tuple-value-from-key.infer';
import {
  ITypedSourcesMapEntriesTupleToKeysTuple
} from '../../../../../misc/typed-sources-map/types/typed-sources-map-entries-tuple-to-keys-tuple.infer';
import { ITypedSourcesMapEntriesTuple } from '../../../../../misc/typed-sources-map/types/typed-sources-map-entries-tuple.type';
import { VirtualReactiveElementNode } from '../element/virtual-reactive-element-node.class';
import { IVirtualCustomElementNodeSlotsMap } from './slots/virtual-custom-element-node-slots-map.type';

export interface IVirtualCustomElementNodeOptions<GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple, > {
  name: string;
  extends?: string;
  slots: IVirtualCustomElementNodeSlotsMap;
  sources: ITypedSourcesMap<GTypedSourcesTuple>;
  // readonlySources: readonly ITypedSourcesMapEntriesTupleToKeysTuple<GTypedSourcesTuple>[];
}

export class VirtualCustomElementNode<// generics
  GElementNode extends HTMLElement,
  GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
  //
  > extends VirtualReactiveElementNode<GElementNode> {

  protected readonly _name: string;
  protected readonly _extends: string | undefined;
  protected readonly _slots: IVirtualCustomElementNodeSlotsMap;
  protected readonly _sources: ITypedSourcesMap<GTypedSourcesTuple>;
  // protected readonly _readonlySources: Set<ITypedSourcesMapEntriesTupleToKeysTuple<GTypedSourcesTuple>>;

  constructor(
    {
      name,
      extends: _extends,
      slots,
      sources,
      // readonlySources,
    }: IVirtualCustomElementNodeOptions<GTypedSourcesTuple>,
  ) {
    super(
      HTML_NAMESPACE_URI_CONSTANT,
      (_extends === void 0)
        ? name
        : _extends,
    );
    this._name = name;
    this._extends = _extends;
    this._slots = slots;
    this._sources = sources;
    // this._readonlySources = new Set<ITypedSourcesMapEntriesTupleToKeysTuple<GTypedSourcesTuple>>(readonlySources);

    if (_extends !== void 0) {
      this.setAttribute('is', name);
    }
  }

  get name(): string {
    return this._name;
  }

  get extends(): string | undefined {
    return this._extends;
  }

  get slots(): IVirtualCustomElementNodeSlotsMap {
    return this._slots;
  }

  get sources(): ITypedSourcesMap<GTypedSourcesTuple> {
    return this._sources;
  }

  /* INPUT / OUTPUT */

  setReactiveInput<GKey extends InferTypedSourcesMapEntriesTupleKeys<GTypedSourcesTuple>>(
    key: GKey,
    value$: IObservable<InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, GKey>>,
  ): void {
    this.onConnected$(value$)(this._sources.$set<GKey>(key));
  }

  setReactiveOutput<GKey extends InferTypedSourcesMapEntriesTupleKeys<GTypedSourcesTuple>>(
    key: GKey,
    $value: IObserver<InferTypedSourcesMapEntriesTupleValueFromKey<GTypedSourcesTuple, GKey>>,
  ): void {
    this.onConnected$(this._sources.get$<GKey>(key))($value);
  }
}

// export type IGenericGenericVirtualCustomElementNode = VirtualCustomElementNode<HTMLElement, ITypedSourcesMapEntriesTuple>;
export type IGenericGenericVirtualCustomElementNode = VirtualCustomElementNode<any, ITypedSourcesMapEntriesTuple>;
