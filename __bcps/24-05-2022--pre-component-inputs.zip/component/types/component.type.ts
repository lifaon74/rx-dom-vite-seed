import { ITypedSourcesMapEntriesTuple } from '../../misc/typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  IVirtualCustomElementNodeSlotsMap,
} from '../../virtual-node/dom/nodes/reactive/custom-element/slots/virtual-custom-element-node-slots-map.type';
import { VirtualCustomElementNode } from '../../virtual-node/dom/nodes/reactive/custom-element/virtual-custom-element-node.class';

// export interface IComponentCreateFunction<GNode extends IGenericGenericVirtualCustomElementNode> {
//   (
//     slots?: IVirtualCustomElementNodeSlotsMap,
//   ): GNode;
// }
//
// export interface IComponent<GNode extends IGenericGenericVirtualCustomElementNode> {
//   readonly name: string;
//   readonly create: IComponentCreateFunction<GNode>;
// }
//
// export type IGenericComponent = IComponent<IGenericGenericVirtualCustomElementNode>;
//

export interface IComponentCreateFunction<// generics
  GElement extends HTMLElement,
  GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
  //
  > {
  (
    slots?: IVirtualCustomElementNodeSlotsMap,
  ): VirtualCustomElementNode<GElement, GTypedSourcesTuple>;
}

export interface IComponent<// generics
  GElement extends HTMLElement,
  GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
  //
  > {
  readonly name: string;
  readonly create: IComponentCreateFunction<GElement, GTypedSourcesTuple>;
}

export type IGenericComponent = IComponent<any, ITypedSourcesMapEntriesTuple>;

