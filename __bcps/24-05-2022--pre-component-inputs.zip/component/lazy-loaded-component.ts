// import { ITypedSourcesMapEntriesTuple } from '../misc/typed-sources-map/types/typed-sources-map-entries-tuple.type';
// import { IComponent, IComponentCreateFunction } from './create-component';

/*
To lazy load a component:

- create a class VirtualLazyLoadedComponent
- all of its inputs are virtual
- when the component is loaded, the inputs are reflected on the component

 */
// export function lazyLoadedComponent<// generics
//   GElement extends HTMLElement,
//   GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
// //
//   >(
//     name: string,
//     load: I
// ): IComponent<GElement, GTypedSourcesTuple> {
//   return {
//     name:
//   }
// }
