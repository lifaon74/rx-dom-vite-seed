import { createTypedSourcesMap } from '../../misc/typed-sources-map/implementations/create-typed-sources-map';
import { ITypedSourcesMap } from '../../misc/typed-sources-map/implementations/typed-sources-map';
import { InferTypedSourcesMapEntriesTupleKeys } from '../../misc/typed-sources-map/types/infer-typed-sources-map-entries-tuple-keys.infer';
import {
  ITypedSourcesMapEntriesTupleToEntriesTuple,
} from '../../misc/typed-sources-map/types/typed-sources-map-entries-tuple-to-entries-tuple.infer';
import {
  ITypedSourcesMapEntriesTupleToKeysTuple,
} from '../../misc/typed-sources-map/types/typed-sources-map-entries-tuple-to-keys-tuple.infer';
import { ITypedSourcesMapEntriesTuple } from '../../misc/typed-sources-map/types/typed-sources-map-entries-tuple.type';
import {
  IVirtualCustomElementNodeSlotsMap,
} from '../../virtual-node/dom/nodes/reactive/custom-element/slots/virtual-custom-element-node-slots-map.type';
import {
  IGenericGenericVirtualCustomElementNode,
  IVirtualCustomElementNodeOptions,
  VirtualCustomElementNode,
} from '../../virtual-node/dom/nodes/reactive/custom-element/virtual-custom-element-node.class';
import { VirtualContainerNode } from '../../virtual-node/dom/nodes/static/container/virtual-container-node.class';
import { VirtualDOMNode } from '../../virtual-node/dom/virtual-dom-node.class';
import { IComponent, IComponentCreateFunction } from '../types/component.type';

/*-------------------*/

export interface IComponentInitFunctionOptions<// generics
  GElement extends HTMLElement,
  GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
  //
  > {
  node: VirtualCustomElementNode<GElement, GTypedSourcesTuple>;
  slots: IVirtualCustomElementNodeSlotsMap;
  sources: ITypedSourcesMap<GTypedSourcesTuple>;
}

export interface IComponentInitFunction<// generics
  GElement extends HTMLElement,
  GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
  GData extends object
  //
  > {
  (
    options: IComponentInitFunctionOptions<GElement, GTypedSourcesTuple>,
  ): GData;
}

export interface IComponentTemplate<GData extends object> {
  (
    parentNode: VirtualDOMNode,
    $: GData,
    slots: IVirtualCustomElementNodeSlotsMap,
  ): void;
}

export interface IComponentStyle {
  (
    node: IGenericGenericVirtualCustomElementNode,
  ): void;
}

export interface ICreateComponentOptions<// generics
  GElement extends HTMLElement,
  GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
  GData extends object
  //
  > extends Pick<IVirtualCustomElementNodeOptions<GTypedSourcesTuple>, 'name' | 'extends'> {
  sources: ITypedSourcesMapEntriesTupleToEntriesTuple<GTypedSourcesTuple>;
  readonlySources?: readonly InferTypedSourcesMapEntriesTupleKeys<GTypedSourcesTuple>[],
  init: IComponentInitFunction<GElement, GTypedSourcesTuple, GData>;
  template?: IComponentTemplate<GData>;
  styles?: readonly IComponentStyle[];
}

export function createComponent<// generics
  GElement extends HTMLElement,
  GTypedSourcesTuple extends ITypedSourcesMapEntriesTuple,
  GData extends object
  //
  >(
  {
    name,
    extends: _extends,
    sources: sourceEntries,
    readonlySources,
    init,
    template,
    styles = [],
  }: ICreateComponentOptions<GElement, GTypedSourcesTuple, GData>,
): IComponent<GElement, GTypedSourcesTuple> {

  const create: IComponentCreateFunction<GElement, GTypedSourcesTuple> = (
    slots: IVirtualCustomElementNodeSlotsMap = new Map(),
  ): VirtualCustomElementNode<GElement, GTypedSourcesTuple> => {

    const sources = createTypedSourcesMap<GTypedSourcesTuple>(
      sourceEntries,
      readonlySources,
    );

    const node = new VirtualCustomElementNode<GElement, GTypedSourcesTuple>({
      name,
      extends: _extends,
      slots,
      sources,
    });

    const $: GData = init({
      node,
      slots,
      sources,
    });

    if (template !== void 0) {
      // template(node, $, slots);
      const container: VirtualContainerNode = new VirtualContainerNode();
      template(container, $, slots);
      container.attach(node); // batch append child nodes to increase performances
    }

    for (let i = 0, l = styles.length; i < l; i++) {
      styles[i](node);
    }

    return node;
  };

  return {
    name,
    create,
  };
}
