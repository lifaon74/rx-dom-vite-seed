import { IObservable } from '@lirx/core';
import { VirtualReactiveTextNode } from '../../virtual-node/dom/nodes/reactive/text/virtual-reactive-text-node.class';

export function createReactiveTextNode(
  value$: IObservable<string>,
): VirtualReactiveTextNode {
  return new VirtualReactiveTextNode(value$);
}

