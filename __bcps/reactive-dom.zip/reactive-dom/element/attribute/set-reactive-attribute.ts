import { IObservable } from '@lirx/core';
import {
  IGenericVirtualReactiveElementNode
} from '../../../virtual-node/dom/nodes/reactive/element/generic-virtual-reactive-element-node.type';
import { IAttributeValue } from '../../../virtual-node/dom/nodes/static/element/attribute/attribute-value.type';

export function setReactiveAttribute(
  element: IGenericVirtualReactiveElementNode,
  name: string,
  value$: IObservable<IAttributeValue>,
): void {
  element.setReactiveAttribute(name, value$);
}

