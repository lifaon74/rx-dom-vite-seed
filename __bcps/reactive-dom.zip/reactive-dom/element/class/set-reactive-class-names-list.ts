import { IObservable } from '@lirx/core';
import { IClassNamesList } from '../../../virtual-node/dom/nodes/reactive/element/class/class-names-list.type';

import {
  IGenericVirtualReactiveElementNode
} from '../../../virtual-node/dom/nodes/reactive/element/generic-virtual-reactive-element-node.type';



export function setReactiveClassNamesList(
  element: IGenericVirtualReactiveElementNode,
  classNamesList$: IObservable<IClassNamesList>,
): void {
  element.setReactiveClassNamesList(classNamesList$);
}

