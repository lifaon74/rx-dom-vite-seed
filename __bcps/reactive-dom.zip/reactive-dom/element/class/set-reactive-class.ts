import { IObservable } from '@lirx/core';
import {
  IGenericVirtualReactiveElementNode
} from '../../../virtual-node/dom/nodes/reactive/element/generic-virtual-reactive-element-node.type';

export function setReactiveClass(
  element: IGenericVirtualReactiveElementNode,
  name: string,
  enabled$: IObservable<boolean>,
): void {
  element.setReactiveClass(name, enabled$);
}

