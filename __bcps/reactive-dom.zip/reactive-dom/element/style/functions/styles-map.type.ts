import { IStylePropertyObjectWithOptionalPriorityOrNull } from '../../../../light-dom/style/types/style-property-object.type';

export type IStylesMap = Map<string, IStylePropertyObjectWithOptionalPriorityOrNull>;

