export const HTML_NAMESPACE_URI_CONSTANT = 'http://www.w3.org/1999/xhtml';
