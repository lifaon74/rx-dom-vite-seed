export const SVG_NAMESPACE_URI_CONSTANT = 'http://www.w3.org/2000/svg';
