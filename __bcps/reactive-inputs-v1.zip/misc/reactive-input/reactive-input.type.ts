export type IReactiveInput<GName extends string, GValue> = [
  name: GName,
  value: GValue,
];

export type IGenericReactiveInput = IReactiveInput<string, any>;

