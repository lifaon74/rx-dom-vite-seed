import { IObservable, IObserver, ISource, let$$, readObservableValue } from '@lirx/core';
import { InferReactiveInputsMapKeys } from './infer-reactive-inputs-map-keys.infer';
import { InferReactiveInputsMapValueFromKey } from './infer-reactive-inputs-map-value-from-key.infer';
import { IGenericReactiveInput } from './reactive-input.type';
import { IReactiveInputsTupleToKeysTuple } from './reactive-inputs-tuple-to-keys-tuple.infer';
import { IReactiveInputsTuple } from './reactive-inputs-tuple.type';

export class ReactiveInputsMap<GReactiveInputsTuple extends IReactiveInputsTuple> {

  static create<GReactiveInputsTuple extends IReactiveInputsTuple>(
    inputs: IReactiveInputsTupleToKeysTuple<GReactiveInputsTuple>,
  ): ReactiveInputsMap<GReactiveInputsTuple> {
    return new ReactiveInputsMap<GReactiveInputsTuple>(
      inputs.map((name: string): IGenericReactiveInput => {
        return [
          name,
          let$$<unknown>(),
        ];
      }) as unknown as GReactiveInputsTuple,
    );
  }

  protected readonly _map: ReadonlyMap<string, ISource<any>>;

  constructor(
    entries: GReactiveInputsTuple,
  ) {
    this._map = new Map(entries);
  }

  has(
    key: string,
  ): key is InferReactiveInputsMapKeys<GReactiveInputsTuple> {
    return this._map.has(key);
  }

  input<GKey extends InferReactiveInputsMapKeys<GReactiveInputsTuple>>(
    key: GKey,
  ): ISource<InferReactiveInputsMapValueFromKey<GReactiveInputsTuple, GKey>> {
    return this._map.get(key)!;
  }

  get$<GKey extends InferReactiveInputsMapKeys<GReactiveInputsTuple>>(
    key: GKey,
  ): IObservable<InferReactiveInputsMapValueFromKey<GReactiveInputsTuple, GKey>> {
    return this.input(key).subscribe;
  }

  get<GKey extends InferReactiveInputsMapKeys<GReactiveInputsTuple>>(
    key: GKey,
  ): InferReactiveInputsMapValueFromKey<GReactiveInputsTuple, GKey> {
    return readObservableValue(this.get$(key), (): never => {
      throw new Error(`Unable to read input: ${key}`);
    });
  }

  $set<GKey extends InferReactiveInputsMapKeys<GReactiveInputsTuple>>(
    key: GKey,
  ): IObserver<InferReactiveInputsMapValueFromKey<GReactiveInputsTuple, GKey>> {
    return this.input(key).emit;
  }

  set<GKey extends InferReactiveInputsMapKeys<GReactiveInputsTuple>>(
    key: GKey,
    value: InferReactiveInputsMapValueFromKey<GReactiveInputsTuple, GKey>,
  ): void {
    this.$set<GKey>(key)(value);
  }
}
