import { IGenericReactiveInput } from './reactive-input.type';

export type IReactiveInputsTuple = readonly IGenericReactiveInput[];
