import { InferReactiveInputsMapKeys } from './infer-reactive-inputs-map-keys.infer';
import { IReactiveInput } from './reactive-input.type';
import { IReactiveInputsTuple } from './reactive-inputs-tuple.type';

export type InferReactiveInputsMapValueFromKey<// generics
  GReactiveInputsTuple extends IReactiveInputsTuple,
  GKey extends InferReactiveInputsMapKeys<GReactiveInputsTuple>
  //
  > = {
  [Key in keyof GReactiveInputsTuple]: GReactiveInputsTuple[Key] extends IReactiveInput<GKey, infer GValue>
    ? GValue
    : never;
}[number];
