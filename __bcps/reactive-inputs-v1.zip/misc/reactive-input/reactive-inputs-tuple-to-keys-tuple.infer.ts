import { IReactiveInput } from './reactive-input.type';
import { IReactiveInputsTuple } from './reactive-inputs-tuple.type';

export type IReactiveInputsTupleToKeysTuple<GReactiveInputsTuple extends IReactiveInputsTuple> = {
  [Key in keyof GReactiveInputsTuple]: GReactiveInputsTuple[Key] extends IReactiveInput<infer GKey, any>
    ? GKey
    : never;
};
