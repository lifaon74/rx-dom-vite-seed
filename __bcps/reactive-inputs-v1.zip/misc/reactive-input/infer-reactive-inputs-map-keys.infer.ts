import { IReactiveInputsTupleToKeysTuple } from './reactive-inputs-tuple-to-keys-tuple.infer';
import { IReactiveInputsTuple } from './reactive-inputs-tuple.type';

export type InferReactiveInputsMapKeys<GReactiveInputsTuple extends IReactiveInputsTuple> = IReactiveInputsTupleToKeysTuple<GReactiveInputsTuple>[number];
