import { IObservable } from '../../../../../../../lirx/core/dist';
import { HTML_NAMESPACE_URI_CONSTANT } from '../../../../../misc/namespace-uri/html-namespace-uri.constant';
import { InferReactiveInputsMapKeys } from '../../../../../misc/reactive-input/infer-reactive-inputs-map-keys.infer';
import { InferReactiveInputsMapValueFromKey } from '../../../../../misc/reactive-input/infer-reactive-inputs-map-value-from-key.infer';
import { ReactiveInputsMap } from '../../../../../misc/reactive-input/reactive-inputs-map.class';
import { IReactiveInputsTuple } from '../../../../../misc/reactive-input/reactive-inputs-tuple.type';
import { IVirtualDOMNodeTemplate } from '../../../types/virtual-dom-node-template.type';
import { VirtualReactiveElementNode } from '../element/virtual-reactive-element-node.class';

/*----------------*/

export type InferVirtualCustomElementNodeGetInputKeys<// generics
  GElementNode extends HTMLElement,
  GReactiveInputsTuple extends IReactiveInputsTuple,
//
  > =
  | InferReactiveInputsMapKeys<GReactiveInputsTuple>
  | keyof GElementNode
  ;

export type InferVirtualCustomElementNodeGetInputValueFromKey<// generics
  GElementNode extends HTMLElement,
  GReactiveInputsTuple extends IReactiveInputsTuple,
  GKey extends InferVirtualCustomElementNodeGetInputKeys<GElementNode, GReactiveInputsTuple>
//
  > =
  GKey extends InferReactiveInputsMapKeys<GReactiveInputsTuple>
    ? InferReactiveInputsMapValueFromKey<GReactiveInputsTuple, GKey>
    : (
      GKey extends keyof GElementNode
        ? GElementNode[GKey]
        : never
      )
  ;

/*----------------*/

export type IVirtualCustomElementNodeSlotTemplate = IVirtualDOMNodeTemplate<[]>; // IGenericVirtualReactiveDOMNodeTemplate

export type IVirtualCustomElementNodeSlotsMap = ReadonlyMap<string | '*', IVirtualCustomElementNodeSlotTemplate>

export interface IVirtualCustomElementNodeOptions<GReactiveInputsTuple extends IReactiveInputsTuple, > {
  name: string;
  parentName?: string;
  slots: IVirtualCustomElementNodeSlotsMap;
  inputs: ReactiveInputsMap<GReactiveInputsTuple>;
}

export class VirtualCustomElementNode<// generics
  GElementNode extends HTMLElement,
  GReactiveInputsTuple extends IReactiveInputsTuple,
  //
  > extends VirtualReactiveElementNode<GElementNode> {

  protected readonly _name: string;
  protected readonly _parentName: string | undefined;
  protected readonly _slots: IVirtualCustomElementNodeSlotsMap;
  protected readonly _inputs: ReactiveInputsMap<GReactiveInputsTuple>;

  constructor(
    {
      name,
      parentName,
      slots,
      inputs,
    }: IVirtualCustomElementNodeOptions<GReactiveInputsTuple>,
  ) {
    super(
      HTML_NAMESPACE_URI_CONSTANT,
      (parentName === void 0)
        ? name
        : parentName,
    );
    this._name = name;
    this._parentName = parentName;
    this._slots = slots;
    this._inputs = inputs;

    if (parentName !== void 0) {
      this.setAttribute('is', name);
    }
  }

  get name(): string {
    return this._name;
  }

  get parentName(): string | undefined {
    return this._parentName;
  }

  get slots(): IVirtualCustomElementNodeSlotsMap {
    return this._slots;
  }

  get inputs(): ReactiveInputsMap<GReactiveInputsTuple> {
    return this._inputs;
  }

  /* INPUT */

  getInput<GKey extends InferVirtualCustomElementNodeGetInputKeys<GElementNode, GReactiveInputsTuple>>(
    key: GKey,
  ): InferVirtualCustomElementNodeGetInputValueFromKey<GElementNode, GReactiveInputsTuple, GKey> {
    if (this._inputs.has(key as string)) {
      return this._inputs.get(key as InferReactiveInputsMapKeys<GReactiveInputsTuple>) as InferVirtualCustomElementNodeGetInputValueFromKey<GElementNode, GReactiveInputsTuple, GKey>;
    } else {
      return this.getProperty(key as keyof GElementNode) as InferVirtualCustomElementNodeGetInputValueFromKey<GElementNode, GReactiveInputsTuple, GKey>;
    }
  }

  setInput<GKey extends InferVirtualCustomElementNodeGetInputKeys<GElementNode, GReactiveInputsTuple>>(
    key: GKey,
    value: InferVirtualCustomElementNodeGetInputValueFromKey<GElementNode, GReactiveInputsTuple, GKey>,
  ): void {
    if (this._inputs.has(key as string)) {
      this._inputs.set(key as InferReactiveInputsMapKeys<GReactiveInputsTuple>, value as any);
    } else {
      this.setProperty(key as keyof GElementNode, value as any);
    }
  }

  setReactiveInput<GKey extends InferVirtualCustomElementNodeGetInputKeys<GElementNode, GReactiveInputsTuple>>(
    key: GKey,
    value$: IObservable<InferVirtualCustomElementNodeGetInputValueFromKey<GElementNode, GReactiveInputsTuple, GKey>>,
  ): void {
    this.onConnected$(value$)((value: InferVirtualCustomElementNodeGetInputValueFromKey<GElementNode, GReactiveInputsTuple, GKey>): void => {
      this.setInput<GKey>(key, value);
    });
  }
}


