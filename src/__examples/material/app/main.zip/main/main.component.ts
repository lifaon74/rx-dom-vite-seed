import { distinct$$, fromEventTarget, IObservable, IObserver, let$$, map$$, merge, not$$, reference, throttleTime$$ } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  VirtualComponentNode,
  Component,
} from '@lirx/dom';
import { IconMenuComponent } from '@lirx/mdi';
import {
  IMatSidenavComponentMode,
  IMatSidenavComponentUserCloseType,
  MatButtonModifier,
  MatIconButtonModifier,
  MatSidenavContainerComponent,
  MatToolbarComponent,
  MatToolbarContainerComponent,
  MatMenuComponent,
  MatMenuItemModifier,
  MatNavListComponent, MatNavListItemModifier,
} from '@lirx/dom-material';
import { IUnsubscribe } from '@lirx/unsubscribe';
import { VirtualLinkComponent } from '@lirx/router';

// @ts-ignore
import html from './main.component.html?raw';
// @ts-ignore
import style from './main.component.scss?inline';

/**
 * COMPONENT: 'app-main'
 */

interface ITemplateData {
  readonly sidenavOpened$: IObservable<boolean>;
  readonly sidenavMode$: IObservable<IMatSidenavComponentMode>;
  readonly sidenavHasBackdrop$: IObservable<boolean>;
  readonly menuButtonVisible$: IObservable<boolean>;
  readonly onUserCloseSidenav: IObserver<IMatSidenavComponentUserCloseType>;
  readonly onClickMenuButton: IObserver<MouseEvent>;
}

export const AppMainComponent = new Component<HTMLElement, object, ITemplateData>({
  name: 'app-main',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    components: [
      MatSidenavContainerComponent,
      MatToolbarContainerComponent,
      MatToolbarComponent,
      IconMenuComponent,
      MatNavListComponent,
      VirtualLinkComponent,
    ],
    modifiers: [
      MatButtonModifier,
      MatIconButtonModifier,
      MatNavListItemModifier,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  templateData: (node: VirtualComponentNode<HTMLElement, object>): ITemplateData => {
    const windowSize$ = throttleTime$$(fromEventTarget(window, 'resize'), 100);

    // TODO use createWindowSizeObservableInitialized ?
    const isLargeWindow = () => (window.innerWidth > 950);
    // const isLargeWindow = () => (window.innerWidth > 0);
    const isLargeWindow$ = distinct$$(
      merge([
        reference(isLargeWindow),
        map$$(windowSize$, isLargeWindow),
      ]),
    );

    const [
      $sidenavOpened,
      sidenavOpened$,
      getSidenavOpened,
    ] = let$$(false);

    const onUserCloseSidenav = (): void => {
      $sidenavOpened(false);
    };

    const onClickMenuButton = (): void => {
      $sidenavOpened(!getSidenavOpened());
    };

    node.onConnected((): IUnsubscribe => {
      return isLargeWindow$($sidenavOpened);
    });

    const sidenavMode$ = map$$(isLargeWindow$, (isLargeWindow: boolean): IMatSidenavComponentMode => {
      return isLargeWindow
        ? 'push'
        : 'over';
    });

    const sidenavHasBackdrop$ = not$$(isLargeWindow$);

    const menuButtonVisible$ = not$$(isLargeWindow$);

    return {
      sidenavOpened$,
      sidenavMode$,
      sidenavHasBackdrop$,
      menuButtonVisible$,

      onUserCloseSidenav,
      onClickMenuButton,
    };
  },
});

