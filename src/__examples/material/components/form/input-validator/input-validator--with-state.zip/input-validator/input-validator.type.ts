import { IInputValidatorResult } from './result/input-validator-result.type';

export interface IInputValidator {
  (
    value: string,
  ): IInputValidatorResult;
}

