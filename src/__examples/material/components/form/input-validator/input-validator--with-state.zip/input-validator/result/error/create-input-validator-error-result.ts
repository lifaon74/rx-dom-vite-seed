import { IInputValidatorErrorResult } from './input-validator-error-result.type';

export function createInputValidatorErrorResult(
  messages: (readonly string[] | string),
): IInputValidatorErrorResult {
  if (typeof messages === 'string') {
    messages = [
      messages,
    ];
  }
  return {
    state: 'error',
    messages,
  };
}
