import { IInputValidatorValidResult } from './input-validator-valid-result.type';

export const INPUT_VALIDATOR_VALID_RESULT: IInputValidatorValidResult = Object.freeze({
  state: 'valid',
});
