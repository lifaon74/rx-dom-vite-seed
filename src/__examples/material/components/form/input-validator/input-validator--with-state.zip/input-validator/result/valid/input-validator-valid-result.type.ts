export interface IInputValidatorValidResult {
  readonly state: 'valid';
}
