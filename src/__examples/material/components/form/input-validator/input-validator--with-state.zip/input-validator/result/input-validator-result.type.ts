import { IInputValidatorErrorResult } from './error/input-validator-error-result.type';
import { IInputValidatorValidResult } from './valid/input-validator-valid-result.type';

export type IInputValidatorResult =
  | IInputValidatorValidResult
  | IInputValidatorErrorResult
  ;

