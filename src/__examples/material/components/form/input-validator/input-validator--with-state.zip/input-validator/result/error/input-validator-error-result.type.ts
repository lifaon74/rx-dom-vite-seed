export interface IInputValidatorErrorResult {
  readonly state: 'error';
  readonly messages: readonly string[];
}
