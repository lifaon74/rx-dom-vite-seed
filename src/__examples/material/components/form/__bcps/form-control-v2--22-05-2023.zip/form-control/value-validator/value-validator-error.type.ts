export interface IValueValidatorError {
  readonly code: string;
  readonly message: string;
}

export type IValueValidatorErrorList = IValueValidatorError[];

export interface IValueValidatorErrorGenerator<GValue, GArgs extends any[] = []> {
  (
    value: GValue,
    ...args: GArgs
  ): IValueValidatorError;
}

