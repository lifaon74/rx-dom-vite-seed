import { createSyncValueValidator } from '../../create-sync-value-validator';
import { IValueValidatorError, IValueValidatorErrorGenerator } from '../../value-validator-error.type';
import { ValueValidator } from '../../value-validator.class';
import { EMAIL_PATTERN } from './patterns/email-pattern.constant';

export const DEFAULT_STRING_VALIDATOR_NOT_EMPTY_ERROR_GENERATOR: IValueValidatorErrorGenerator<string> = (): IValueValidatorError => {
  return {
    code: 'empty-string',
    message: `Must not be an empty string`,
  };
};

export const DEFAULT_STRING_VALIDATOR_PATTERN_ERROR_GENERATOR: IValueValidatorErrorGenerator<string, [RegExp]> = (
  value: string,
  pattern: RegExp,
): IValueValidatorError => {
  return {
    code: 'mismatch-pattern',
    message: `The string doesn't match the pattern: /${pattern.source}/${pattern.flags}`,
  };
};

export const DEFAULT_STRING_VALIDATOR_EMAIL_ERROR_GENERATOR: IValueValidatorErrorGenerator<string, [RegExp]> = (): IValueValidatorError => {
  return {
    code: 'mismatch-pattern',
    message: `Not an email`,
  };
};

export class StringValidator extends ValueValidator<string> {

  static notEmpty(
    error: IValueValidatorErrorGenerator<string> = DEFAULT_STRING_VALIDATOR_NOT_EMPTY_ERROR_GENERATOR,
  ): StringValidator {
    return new StringValidator(
      createSyncValueValidator<string>(
        (value: string) => (value !== ''),
        error,
      ),
    );
  }

  static pattern(
    pattern: RegExp,
    error: IValueValidatorErrorGenerator<string, [RegExp]> = DEFAULT_STRING_VALIDATOR_PATTERN_ERROR_GENERATOR,
  ): StringValidator {
    return new StringValidator(
      createSyncValueValidator<string, [RegExp]>(
        (value: string) => pattern.test(value),
        error,
        [pattern],
      ),
    );
  }

  static email(
    error: IValueValidatorErrorGenerator<string, [RegExp]> = DEFAULT_STRING_VALIDATOR_EMAIL_ERROR_GENERATOR,
  ): StringValidator {
    return this.pattern(EMAIL_PATTERN, error);
  }
}
