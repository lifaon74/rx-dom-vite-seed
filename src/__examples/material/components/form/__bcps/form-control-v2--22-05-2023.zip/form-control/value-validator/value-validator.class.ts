import { Abortable, AsyncTask, IAsyncTaskFactory, IAsyncTaskInput } from '@lirx/async-task';
import { INullish, isNullish } from '@lirx/utils';
import { StringValidator } from './built-in/string/string-validator.class';
import { createSyncValueValidator } from './create-sync-value-validator';
import { IValueValidatorError, IValueValidatorErrorGenerator, IValueValidatorErrorList } from './value-validator-error.type';
import { IValueValidatorInput } from './value-validator-input.type';

export const DEFAULT_VALUE_VALIDATOR_REQUIRED_ERROR_GENERATOR: IValueValidatorErrorGenerator<unknown> = (): IValueValidatorError => {
  return {
    code: 'required',
    message: `Value is required`,
  };
};

export class ValueValidator<GValue> {
  static none<GValue>(): ValueValidator<GValue> {
    return new ValueValidator<GValue>(() => []);
  }

  static subType<GValue, GSubValue extends GValue>(
    isSubType: (value: GValue) => value is GSubValue,
    validator: ValueValidator<GSubValue>,
  ): ValueValidator<GValue> {
    return new ValueValidator<GValue>((
      value: GValue,
      abortable: Abortable,
    ): AsyncTask<IValueValidatorErrorList> => {
      return isSubType(value)
       ? 
      return this.validate(value, abortable)
        .successful((errors: IValueValidatorErrorList, abortable: Abortable): IValueValidatorErrorList | AsyncTask<IValueValidatorErrorList> => {
          return (errors.length === 0)
            ? validator.validate(value as GSubValue, abortable)
            : errors;
        });
    });
  }

  // static optional<GValue>(): ValueValidator<GValue | INullish> {
  //   return new ValueValidator<GValue | INullish>(((
  //     value: GValue | INullish,
  //     abortable: Abortable,
  //   ): AsyncTask<IValueValidatorErrorList> | IValueValidatorErrorList => {
  //     return isNullish(value)
  //       ? []
  //       : this.validate(value, abortable)
  //   }) as IValueValidatorInput<GValue | INullish>);
  // }

  static required<GValue>(
    error: IValueValidatorErrorGenerator<GValue | INullish> = DEFAULT_VALUE_VALIDATOR_REQUIRED_ERROR_GENERATOR,
  ): ValueValidator<GValue | INullish> {
    return new ValueValidator<GValue | INullish>(
      createSyncValueValidator<GValue | INullish>(
        (value: GValue | INullish) => !isNullish(value),
        error,
      ),
    );
  }

  // static not<GValue>(
  //   validator: ValueValidator<GValue>,
  // ): ValueValidator<GValue> {
  //   return new ValueValidator<GValue>((
  //     value: GValue,
  //     abortable: Abortable,
  //   ): AsyncTask<IValueValidatorErrorList> => {
  //     return validator.validate(value, abortable)
  //       .successful((errors: IValueValidatorErrorList): IValueValidatorErrorList => {
  //         return (errors.length === 0)
  //           ? [
  //             {
  //               code: 'not',
  //               message: '',
  //             },
  //           ]
  //           : [];
  //       });
  //   });
  // }

  // static or<GValue>(
  //   ...validators: readonly ValueValidator<GValue>[]
  // ): ValueValidator<GValue> {
  //   return new ValueValidator<GValue>((
  //     value: GValue,
  //     abortable: Abortable,
  //   ): AsyncTask<IValueValidatorErrorList> => {
  //     const loop = (
  //       index: number,
  //       abortable: Abortable,
  //       allErrors: IValueValidatorErrorList,
  //     ): AsyncTask<IValueValidatorErrorList> => {
  //       return (index < validators.length)
  //         ? validators[index].validate(value, abortable)
  //           .successful((errors: IValueValidatorErrorList): IValueValidatorErrorList | AsyncTask<IValueValidatorErrorList> => {
  //             return (errors.length === 0)
  //               ? []
  //               : loop(index + 1, abortable, [...allErrors, ...errors]);
  //           })
  //         : AsyncTask.success<IValueValidatorErrorList>([], abortable);
  //     };
  //
  //     return loop(0, abortable, []);
  //   });
  // }

  static sequence<GValue>(
    ...validators: readonly ValueValidator<GValue>[]
  ): ValueValidator<GValue> {
    return new ValueValidator<GValue>((
      value: GValue,
      abortable: Abortable,
    ): AsyncTask<IValueValidatorErrorList> => {
      const loop = (
        index: number,
        abortable: Abortable,
      ): AsyncTask<IValueValidatorErrorList> => {
        return (index < validators.length)
          ? validators[index].validate(value, abortable)
            .successful((errors: IValueValidatorErrorList): IValueValidatorErrorList | AsyncTask<IValueValidatorErrorList> => {
              return (errors.length === 0)
                ? loop(index + 1, abortable)
                : errors;
            })
          : AsyncTask.success<IValueValidatorErrorList>([], abortable);
      };

      return loop(0, abortable);
    });
  }

  // static group<GValue>(
  //   validators: readonly ValueValidator<GValue>[],
  // ): ValueValidator<GValue> {
  //   return new ValueValidator<GValue>((
  //     value: GValue,
  //     abortable: Abortable,
  //   ): AsyncTask<IValueValidatorErrorList> => {
  //     return AsyncTask.all(
  //       validators.map((validator: ValueValidator<GValue>): IAsyncTaskFactory<IValueValidatorErrorList> => {
  //         return (abortable: Abortable): IAsyncTaskInput<IValueValidatorErrorList> => {
  //           return validator.validate(value, abortable);
  //         };
  //       }),
  //       abortable,
  //     )
  //       .successful((errors: IValueValidatorErrorList[]): IValueValidatorErrorList => {
  //         return errors.flat();
  //       });
  //   });
  // }

  protected readonly _validator: IValueValidatorInput<GValue>;

  constructor(
    validator: IValueValidatorInput<GValue>,
  ) {
    this._validator = validator;
  }

  validate(
    value: GValue,
    abortable: Abortable = Abortable.never,
  ): AsyncTask<IValueValidatorErrorList> {
    return AsyncTask.fromFactory<IValueValidatorErrorList>((abortable: Abortable): IAsyncTaskInput<IValueValidatorErrorList> => {
      return this._validator(value, abortable);
    }, abortable);
  }

  child<GChildValue extends GValue>(
    validator: ValueValidator<GChildValue>,
  ): ValueValidator<GValue> {
    return new ValueValidator<GValue>((
      value: GValue,
      abortable: Abortable,
    ): AsyncTask<IValueValidatorErrorList> => {
      return this.validate(value, abortable)
        .successful((errors: IValueValidatorErrorList, abortable: Abortable): IValueValidatorErrorList | AsyncTask<IValueValidatorErrorList> => {
          return (errors.length === 0)
            ? validator.validate(value as GChildValue, abortable)
            : errors;
        });
    });
  }

  // required(
  //   error: IValueValidatorErrorGenerator<GValue | INullish> = DEFAULT_VALUE_VALIDATOR_REQUIRED_ERROR_GENERATOR,
  // ): ValueValidator<GValue | INullish> {
  //   return new ValueValidator<GValue | INullish>(((
  //     value: GValue | INullish,
  //     abortable: Abortable,
  //   ): AsyncTask<IValueValidatorErrorList> | IValueValidatorErrorList => {
  //     return isNullish(value)
  //       ? [error(value)]
  //       : this.validate(value, abortable);
  //   }) as IValueValidatorInput<GValue | INullish>);
  // }
}

