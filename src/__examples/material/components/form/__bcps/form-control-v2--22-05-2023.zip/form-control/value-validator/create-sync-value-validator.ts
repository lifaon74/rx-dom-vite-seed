import { IValueValidatorErrorGenerator, IValueValidatorErrorList } from './value-validator-error.type';
import { ISyncValueValidator } from './value-validator-input.type';

export function createSyncValueValidator<GValue>(
  isValueValid: (value: GValue) => boolean,
  error: IValueValidatorErrorGenerator<GValue, []>,
): ISyncValueValidator<GValue>;
export function createSyncValueValidator<GValue, GArgs extends any[]>(
  isValueValid: (value: GValue) => boolean,
  error: IValueValidatorErrorGenerator<GValue, GArgs>,
  args: GArgs,
): ISyncValueValidator<GValue>;
export function createSyncValueValidator<GValue, GArgs extends any[]>(
  isValueValid: (value: GValue) => boolean,
  error: IValueValidatorErrorGenerator<GValue, GArgs>,
  args: GArgs = [] as any,
): ISyncValueValidator<GValue> {
  return (value: GValue): IValueValidatorErrorList => {
    return isValueValid(value)
      ? []
      : [error(value, ...args)];
  };
}
