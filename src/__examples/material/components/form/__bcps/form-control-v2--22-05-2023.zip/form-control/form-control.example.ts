import { Abortable, AsyncTask } from '@lirx/async-task';
import {
  combineLatest,
  createMulticastReplayLastSource,
  fromPromiseFactory,
  IMulticastReplayLastSource,
  IObservable,
  IObserver,
  map$$,
  MAP_FILTER_DISCARD,
  mapFilter$$,
  shareRL$$,
  switchMap$$,
} from '@lirx/core';
import {
  IFromPromiseFactoryObservableNotifications,
} from '@lirx/core/src/observable/built-in/from/with-notifications/promise/from-promise-factory/from-promise-factory-observable-notifications.type';
import { IMapFilterMapFunctionReturn } from '@lirx/core/src/observer/pipes/built-in/map-filter/map-filter-map-function.type';
import { StringValidator } from './value-validator/built-in/string/string-validator.class';
import { IValueValidatorErrorList } from './value-validator/value-validator-error.type';
import { ValueValidator } from './value-validator/value-validator.class';

/** FORM INPUT **/

export interface IFormInputOptions<GValue> {
  value?: GValue | null;
  disabled?: boolean;
  required?: boolean;
  validator?: ValueValidator<GValue | null>;
}

export abstract class FormInput<GName extends string, GValue> {
  protected readonly _name: GName;

  protected readonly _$value$: IMulticastReplayLastSource<GValue | null>;
  protected readonly _$disabled$: IMulticastReplayLastSource<boolean>;
  protected readonly _$required$: IMulticastReplayLastSource<boolean>;

  protected readonly _validator: ValueValidator<GValue | null> | undefined;
  protected readonly _validity$: IObservable<IValueValidatorErrorList>;

  protected constructor(
    name: GName,
    {
      value = null,
      disabled = false,
      required = false,
      validator,
    }: IFormInputOptions<GValue> = {},
  ) {
    this._name = name;

    this._$value$ = createMulticastReplayLastSource<GValue | null>(value);
    this._$disabled$ = createMulticastReplayLastSource<boolean>(disabled);
    this._$required$ = createMulticastReplayLastSource<boolean>(required);

    this._validator = validator;

    const validator$ = map$$(
      combineLatest([this.disabled$, this.required$]),
      () => this.validator,
    );

    this._validity$ = shareRL$$<IValueValidatorErrorList>(
      switchMap$$(validator$, (validator: ValueValidator<GValue | null>): IObservable<IValueValidatorErrorList> => {
        return switchMap$$(this.value$, (value: GValue | null): IObservable<IValueValidatorErrorList> => {
          return mapFilter$$<IFromPromiseFactoryObservableNotifications<IValueValidatorErrorList>, IValueValidatorErrorList>(
            fromPromiseFactory<IValueValidatorErrorList>((signal: AbortSignal) => {
              return validator.validate(value, Abortable.fromAbortSignal(signal)).toPromise();
            }),
            (notification: IFromPromiseFactoryObservableNotifications<IValueValidatorErrorList>): IMapFilterMapFunctionReturn<IValueValidatorErrorList> => {
              switch (notification.name) {
                case 'next':
                  return notification.value;
                case 'error':
                  return [
                    {
                      code: 'unknown',
                      message: notification.value.message ?? '',
                    },
                  ];
                default:
                  return MAP_FILTER_DISCARD;
              }
            },
          );
        });
      }),
    );
  }

  /* NAME */

  get name(): GName {
    return this._name;
  }

  /* VALUE */

  get value(): GValue | null {
    return this._$value$.getValue();
  }

  set value(
    input: GValue | null,
  ) {
    this._$value$.emit(input);
  }

  get value$(): IObservable<GValue | null> {
    return this._$value$.subscribe;
  }

  get $value(): IObserver<GValue | null> {
    return this._$value$.emit;
  }

  /* DISABLED */

  get disabled(): boolean {
    return this._$disabled$.getValue();
  }

  set disabled(
    input: boolean,
  ) {
    this._$disabled$.emit(input);
  }

  get disabled$(): IObservable<boolean> {
    return this._$disabled$.subscribe;
  }

  get $disabled(): IObserver<boolean> {
    return this._$disabled$.emit;
  }

  /* REQUIRED */

  get required(): boolean {
    return this._$required$.getValue();
  }

  set required(
    input: boolean,
  ) {
    this._$required$.emit(input);
  }

  get required$(): IObservable<boolean> {
    return this._$required$.subscribe;
  }

  get $required(): IObserver<boolean> {
    return this._$required$.emit;
  }

  /* VALIDITY */

  get validity$(): IObservable<IValueValidatorErrorList> {
    return this._validity$;
  }

  get isValid$(): IObservable<boolean> {
    return map$$(this._validity$, (errors: IValueValidatorErrorList) => errors.length === 0);
  }

  get validator(): ValueValidator<GValue | null> {
    return this.disabled
      ? ValueValidator.none<GValue | null>()
      : (
        (this._validator === void 0)
          ? (
            this.required
              ? ValueValidator.required<GValue>()
              : ValueValidator.none<GValue | null>()
          )
          : (
            this.required
              ? ValueValidator.required<GValue>()
                .child(this._validator)
              : this._validator
          )

      );
  }

  validate(
    abortable?: Abortable,
  ): AsyncTask<IValueValidatorErrorList> {
    return this.validator.validate(this.value, abortable);
  }

  /* METHODS */

  reset(): void {
    this.value = null;
  }
}

export type IGenericFormInput = FormInput<string, any>;

/*---*/

export type IGenericFormGroupItem =
  | IGenericFormInput
  | IGenericFormGroup
  ;

export type InferFormGroupItemNames<GItems extends readonly IGenericFormGroupItem[]> = {
  [GKey in keyof GItems]: GItems[GKey]['name'];
}[number];

export type InferFormGroupItemFromName<GItems extends readonly IGenericFormGroupItem[], GItemName extends InferFormGroupItemNames<GItems>> = {
  [GKey in keyof GItems]: GItems[GKey]['name'] extends GItemName
    ? GItems[GKey]
    : never;
}[number];

export class FormGroup<GName extends string, GItems extends readonly IGenericFormGroupItem[]> {
  protected readonly _name: GName;
  protected readonly _items: ReadonlyMap<string, IGenericFormGroupItem>;

  // protected readonly _validity$: IObservable<IValueValidatorErrorList>;

  constructor(
    name: GName,
    inputs: GItems,
  ) {
    this._name = name;
    this._items = new Map<string, IGenericFormGroupItem>(
      Array.from(inputs, (input: IGenericFormGroupItem): [string, IGenericFormGroupItem] => {
        return [
          input.name,
          input,
        ];
      }),
    );
  }

  /* NAME */

  get name(): GName {
    return this._name;
  }

  /* ITEMS */

  get<GItemName extends InferFormGroupItemNames<GItems>>(
    name: GItemName,
  ): InferFormGroupItemFromName<GItems, GItemName> {
    const item: IGenericFormGroupItem | undefined = this._items.get(name);
    if (item === void 0) {
      throw new Error(`Cannot find item with name: ${name}`);
    } else {
      return item as any;
    }
  }

  /* VALIDITY */

  // get isValid$(): IObservable<boolean> {
  //   return map$$(this._validity$, (errors: IValueValidatorErrorList) => errors.length === 0);
  // }
  //
  // get validator(): ValueValidator<GValue | null> {
  //   return this.disabled
  //     ? ValueValidator.none<GValue | null>()
  //     : (
  //       (this._validator === void 0)
  //         ? (
  //           this.required
  //             ? ValueValidator.required<GValue>()
  //             : ValueValidator.none<GValue | null>()
  //         )
  //         : (
  //           this.required
  //             ? ValueValidator.required<GValue>()
  //               .child(this._validator)
  //             : this._validator
  //         )
  //
  //     );
  // }
  //
  // validate(
  //   abortable?: Abortable,
  // ): AsyncTask<IValueValidatorErrorList> {
  //   return this.validator.validate(this.value, abortable);
  // }
  //
  // /* METHODS */
  //
  // reset(): void {
  //   this.value = null;
  // }
}

export type IGenericFormGroup = FormGroup<string, any[]>;

/*---*/

// export abstract class FormInputFromTextSource<GValue> extends FormInput<GValue> {
//   protected readonly _$rawValue$: IMulticastReplayLastSource<string>;
//
//   protected constructor() {
//     super();
//   }
// }

/*---*/

export class FormInputText<GName extends string> extends FormInput<GName, string> {
  constructor(
    name: GName,
    options?: IFormInputOptions<string>,
  ) {
    super(
      name,
      options,
    );
  }
}

/*------------------------------*/

async function formControlExample1() {
  // const validator = ValueValidator.group([
  //   StringValidator.pattern(/.+/),
  // ]);

  // const validator = ValueValidator.required()
  //   .child(
  //     StringValidator.sequence(
  //       StringValidator.pattern(/.+/),
  //       StringValidator.email(),
  //     ),
  //   );

  // const validator = StringValidator.sequence(
  //   StringValidator.pattern(/.+/),
  //   StringValidator.email(),
  // ).required();

  const validator = ValueValidator.subType(
    StringValidator.sequence(
      StringValidator.pattern(/.+/),
      StringValidator.email(),
    ),
  )
    .child(
      StringValidator.sequence(
        StringValidator.pattern(/.+/),
        StringValidator.email(),
      ),
    );

  // console.log(await (validator.validate(null, Abortable.never)));
  console.log(await (validator.validate('8', Abortable.never)));
}

async function formControlExample2() {
  const textInput = new FormInputText('input-a', {
    validator: ValueValidator.or(
      ValueValidator.isNullish(),
      ValueValidator.required()
        .child(
          StringValidator.sequence(
            StringValidator.pattern(/.+/),
            StringValidator.email(),
          ),
        ),
    ),
  });

  textInput.value = 'abc';
}

/*------------------------------*/

export async function formControlExample() {
  // await formControlExample1();
  await formControlExample2();
}
