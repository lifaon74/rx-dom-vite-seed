import { Abortable, AsyncTask } from '@lirx/async-task';
import { IValueValidatorErrorList } from './value-validator-error.type';

export interface ISyncValueValidator<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): IValueValidatorErrorList;
}

export interface IAsyncTaskValueValidator<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<IValueValidatorErrorList>;
}

export interface IPromiseValueValidator<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): Promise<IValueValidatorErrorList>;
}

export type IValueValidatorInput<GValue> =
  | ISyncValueValidator<GValue>
  | IAsyncTaskValueValidator<GValue>
  | IPromiseValueValidator<GValue>
  ;


