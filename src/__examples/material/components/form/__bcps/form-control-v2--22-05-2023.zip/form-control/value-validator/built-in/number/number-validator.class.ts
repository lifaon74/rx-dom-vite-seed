import { createSyncValueValidator } from '../../create-sync-value-validator';
import { IValueValidatorError, IValueValidatorErrorGenerator } from '../../value-validator-error.type';
import { ValueValidator } from '../../value-validator.class';

export const DEFAULT_NUMBER_VALIDATOR_IS_VALID_ERROR_GENERATOR: IValueValidatorErrorGenerator<number> = (): IValueValidatorError => {
  return {
    code: 'not-a-number',
    message: `Value is not a number`,
  };
};

export class NumberValidator extends ValueValidator<number> {
  static isValid(
    error: IValueValidatorErrorGenerator<number> = DEFAULT_NUMBER_VALIDATOR_IS_VALID_ERROR_GENERATOR,
  ): NumberValidator {
    return new NumberValidator(
      createSyncValueValidator<number>(
        (value: number) => !Number.isNaN(value),
        error,
      ),
    );
  }
}
