import { $$map, IObservable, IObserver, map$$, single, switchMap$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { IGenericFormInputText } from '../../../form-control/form-input/built-in/form-input-text/form-input-text.class';
import { IFormInputValue } from '../../../form-control/form-input/types/form-input-value.type';
import { INVALID_TYPE_TOKEN } from '../../../form-control/tokens/invalid-type.token';
import { INoValueToken, NO_VALUE_TOKEN } from '../../../form-control/tokens/no-value.token';
import { MatInputFullModifier } from '../../fragments/mat-input-full/mat-input-full.modifier';

// @ts-ignore
import html from './mat-input-text.component.html?raw';
// @ts-ignore
import style from './mat-input-text.component.scss?inline';

/**
 * COMPONENT: 'mat-input-text'
 */

interface IData {
  readonly name$: IObservable<string>;
  readonly value$: IObservable<string>;
  readonly $input: IObservable<IObserver<Event>>;
  readonly disabled$: IObservable<boolean>;
  readonly readonly$: IObservable<boolean>;
  readonly required$: IObservable<boolean>;
  readonly minLength$: IObservable<number | undefined>;
  readonly maxLength$: IObservable<number | undefined>;
  readonly pattern$: IObservable<RegExp | undefined>;
}

interface IMatInputTextComponentConfig {
  element: HTMLElement;
  inputs: [
    ['controller', IGenericFormInputText],
  ];
  data: IData;
}

export const MatInputTextComponent = createComponent<IMatInputTextComponentConfig>({
  name: 'mat-input-text',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    modifiers: [
      // MatInputModifier,
      // MatInputDisabledModifier,
      MatInputFullModifier,
    ],
  }),
  styles: [
    compileStyleAsComponentStyle(style),
  ],
  inputs: [
    ['controller'],
  ],
  init: (node: VirtualCustomElementNode<IMatInputTextComponentConfig>): IData => {
    const controller$ = node.inputs.get$('controller');

    const name$ = map$$(controller$, controller => controller.name);

    const value$ = switchMap$$(controller$, (controller: IGenericFormInputText): IObservable<string> => {
      return map$$<IFormInputValue<string>, string>(controller.value$, (value: IFormInputValue<string>): string => {
        return (
          (value === NO_VALUE_TOKEN)
          || (value === INVALID_TYPE_TOKEN)
        )
          ? ''
          : value;
      });
    });

    const $value = map$$(controller$, (controller: IGenericFormInputText): IObserver<string> => {
      return $$map<string, IFormInputValue<string>>(controller.$value, (value: string): IFormInputValue<string> => {
        return (value === '')
          ? NO_VALUE_TOKEN
          : value;
      });
    });

    const $input = map$$($value, (value$: IObserver<string>): IObserver<Event> => {
      return $$map<Event, string>(value$, (event: Event): string => {
        return (event.target as HTMLInputElement).value;
      });
    });

    const disabled$ = switchMap$$(controller$, controller => controller.disabled$);
    const readonly$ = switchMap$$(controller$, controller => controller.readonly$);

    const required$ = switchMap$$(controller$, controller => controller.required$);

    const minLength$ = switchMap$$(controller$, controller => controller.minLength$);
    const maxLength$ = switchMap$$(controller$, controller => controller.maxLength$);
    const pattern$ = switchMap$$(controller$, controller => controller.pattern$);
    const reset$ = switchMap$$(controller$, controller => controller.reset$);

    node.onConnected$(reset$)(() => {
      node.elementNode.dispatchEvent(new CustomEvent('reset'));
    });

    return {
      name$,
      value$,
      $input,
      disabled$,
      readonly$,
      required$,
      minLength$,
      maxLength$,
      pattern$,
    };
  },
});



