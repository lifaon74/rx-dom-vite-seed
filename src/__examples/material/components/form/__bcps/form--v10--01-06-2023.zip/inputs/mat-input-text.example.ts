import { $log, IObservable, single } from '@lirx/core';
import { bootstrap, compileReactiveHTMLAsComponentTemplate, createComponent } from '@lirx/dom';
import { FormInputText } from '../form-control/form-input/built-in/form-input-text/form-input-text.class';
import { INVALID_TYPE_TOKEN } from '../form-control/tokens/invalid-type.token';
import { MatInputTextComponent } from './built-in/mat-input-text/mat-input-text.component';

interface IMatInputTextComponentConfig {
  element: HTMLElement;
  data: {
    controller$: IObservable<FormInputText<string>>
  };
}

const MatInputTextExampleComponent = createComponent<IMatInputTextComponentConfig>({
  name: 'mat-input-text-example',
  template: compileReactiveHTMLAsComponentTemplate({
    html: `
      <form>
        <mat-input-text
          $[controller]="$.controller$"
        ></mat-input-text>
        <button type="reset">RESET</button>
      </form>
    `,
    customElements: [
      MatInputTextComponent,
    ],
  }),
  init: () => {
    const controller = new FormInputText('abc', {});

    (window as any).controller = controller;
    // controller.value = INVALID_TYPE_TOKEN;
    // controller.validity$($log);
    // console.log(controller.constraint.properties.type);
    return {
      controller$: single(controller),
    };
  },
});

/*----------*/

export function matInputTextExample(): void {
  bootstrap(MatInputTextExampleComponent);
}
