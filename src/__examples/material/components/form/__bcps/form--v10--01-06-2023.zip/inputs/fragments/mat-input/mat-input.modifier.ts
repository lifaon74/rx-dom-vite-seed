import { IObservableLike } from '@lirx/core';
import {
  compileStyleAsComponentStyle,
  createVirtualReactiveElementNodeModifier,
  IGenericVirtualReactiveElementNode,
  VirtualDOMNode,
} from '@lirx/dom';

// @ts-ignore
import style from './mat-input.component.scss?inline';

const componentStyle = compileStyleAsComponentStyle(style);

export interface IMatInputOptions {
}

export function matInputModifierFunction(
  node: IGenericVirtualReactiveElementNode,
  options?: IObservableLike<IMatInputOptions>,
): VirtualDOMNode {
  const input: Element = node.elementNode;

  if (
    (input instanceof HTMLInputElement)
    || (input instanceof HTMLTextAreaElement)
  ) {
    node.setClass('mat-input', true);

    componentStyle(node);

    return node;
  } else {
    throw new Error(`Not an <input> or <textarea>`);
  }
}

export const MatInputModifier = createVirtualReactiveElementNodeModifier<IMatInputOptions | undefined, VirtualDOMNode>('mat-input', matInputModifierFunction, { weight: 0 });

