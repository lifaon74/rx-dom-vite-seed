import { createCustomError, ICustomError, ICustomErrorMessageOptionalOptions } from '@lirx/utils';

export interface IValueValidatorErrorProperties {
  readonly code: string;
}

export type IValueValidatorError = ICustomError<'ValueValidatorError', IValueValidatorErrorProperties>;

export interface IValueValidatorErrorOptions extends ICustomErrorMessageOptionalOptions {
  code: string;
}

export function createValueValidatorError(
  {
    code,
    message,
  }: IValueValidatorErrorOptions,
): IValueValidatorError {
  return createCustomError<'ValueValidatorError', IValueValidatorErrorProperties>({
    name: 'ValueValidatorError',
    message: message ? message : `ValueError: ${code}`,
    code,
  });
}
