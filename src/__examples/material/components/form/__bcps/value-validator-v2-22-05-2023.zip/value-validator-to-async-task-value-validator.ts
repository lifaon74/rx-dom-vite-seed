import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncTaskValueValidator, IValueValidator } from './value-validator.type';

export function valueValidatorToAsyncTaskValueValidator<GValue>(
  validator: IValueValidator<GValue>,
): IAsyncTaskValueValidator<GValue> {
  return (
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void> => {
    return AsyncTask.fromFactory((abortable: Abortable): IAsyncTaskInput<void> => {
      return validator(value, abortable);
    }, abortable);
  };
}
