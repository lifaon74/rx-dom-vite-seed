import { createValueValidatorError } from '../../value-validator-error';
import { ISyncValueValidator } from '../../value-validator.type';

export function stringNotEmptyValueValidator(): ISyncValueValidator<string> {
  return (value: string): void => {
    if (value === '') {
      throw createValueValidatorError({
        code: 'empty-string',
        message: `Must not be an empty string`,
      });
    }
  };
}
