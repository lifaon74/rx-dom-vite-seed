import {
  Abortable,
  AsyncTask,
  IAsyncTaskAllSettledState,
  IAsyncTaskErrorState,
  IAsyncTaskFactory,
  IAsyncTaskInput,
} from '@lirx/async-task';
import { aggregateErrorMessage } from '../../../misc/aggregate-error-message';
import { IAsyncTaskValueValidator, IValueValidator } from '../../value-validator.type';

export function aggregateValueValidators<GValue>(
  validators: readonly IValueValidator<GValue>[],
): IAsyncTaskValueValidator<GValue> {
  return (
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void> => {
    return AsyncTask.allSettled(
      validators.map((validator: IValueValidator<GValue>): IAsyncTaskFactory<void> => {
        return (abortable: Abortable): IAsyncTaskInput<void> => {
          return validator(value, abortable);
        };
      }),
      abortable,
    )
      .successful((states: IAsyncTaskAllSettledState<void>[]): void => {
        const errors: unknown[] = states
          .filter((state: IAsyncTaskAllSettledState<void>): state is IAsyncTaskErrorState => {
            return state.state === 'error';
          })
          .map((state: IAsyncTaskErrorState): unknown => {
            return state.error;
          });

        if (errors.length > 0) {
          throw new AggregateError(
            errors,
            aggregateErrorMessage(errors),
          );
        }
      });
  };
}

