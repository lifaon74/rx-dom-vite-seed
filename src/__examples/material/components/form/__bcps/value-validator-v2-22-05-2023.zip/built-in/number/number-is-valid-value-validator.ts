import { createValueValidatorError } from '../../value-validator-error';
import { ISyncValueValidator } from '../../value-validator.type';

export function numberIsValidValueValidator(): ISyncValueValidator<number> {
  return (value: number): void => {
    if (Number.isNaN(value)) {
      throw createValueValidatorError({
        code: 'not-a-number',
        message: `Value is not a number`,
      });
    }
  };
}
