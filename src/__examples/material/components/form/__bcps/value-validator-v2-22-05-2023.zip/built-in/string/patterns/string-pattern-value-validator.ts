import { createValueValidatorError } from '../../../value-validator-error';
import { ISyncValueValidator } from '../../../value-validator.type';

export function stringPatternValueValidator(
  pattern: RegExp,
): ISyncValueValidator<string> {
  return (value: string): void => {
    pattern.lastIndex = 0;
    if (!pattern.test(value)) {
      throw createValueValidatorError({
        code: 'mismatch-pattern',
        message: `The input doesn't match pattern: /${pattern.source}/${pattern.flags}`,
      });
    }
  };
}


