import { Abortable, AsyncTask } from '@lirx/async-task';

export interface ISyncValueValidator<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): void;
}

export interface IAsyncTaskValueValidator<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void>;
}

export interface IPromiseValueValidator<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): Promise<void>;
}

export type IValueValidator<GValue> =
  | ISyncValueValidator<GValue>
  | IAsyncTaskValueValidator<GValue>
  | IPromiseValueValidator<GValue>
  ;


