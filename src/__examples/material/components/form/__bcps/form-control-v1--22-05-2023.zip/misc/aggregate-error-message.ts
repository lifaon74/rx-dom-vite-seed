export function aggregateErrorMessage(
  errors: unknown[],
): string {
  return errors
    .map((error: unknown): string => {
      if (error instanceof Error) {
        const message: string = error.message.includes('\n')
          ? error.message.split('\n').map(_ => '  ' + _).join('\n')
          : error.message;
        return `\n - ${error.name}: ${message}`;
      } else {
        return `\n  - Unknown error: ${error}`;
      }
    })
    .join('');
}
