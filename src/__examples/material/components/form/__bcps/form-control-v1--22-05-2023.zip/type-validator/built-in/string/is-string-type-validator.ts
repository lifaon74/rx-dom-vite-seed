import { ITypeValidatorFunction } from '../../type-validator-function.type';
import { createTypeValidatorError } from '../../type-validotor-error';

export function isStringTypeValidator(): ITypeValidatorFunction<any, string> {
  return (value: any): asserts value is string => {
    if (typeof value !== 'string') {
      throw createTypeValidatorError({
        type: 'not-a-string',
        message: `Value is not a string`,
      });
    }
  };
}

export function isNotEmptyStringTypeValidator(): ITypeValidatorFunction<string> {
  return (value: string): void => {
    if (value === '') {
      throw createTypeValidatorError({
        type: 'empty-string',
        message: `Value is an empty string`,
      });
    }
  };
}

export function isValidNumberTypeValidator(): ITypeValidatorFunction<number> {
  return (value: number): void => {
    if (Number.isNaN(value)) {
      throw createTypeValidatorError({
        type: 'not-a-number',
        message: `Value is not a number`,
      });
    }
  };
}


