import { aggregateErrorMessage } from '../../../misc/aggregate-error-message';
import { ITypeValidatorFunction } from '../../type-validator-function.type';

// export type IParallelTypeValidatorsValue<GValidators extends ITypeValidatorFunction<any>[]> =
//   GValidators extends []
//     ? any
//     : (
//       GValidators extends ITypeValidatorFunction<infer GValue, any>[]
//         ? GValue
//         : never
//       )
//   ;
//
// export type IParallelTypeValidatorsExpected<GValidators extends ITypeValidatorFunction<any>[]> =
//   GValidators extends []
//     ? any
//     : (
//       GValidators extends ITypeValidatorFunction<infer GValue, any>[]
//         ? GValue
//         : never
//       )
//   ;
//
// export type IParallelTypeValidatorsResult<GValidators  extends ITypeValidatorFunction<any>[]> =
//   ITypeValidatorFunction<IParallelTypeValidatorsValue<GValidators>, IParallelTypeValidatorsExpected<GValidators>>
//   ;
//
// export function parallelTypeValidators<GValidators extends ITypeValidatorFunction<any>[]>(
//   validators: GValidators,
// ): IParallelTypeValidatorsResult<GValidators> {
//   return (value: IParallelTypeValidatorsValue<GValidators>): asserts value is IParallelTypeValidatorsExpected<GValidators> => {
//     for (let i = 0, l = validators.length; i < l; i++) {
//       (validators as any[])[i](value);
//     }
//   };
// }

export function parallelTypeValidators<GValue, GExpected extends GValue = GValue>(
  validators: ITypeValidatorFunction<GValue, GExpected>[],
): ITypeValidatorFunction<GValue, GExpected> {
  return (value: GValue): asserts value is GExpected => {
    const errors: unknown[] = [];

    for (let i = 0, l = validators.length; i < l; i++) {
      try {
        (validators as any[])[i](value);
      } catch (error: unknown) {
        errors.push(error);
      }
    }

    if (errors.length > 0) {
      throw new AggregateError(
        errors,
        aggregateErrorMessage(errors),
      );
    }
  };
}

