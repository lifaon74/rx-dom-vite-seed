import { createCustomError, ICustomError } from '@lirx/utils';
import { ICustomErrorMessageOptionalOptions } from '@lirx/utils/src/errors/custom-error/custom-error.type';

export interface ITypeValidatorErrorProperties {
  readonly type: string;
}

export type ITypeValidatorError = ICustomError<'TypeValidatorError', ITypeValidatorErrorProperties>;

export interface ITypeValidatorErrorOptions extends ICustomErrorMessageOptionalOptions {
  type: string;
}

export function createTypeValidatorError(
  {
    type,
    message,
  }: ITypeValidatorErrorOptions,
): ITypeValidatorError {
  return createCustomError<'TypeValidatorError', ITypeValidatorErrorProperties>({
    name: 'TypeValidatorError',
    message: message ? message : `TypeError: ${type}`,
    type,
  });
}
