import { ITypeValidatorFunction } from '../../type-validator-function.type';

export type ISequentialTypeValidators<GValidators, GValue> =
  [GValidators] extends [[]]
    ? []
    : (
      [GValidators] extends [[infer GFirst, ...infer GRest]]
        ? (
          GFirst extends ITypeValidatorFunction<GValue, infer GExpected>
            ? [GFirst, ...ISequentialTypeValidators<GRest, GExpected>]
            : [ITypeValidatorFunction<GValue>, ...GRest]
          )
        : ITypeValidatorFunction<any>[]
      )
  ;

export type ISequentialTypeValidatorsFirstValue<GValidators> =
  GValidators extends []
    ? any
    : (
      GValidators extends [infer GFirst, ...any[]]
        ? (
          GFirst extends ITypeValidatorFunction<infer GValue, any>
            ? GValue
            : never
          )
        : never
      )
  ;

export type ISequentialTypeValidatorsLastExpected<GValidators> =
  GValidators extends []
    ? any
    : (
      GValidators extends [...any[], infer GLast]
        ? (
          GLast extends ITypeValidatorFunction<any, infer GExpected>
            ? GExpected
            : never
          )
        : never
      )
  ;

export type ISequentialTypeValidatorsResult<GValidators> =
  ITypeValidatorFunction<ISequentialTypeValidatorsFirstValue<GValidators>, ISequentialTypeValidatorsLastExpected<GValidators>>
  ;

export function sequentialTypeValidators<GValidators extends ISequentialTypeValidators<GValidators, any>>(
  validators: GValidators,
): ISequentialTypeValidatorsResult<GValidators> {
  return (value: ISequentialTypeValidatorsFirstValue<GValidators>): asserts value is ISequentialTypeValidatorsLastExpected<GValidators> => {
    for (let i = 0, l = validators.length; i < l; i++) {
      (validators as any[])[i](value);
    }
  };
}


