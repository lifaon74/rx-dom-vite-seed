

export interface ITypeValidatorFunction<GValue, GExpected extends GValue = GValue> {
  (value: GValue): asserts value is GExpected;
}
