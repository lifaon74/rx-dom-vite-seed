import { Abortable, AsyncTask } from '@lirx/async-task';
import { ITypeValidatorFunction } from '../../../type-validator/type-validator-function.type';
import { createTypeValidatorError } from '../../../type-validator/type-validotor-error';
import { IAsyncTypeValidatorFunction } from '../../async-type-validator-function.type';


export function isStringAsyncTypeValidator(): IAsyncTypeValidatorFunction<any> {
  return (
    value: any,
    abortable: Abortable,
  ): AsyncTask<void> => {
    return AsyncTask.fromFactory(() => {
      if (typeof value !== 'string') {
        throw createTypeValidatorError({
          type: 'not-a-string',
          message: `Value is not a string`,
        });
      }
    }, abortable);
  };
}

export function isNotEmptyStringAsyncTypeValidator(): IAsyncTypeValidatorFunction<string> {
  return (
    value: string,
    abortable: Abortable,
  ): AsyncTask<void> => {
    return AsyncTask.fromFactory(() => {
      if (value === '') {
        throw createTypeValidatorError({
          type: 'empty-string',
          message: `Value is an empty string`,
        });
      }
    }, abortable);
  };
}
