import { Abortable, AsyncTask } from '@lirx/async-task';
import { IAsyncTaskAllSettledState } from '@lirx/async-task/src/async-task/async-task-all-settled-state.type';
import { IAsyncTaskFactory } from '@lirx/async-task/src/async-task/types/factory/async-task-factory.type';
import { IAsyncTaskErrorState } from '@lirx/async-task/src/async-task/types/state/async-task-error-state.type';
import { aggregateErrorMessage } from '../../../misc/aggregate-error-message';
import { IAsyncTypeValidatorFunction } from '../../async-type-validator-function.type';

export function aggregateAsyncTypeValidators<GValue>(
  validators: IAsyncTypeValidatorFunction<GValue>[],
): IAsyncTypeValidatorFunction<GValue> {
  return (
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void> => {
    return AsyncTask.allSettled(
      validators.map((validator: IAsyncTypeValidatorFunction<GValue>): IAsyncTaskFactory<void> => {
        return (abortable: Abortable): AsyncTask<void> => {
          return validator(value, abortable);
        };
      }),
      abortable,
    )
      .successful((states: IAsyncTaskAllSettledState<void>[]): void => {
        const errors: unknown[] = states
          .filter((state: IAsyncTaskAllSettledState<void>): state is IAsyncTaskErrorState => {
            return state.state === 'error';
          })
          .map((state: IAsyncTaskErrorState): unknown => {
            return state.error;
          });

        if (errors.length > 0) {
          throw new AggregateError(
            errors,
            aggregateErrorMessage(errors),
          );
        }
      });
  };
}

