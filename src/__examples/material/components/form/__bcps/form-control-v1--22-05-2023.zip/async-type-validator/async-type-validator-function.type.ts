import { AsyncTask, Abortable } from '@lirx/async-task';

export interface IAsyncTypeValidatorFunction<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void>;
}
