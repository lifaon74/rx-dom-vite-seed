import { AsyncTask, Abortable } from '@lirx/async-task';
import {
  createMulticastReplayLastSource,
  ICreateReplayLastSourceInitialValue,
  IMulticastReplayLastSource,
  IObservable,
  IObserver,
} from '@lirx/core';
import { IAsyncTypeValidatorFunction } from './async-type-validator/async-type-validator-function.type';
import { aggregateAsyncTypeValidators } from './async-type-validator/built-in/aggregate/aggregate-type-validators';
import {
  isNotEmptyStringAsyncTypeValidator,
  isStringAsyncTypeValidator,
} from './async-type-validator/built-in/string/is-string-async-type-validator';
import { parallelTypeValidators } from './type-validator/built-in/aggregate/parallel-type-validators';
import { isNotEmptyStringTypeValidator, isStringTypeValidator } from './type-validator/built-in/string/is-string-type-validator';
import { ITypeValidatorFunction } from './type-validator/type-validator-function.type';

/** FORM VALIDATION **/

export class FormValidator<GValue> {
  validate(): AsyncTask<void> {

  }
}

/** FORM INPUT **/

export interface IFormInputOptions<GValue> {
  initialValue?: GValue;
}

export abstract class FormInput<GValue> {
  protected _$value$: IMulticastReplayLastSource<GValue>;
  protected _$disabled$: IMulticastReplayLastSource<boolean>;

  // protected _$valid$: IMulticastReplayLastSource<boolean>;

  protected constructor(
    {
      ...options
    }: IFormInputOptions<GValue>,
  ) {
    const initialValue: ICreateReplayLastSourceInitialValue<GValue> = ('initialValue' in options)
      ? [options.initialValue] as [GValue]
      : [];
    this._$value$ = createMulticastReplayLastSource<GValue>(...initialValue);
    this._$disabled$ = createMulticastReplayLastSource<boolean>(false);
  }

  /* VALUE */

  get value(): GValue {
    return this._$value$.getValue();
  }

  get value$(): IObservable<GValue> {
    return this._$value$.subscribe;
  }

  get $value(): IObserver<GValue> {
    return this._$value$.emit;
  }

  /* VALUE */

  get disabled(): boolean {
    return this._$disabled$.getValue();
  }

  get disabled$(): IObservable<boolean> {
    return this._$disabled$.subscribe;
  }

  get $disabled(): IObserver<boolean> {
    return this._$disabled$.emit;
  }

  /* VALIDITY */

  // get disabled(): boolean {
  //   return this._$disabled$.getValue();
  // }
  //
  // get disabled$(): IObservable<boolean> {
  //   return this._$disabled$.subscribe;
  // }
  //
  // get $disabled(): IObserver<boolean> {
  //   return this._$disabled$.emit;
  // }

  /* METHODS */

  abstract reset(): void;
}

// export class FormInputText extends FormInput<string> {
//   constructor() {
//     super();
//   }
// }

/*------------------------------*/

function formControlExample1(): void {
  // const validator: ITypeValidatorFunction<any, string> = sequentialTypeValidators([
  //   isStringTypeValidator(),
  //   isNotEmptyStringTypeValidator(),
  // ]);

  const validator: ITypeValidatorFunction<string, string> = parallelTypeValidators([
    isStringTypeValidator(),
    isNotEmptyStringTypeValidator(),
    parallelTypeValidators([
      isStringTypeValidator(),
      isNotEmptyStringTypeValidator(),
      isNotEmptyStringTypeValidator(),
      parallelTypeValidators([
        isStringTypeValidator(),
        isNotEmptyStringTypeValidator(),
        isNotEmptyStringTypeValidator(),
      ]),
    ]),
  ]);

  const value: any = '';

  validator(value);
}

async function formControlExample2() {
  const validator = aggregateAsyncTypeValidators([
    isStringAsyncTypeValidator(),
    isNotEmptyStringAsyncTypeValidator(),
  ]);

  console.log(await (validator('', Abortable.never)));
}

/*------------------------------*/

export async function formControlExample() {
  // formControlExample1();
  await formControlExample2();
}
