import { IObservable, MAP_FILTER_DISCARD, mapFilter$$ } from '@lirx/core';
import { IMapFilterMapFunctionReturn } from '@lirx/core/src/observer/pipes/built-in/map-filter/map-filter-map-function.type';
import { IValueValidatorError } from '../../value-validator/errors/value-validator-error.type';
import { IValidityStateNotifications } from './validity-state-notifications.type';

export abstract class AbstractFormControl<GName extends string, GError extends IValueValidatorError> {
  protected readonly _name: GName;
  protected readonly _validityState$: IObservable<IValidityStateNotifications<GError>>;
  protected readonly _isValid$: IObservable<boolean>;

  protected constructor(
    name: GName,
    validityState$: IObservable<IValidityStateNotifications<GError>>,
  ) {
    this._name = name;
    this._validityState$ = validityState$;
    this._isValid$ = mapFilter$$<IValidityStateNotifications<GError>, boolean>(
      validityState$,
      (notification: IValidityStateNotifications<GError>): IMapFilterMapFunctionReturn<boolean> => {
        switch (notification.name) {
          case 'valid':
            return true;
          case 'invalid':
            return false;
          case 'validating':
          case 'error':
          default:
            return MAP_FILTER_DISCARD;
        }
      });
  }

  /* NAME */

  get name(): GName {
    return this._name;
  }

  /* VALIDITY STATE */

  get validityState$(): IObservable<IValidityStateNotifications<GError>> {
    return this._validityState$;
  }

  get isValid$(): IObservable<boolean> {
    return this._isValid$;
  }

  /* METHODS */

  abstract reset(): void;
}

export type IGenericAbstractFormControl = AbstractFormControl<string, any>;

export type InferAbstractFormControlName<GAbstractFormControl extends IGenericAbstractFormControl> =
  GAbstractFormControl extends AbstractFormControl<infer GName, any>
    ? GName
    : never
  ;

export type InferAbstractFormControlError<GAbstractFormControl extends IGenericAbstractFormControl> =
  GAbstractFormControl extends AbstractFormControl<any, infer GError>
    ? GError
    : never
  ;
