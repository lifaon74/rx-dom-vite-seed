import { INotification } from '@lirx/core';
import { IValidNotificationName } from './valid-notification-name.constant';

export type IValidNotification = INotification<IValidNotificationName, void>;
