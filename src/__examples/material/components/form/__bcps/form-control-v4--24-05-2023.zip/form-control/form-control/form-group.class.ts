import { combineLatest, distinct$$, IObservable, map$$, shareRL$$ } from '@lirx/core';
import { IValueValidatorError } from '../value-validator/errors/value-validator-error.type';
import {
  AbstractFormControl,
  IGenericAbstractFormControl, InferAbstractFormControlError,
  InferAbstractFormControlName,
} from './abstract-form-control/abstract-form-control.class';
import { createInvalidNotification } from './abstract-form-control/notifications/invalid/create-invalid-notification';
import { STATIC_VALID_NOTIFICATION } from './abstract-form-control/notifications/valid/valid-notification.constant';
import { IValidityStateNotifications } from './abstract-form-control/validity-state-notifications.type';

/** TYPES **/

/* GET */

export interface IFormGroupValidatorError<GItem extends IGenericAbstractFormControl> extends IValueValidatorError {
  readonly name: 'form-group';
  readonly item: GItem;
  readonly errors: readonly InferAbstractFormControlError<GItem>[];
}

export type IFormGroupValidityStateNotifications<GItem extends IGenericAbstractFormControl> =
  IValidityStateNotifications<IFormGroupValidatorError<GItem>>;

/* GET */

export type InferFormGroupItemNames<GItem extends IGenericAbstractFormControl> = InferAbstractFormControlName<GItem>;

export type InferFormGroupItemFromName<GItem extends IGenericAbstractFormControl, GItemName extends string> = Extract<GItem, AbstractFormControl<GItemName, any>>
  ;

/** CLASS **/

export class FormGroup<GName extends string, GItem extends IGenericAbstractFormControl> extends AbstractFormControl<GName, IFormGroupValidatorError<GItem>> {
  protected readonly _items: ReadonlyMap<string, GItem>;

  constructor(
    name: GName,
    items: Iterable<GItem>,
  ) {
    type GItemNotifications = IValidityStateNotifications<any>;

    const _items: GItem[] = Array.from(items);

    const validityState$ = shareRL$$<IFormGroupValidityStateNotifications<GItem>>(
      distinct$$<IFormGroupValidityStateNotifications<GItem>>(
        map$$<readonly GItemNotifications[], IFormGroupValidityStateNotifications<GItem>>(
          combineLatest<IObservable<GItemNotifications>[]>(
            _items.map((item: GItem): IObservable<GItemNotifications> => {
              return item.validityState$;
            }),
          ),
          (notifications: readonly IValidityStateNotifications<any>[]): IFormGroupValidityStateNotifications<GItem> => {
            for (let i = 0, l = notifications.length; i < l; i++) {
              const notification: GItemNotifications = notifications[i];
              switch (notification.name) {
                case 'validating':
                case 'error':
                  return notification;
                case 'invalid':
                  return createInvalidNotification<IFormGroupValidatorError<GItem>>([
                    {
                      name: 'form-group',
                      item: _items[i],
                      errors: notification.value,
                    },
                  ]);
              }
            }
            return STATIC_VALID_NOTIFICATION;
          },
        ),
      ),
    );

    super(
      name,
      validityState$,
    );

    this._items = new Map<string, GItem>(
      Array.from(items, (item: GItem): [string, GItem] => {
        return [
          item.name,
          item,
        ];
      }),
    );
  }

  /* ITEMS */

  get<GItemName extends InferFormGroupItemNames<GItem>>(
    name: GItemName,
  ): InferFormGroupItemFromName<GItem, GItemName> {
    const item: IGenericAbstractFormControl | undefined = this._items.get(name);
    if (item === void 0) {
      throw new Error(`Cannot find item with name: ${name}`);
    } else {
      return item as any;
    }
  }

  items(): IterableIterator<GItem> {
    return this._items.values();
  }

  [Symbol.iterator](): IterableIterator<GItem> {
    return this._items.values();
  }

  /* METHODS */

  override reset(): void {
    const iterator: Iterator<GItem> = this.items();
    let result: IteratorResult<GItem>;
    while (!(result = iterator.next()).done) {
      result.value.reset();
    }
  }
}

export type IGenericFormGroup = FormGroup<string, any>;
