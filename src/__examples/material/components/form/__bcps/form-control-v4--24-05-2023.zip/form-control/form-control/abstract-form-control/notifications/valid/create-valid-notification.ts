
import { createNotification } from '@lirx/core';
import { IValidNotificationName, VALID_NOTIFICATION_NAME } from './valid-notification-name.constant';
import { IValidNotification } from './valid-notification.type';

export function createValidNotification(): IValidNotification {
  return createNotification<IValidNotificationName, void>(VALID_NOTIFICATION_NAME, void 0);
}
