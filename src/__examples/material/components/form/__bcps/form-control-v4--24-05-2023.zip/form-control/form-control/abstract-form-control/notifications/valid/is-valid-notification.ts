import { isNotification } from '@lirx/core';
import { IValidNotificationName, VALID_NOTIFICATION_NAME } from './valid-notification-name.constant';
import { IValidNotification } from './valid-notification.type';

export function isValidNotification(
  value: any,
): value is IValidNotification {
  return isNotification<IValidNotificationName, void>(value, VALID_NOTIFICATION_NAME);
}
