import { IValueValidatorError } from '../value-validator-error.type';

export interface IUnknownValidatorError extends IValueValidatorError {
  readonly name: 'unknown';
  readonly error?: any;
}
