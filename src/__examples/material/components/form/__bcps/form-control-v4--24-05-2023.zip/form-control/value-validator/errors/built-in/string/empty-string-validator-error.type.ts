import { IValueValidatorError } from '../../value-validator-error.type';

export interface IEmptyStringValidatorError extends IValueValidatorError {
  readonly name: 'empty';
}
