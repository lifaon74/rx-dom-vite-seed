import { isNotification } from '@lirx/core';
import { IValueValidatorError } from '../../../../value-validator/errors/value-validator-error.type';
import { IInvalidNotificationName, INVALID_NOTIFICATION_NAME } from './invalid-notification-name.constant';
import { IInvalidNotification } from './invalid-notification.type';

export function isInvalidNotification<GError extends IValueValidatorError>(
  value: any,
): value is IInvalidNotification<GError> {
  return isNotification<IInvalidNotificationName, readonly GError[]>(value, INVALID_NOTIFICATION_NAME);
}
