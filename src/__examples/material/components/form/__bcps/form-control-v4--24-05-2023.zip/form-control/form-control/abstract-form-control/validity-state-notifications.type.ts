import { IErrorNotification } from '@lirx/core';
import { IValueValidatorError } from '../../value-validator/errors/value-validator-error.type';
import { IInvalidNotification } from './notifications/invalid/invalid-notification.type';
import { IValidNotification } from './notifications/valid/valid-notification.type';
import { IValidatingNotification } from './notifications/validating/validating-notification.type';

export type IValidityStateNotifications<GError extends IValueValidatorError> =
  | IValidatingNotification
  | IValidNotification
  | IInvalidNotification<GError>
  | IErrorNotification
  ;


