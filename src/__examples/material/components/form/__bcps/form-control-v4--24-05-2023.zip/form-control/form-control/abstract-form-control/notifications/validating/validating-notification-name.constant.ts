export const VALIDATING_NOTIFICATION_NAME = 'validating';

export type IValidatingNotificationName = typeof VALIDATING_NOTIFICATION_NAME;
