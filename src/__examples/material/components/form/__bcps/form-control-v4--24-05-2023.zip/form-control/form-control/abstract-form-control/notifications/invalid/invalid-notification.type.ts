import { INotification } from '@lirx/core';
import { IValueValidatorError } from '../../../../value-validator/errors/value-validator-error.type';
import { IInvalidNotificationName } from './invalid-notification-name.constant';

export type IInvalidNotification<GError extends IValueValidatorError> = INotification<IInvalidNotificationName, readonly GError[]>;
