
import { createNotification } from '@lirx/core';
import { IValidatingNotificationName, VALIDATING_NOTIFICATION_NAME } from './validating-notification-name.constant';
import { IValidatingNotification } from './validating-notification.type';

export function createValidatingNotification(): IValidatingNotification {
  return createNotification<IValidatingNotificationName, void>(VALIDATING_NOTIFICATION_NAME, void 0);
}
