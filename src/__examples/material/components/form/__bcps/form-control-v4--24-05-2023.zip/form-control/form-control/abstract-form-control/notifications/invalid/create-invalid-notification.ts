
import { createNotification } from '@lirx/core';
import { IValueValidatorError } from '../../../../value-validator/errors/value-validator-error.type';
import { IInvalidNotificationName, INVALID_NOTIFICATION_NAME } from './invalid-notification-name.constant';
import { IInvalidNotification } from './invalid-notification.type';

export function createInvalidNotification<GError extends IValueValidatorError>(
  errors: readonly GError[],
): IInvalidNotification<GError> {
  return createNotification<IInvalidNotificationName, readonly GError[]>(INVALID_NOTIFICATION_NAME, errors);
}
