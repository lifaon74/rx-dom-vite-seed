import { Abortable } from '@lirx/async-task';
import { $log, combineLatest, distinct$$, IObservable, map$$, shareRL$$ } from '@lirx/core';
import {
  AbstractFormControl,
  IGenericAbstractFormControl,
  InferAbstractFormControlName,
} from './form-control/abstract-form-control/abstract-form-control.class';
import { FormGroup } from './form-control/form-group.class';
import { FormInput, IFormInputOptions } from './form-control/form-input.class';
import { NumberValidator } from './value-validator/built-in/number/number-validator.class';
import { StringValidator } from './value-validator/built-in/string/string-validator.class';
import { IValueValidatorError } from './value-validator/errors/value-validator-error.type';
import { ValueValidator } from './value-validator/value-validator.class';

/*---*/

// export abstract class FormInputFromTextSource<GValue> extends FormInput<GValue> {
//   protected readonly _$rawValue$: IMulticastReplayLastSource<string>;
//
//   protected constructor() {
//     super();
//   }
// }

/*---*/

export interface IFormInputTextOptions<GError extends IValueValidatorError> extends IFormInputOptions<string, GError> {

}

export class FormInputText<GName extends string, GError extends IValueValidatorError> extends FormInput<GName, string, GError> {
  constructor(
    name: GName,
    options?: IFormInputTextOptions<GError>,
  ) {
    super(
      name,
      options,
    );
  }
}

export interface IFormInputNumberOptions<GError extends IValueValidatorError> extends IFormInputOptions<number, GError> {

}

export class FormInputNumber<GName extends string, GError extends IValueValidatorError> extends FormInput<GName, number, GError> {
  constructor(
    name: GName,
    options?: IFormInputNumberOptions<GError>,
    // {
    //   validator,
    //   ...options
    // }: IFormInputNumberOptions<GError> = {},
  ) {
    super(
      name,
      options,
      // {
      //   ...options,
      //   validator: (validator === void 0)
      //     ? NumberValidator.isValid()
      //     : NumberValidator.all(
      //       NumberValidator.isValid(),
      //       validator,
      //     ),
      // },
    );
  }
}

/*------------------------------*/

async function formControlExample1() {
  // const validator = StringValidator.pattern(/.+/);

  // const validator = ValueValidator.merge([
  //   // StringValidator.pattern(/.+/),
  //   StringValidator.pattern(/.+/),
  //   NumberValidator.isValid(),
  // ]);

  // const validator = ValueValidator.and(
  //   StringValidator.notEmpty(),
  //   StringValidator.pattern(/.+/),
  //   // NumberValidator.isValid(),
  // );

  const validator = ValueValidator.optional(
    StringValidator.all(
      StringValidator.notEmpty(),
      StringValidator.pattern(/.+/),
      StringValidator.email(),
    ),
  );

  // console.log(await (validator.validate(null, Abortable.never)));
  console.log(await (validator.validate('', Abortable.never)));
}

async function formControlExample2() {
  const textInput = new FormInputText('input-a', {
    validator: StringValidator.email(),
  });

  textInput.value = 'abc@mail.com';

  const numberInput = new FormInputNumber('input-b', {
    validator: NumberValidator.isValid(),
  });

  numberInput.value = 5;

  const group = new FormGroup('group-a', [
    textInput,
    numberInput,
  ]);

  group.validityState$($log);
  // numberInput.value = Number.NaN;

}

/*------------------------------*/

export async function formControlExample() {
  // await formControlExample1();
  await formControlExample2();
}
