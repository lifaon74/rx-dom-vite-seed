import { INotification } from '@lirx/core';
import { IValidatingNotificationName } from './validating-notification-name.constant';

export type IValidatingNotification = INotification<IValidatingNotificationName, void>;
