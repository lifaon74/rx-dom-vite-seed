export const VALID_NOTIFICATION_NAME = 'valid';

export type IValidNotificationName = typeof VALID_NOTIFICATION_NAME;
