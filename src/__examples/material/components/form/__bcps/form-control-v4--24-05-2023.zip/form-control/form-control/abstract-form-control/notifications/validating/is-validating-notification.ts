import { isNotification } from '@lirx/core';
import { IValidatingNotificationName, VALIDATING_NOTIFICATION_NAME } from './validating-notification-name.constant';
import { IValidatingNotification } from './validating-notification.type';

export function isValidatingNotification(
  value: any,
): value is IValidatingNotification {
  return isNotification<IValidatingNotificationName, void>(value, VALIDATING_NOTIFICATION_NAME);
}
