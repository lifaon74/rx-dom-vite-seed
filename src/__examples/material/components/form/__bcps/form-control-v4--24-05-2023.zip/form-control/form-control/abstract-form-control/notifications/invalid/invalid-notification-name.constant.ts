export const INVALID_NOTIFICATION_NAME = 'invalid';

export type IInvalidNotificationName = typeof INVALID_NOTIFICATION_NAME;
