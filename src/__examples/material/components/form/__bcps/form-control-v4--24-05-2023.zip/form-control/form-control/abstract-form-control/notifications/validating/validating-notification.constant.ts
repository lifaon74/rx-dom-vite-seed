import { freeze } from '@lirx/core';
import { createValidatingNotification } from './create-validating-notification';
import { IValidatingNotification } from './validating-notification.type';

export const STATIC_VALIDATING_NOTIFICATION: IValidatingNotification = freeze(createValidatingNotification());
