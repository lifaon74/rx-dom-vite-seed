import { freeze } from '@lirx/core';
import { createValidNotification } from './create-valid-notification';
import { IValidNotification } from './valid-notification.type';

export const STATIC_VALID_NOTIFICATION: IValidNotification = freeze(createValidNotification());
