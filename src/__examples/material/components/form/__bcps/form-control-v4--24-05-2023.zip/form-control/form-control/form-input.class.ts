import { Abortable } from '@lirx/async-task';
import {
  combineLatest,
  createMulticastReplayLastSource,
  fromPromiseFactory,
  IFromPromiseFactoryObservableNotifications,
  IMapFilterMapFunctionReturn,
  IMulticastReplayLastSource,
  IObservable,
  IObserver,
  map$$,
  MAP_FILTER_DISCARD,
  mapFilter$$,
  merge,
  shareRL$$,
  single,
  switchMap$$,
} from '@lirx/core';
import { IValueValidatorError } from '../value-validator/errors/value-validator-error.type';
import { IRequiredValidatorError } from '../value-validator/required-validator-error.type';
import { ValueValidator } from '../value-validator/value-validator.class';
import { AbstractFormControl } from './abstract-form-control/abstract-form-control.class';
import { createInvalidNotification } from './abstract-form-control/notifications/invalid/create-invalid-notification';
import { STATIC_VALID_NOTIFICATION } from './abstract-form-control/notifications/valid/valid-notification.constant';
import { STATIC_VALIDATING_NOTIFICATION } from './abstract-form-control/notifications/validating/validating-notification.constant';
import { IValidatingNotification } from './abstract-form-control/notifications/validating/validating-notification.type';
import { IValidityStateNotifications } from './abstract-form-control/validity-state-notifications.type';

/** TYPES **/

export type IFormInputValidatorError<GError extends IValueValidatorError> =
  | GError
  | IRequiredValidatorError
  ;

export type IFormInputValidatorErrors<GError extends IValueValidatorError> = IFormInputValidatorError<GError>[];

export type IFormInputValidityStateNotifications<GError extends IValueValidatorError> = IValidityStateNotifications<IFormInputValidatorError<GError>>;

export type IFormInputValidityStateObservable<GError extends IValueValidatorError> = IObservable<IFormInputValidityStateNotifications<GError>>;


/** CLASS **/

export interface IFormInputOptions<GValue, GError extends IValueValidatorError> {
  value?: GValue | null;
  disabled?: boolean;
  required?: boolean;
  validator?: ValueValidator<GValue, GError>;
}

export abstract class FormInput<GName extends string, GValue, GError extends IValueValidatorError> extends AbstractFormControl<GName, IFormInputValidatorError<GError>> {

  protected readonly _$value$: IMulticastReplayLastSource<GValue | null>;
  protected readonly _$disabled$: IMulticastReplayLastSource<boolean>;
  protected readonly _$required$: IMulticastReplayLastSource<boolean>;

  protected constructor(
    name: GName,
    {
      value = null,
      disabled = false,
      required = false,
      validator,
    }: IFormInputOptions<GValue, GError> = {},
  ) {
    const $value$ = createMulticastReplayLastSource<GValue | null>(value);
    const $disabled$ = createMulticastReplayLastSource<boolean>(disabled);
    const $required$ = createMulticastReplayLastSource<boolean>(required);

    const disabled$ = $disabled$.subscribe;
    const required$ = $required$.subscribe;

    const validator$ = map$$(
      combineLatest([disabled$, required$]),
      ([disabled, required]): ValueValidator<GValue | null, GError | IRequiredValidatorError> => {
        return disabled
          ? ValueValidator.none<GValue | null>()
          : (
            required
              ? ValueValidator.required<GValue, GError>(validator)
              : (
                (validator === void 0)
                  ? ValueValidator.none<GValue | null>()
                  : ValueValidator.optional<GValue, GError>(validator)
              )
          );
      },
    );

    const validityState$ = shareRL$$<IFormInputValidityStateNotifications<GError>>(
      switchMap$$(validator$, (validator: ValueValidator<GValue | null, IFormInputValidatorError<GError>>): IFormInputValidityStateObservable<GError> => {
        return switchMap$$(this.value$, (value: GValue | null): IFormInputValidityStateObservable<GError> => {
          return merge([
            single<IValidatingNotification>(STATIC_VALIDATING_NOTIFICATION),
            mapFilter$$<IFromPromiseFactoryObservableNotifications<IFormInputValidatorErrors<GError>>, IFormInputValidityStateNotifications<GError>>(
              fromPromiseFactory<IFormInputValidatorErrors<GError>>((signal: AbortSignal): Promise<IFormInputValidatorErrors<GError>> => {
                return validator.validate(value, Abortable.fromAbortSignal(signal)).toPromise();
              }),
              (notification: IFromPromiseFactoryObservableNotifications<IFormInputValidatorErrors<GError>>): IMapFilterMapFunctionReturn<IFormInputValidityStateNotifications<GError>> => {
                switch (notification.name) {
                  case 'next':
                    return (notification.value.length === 0)
                      ? STATIC_VALID_NOTIFICATION
                      : createInvalidNotification<IFormInputValidatorError<GError>>(notification.value);
                  case 'error':
                    return notification;
                  default:
                    return MAP_FILTER_DISCARD;
                }
              },
            ),
          ]);
        });
      }),
    );

    super(
      name,
      validityState$,
    );

    this._$value$ = $value$;
    this._$disabled$ = $disabled$;
    this._$required$ = $required$;
  }

  /* VALUE */

  get value(): GValue | null {
    return this._$value$.getValue();
  }

  set value(
    input: GValue | null,
  ) {
    this._$value$.emit(input);
  }

  get value$(): IObservable<GValue | null> {
    return this._$value$.subscribe;
  }

  get $value(): IObserver<GValue | null> {
    return this._$value$.emit;
  }

  /* DISABLED */

  get disabled(): boolean {
    return this._$disabled$.getValue();
  }

  set disabled(
    input: boolean,
  ) {
    this._$disabled$.emit(input);
  }

  get disabled$(): IObservable<boolean> {
    return this._$disabled$.subscribe;
  }

  get $disabled(): IObserver<boolean> {
    return this._$disabled$.emit;
  }

  /* REQUIRED */

  get required(): boolean {
    return this._$required$.getValue();
  }

  set required(
    input: boolean,
  ) {
    this._$required$.emit(input);
  }

  get required$(): IObservable<boolean> {
    return this._$required$.subscribe;
  }

  get $required(): IObserver<boolean> {
    return this._$required$.emit;
  }

  /* METHODS */

  override reset(): void {
    this.value = null;
  }
}

export type IGenericFormInput = FormInput<string, any, any>;

