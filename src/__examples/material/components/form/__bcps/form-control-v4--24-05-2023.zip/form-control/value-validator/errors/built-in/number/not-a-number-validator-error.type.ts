import { IValueValidatorError } from '../../value-validator-error.type';

export interface INotANumberValidatorError extends IValueValidatorError {
  readonly name: 'not-a-number';
}
