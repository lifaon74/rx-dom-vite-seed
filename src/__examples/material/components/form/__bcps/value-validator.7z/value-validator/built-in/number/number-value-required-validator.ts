import { ValueValidatorError } from '../../value-validator-error.class';
import { IValueValidatorFunction, IValueValidatorFunctionResult } from '../../value-validator-function.type';

export function stringValueRequiredValidator(): IValueValidatorFunction<string> {
  return (
    value: number,
  ): IValueValidatorFunctionResult => {
    if (value === '') {
      return [
        new ValueValidatorError({
          type: 'required',
          message: `This value is required`,
        }),
      ];
    } else {
      return [];
    }
  };
}
