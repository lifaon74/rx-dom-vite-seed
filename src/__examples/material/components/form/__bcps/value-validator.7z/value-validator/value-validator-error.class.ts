export interface IValueValidatorErrorOptions {
  type: string;
  message: string;
}

export class ValueValidatorError {
  readonly type: string;
  readonly message: string;

  constructor(
    {
      type,
      message,
    }: IValueValidatorErrorOptions,
  ) {
    this.type = type;
    this.message = message;
  }
}
