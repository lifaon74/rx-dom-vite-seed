import { ValueValidatorError } from './value-validator-error.class';

export type IValueValidatorFunctionResult = readonly ValueValidatorError[];

export interface IValueValidatorFunction<GValue> {
  (
    value: GValue | undefined,
  ): IValueValidatorFunctionResult;
}
