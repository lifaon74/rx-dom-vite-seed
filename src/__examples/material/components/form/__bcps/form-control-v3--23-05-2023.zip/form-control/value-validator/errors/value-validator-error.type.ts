
export interface IValueValidatorError {
  readonly name: string;
}
