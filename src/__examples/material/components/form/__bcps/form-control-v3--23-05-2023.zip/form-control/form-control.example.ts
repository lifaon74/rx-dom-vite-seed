import { Abortable } from '@lirx/async-task';
import { $log, combineLatest, distinct$$, IObservable, map$$, shareRL$$ } from '@lirx/core';
import { AbstractFormControl, IGenericAbstractFormControl, InferAbstractFormControlName } from './form-control/abstract-form-control';
import { FormInput, IFormInputOptions } from './form-control/form-input';
import { NumberValidator } from './value-validator/built-in/number/number-validator.class';
import { StringValidator } from './value-validator/built-in/string/string-validator.class';
import { IValueValidatorError } from './value-validator/errors/value-validator-error.type';
import { ValueValidator } from './value-validator/value-validator.class';

/*---*/

export type InferFormGroupItemNames<GItem extends IGenericAbstractFormControl> = InferAbstractFormControlName<GItem>;

export type InferFormGroupItemFromName<GItem extends IGenericAbstractFormControl, GItemName extends string> = Extract<GItem, AbstractFormControl<GItemName>>
  ;

export class FormGroup<GName extends string, GItem extends IGenericAbstractFormControl> extends AbstractFormControl<GName> {
  protected readonly _items: ReadonlyMap<string, GItem>;

  constructor(
    name: GName,
    items: Iterable<GItem>,
  ) {
    const isValid$ = shareRL$$<boolean>(
      distinct$$(
        map$$(
          combineLatest(
            Array.from(items, (item: GItem): IObservable<boolean> => {
              return item.isValid$;
            }),
          ),
          (values: readonly boolean[]): boolean => {
            for (let i = 0, l = values.length; i < l; i++) {
              if (!values[i]) {
                return false;
              }
            }
            return true;
          },
        ),
      ),
    );

    super(
      name,
      isValid$,
    );

    this._items = new Map<string, GItem>(
      Array.from(items, (item: GItem): [string, GItem] => {
        return [
          item.name,
          item,
        ];
      }),
    );
  }

  /* ITEMS */

  get<GItemName extends InferFormGroupItemNames<GItem>>(
    name: GItemName,
  ): InferFormGroupItemFromName<GItem, GItemName> {
    const item: IGenericAbstractFormControl | undefined = this._items.get(name);
    if (item === void 0) {
      throw new Error(`Cannot find item with name: ${name}`);
    } else {
      return item as any;
    }
  }

  items(): IterableIterator<GItem> {
    return this._items.values();
  }

  [Symbol.iterator](): IterableIterator<GItem> {
    return this._items.values();
  }

  /* METHODS */

  override reset(): void {
    const iterator: Iterator<GItem> = this.items();
    let result: IteratorResult<GItem>;
    while (!(result = iterator.next()).done) {
      result.value.reset();
    }
  }
}

export type IGenericFormGroup = FormGroup<string, any>;

/*---*/

// export abstract class FormInputFromTextSource<GValue> extends FormInput<GValue> {
//   protected readonly _$rawValue$: IMulticastReplayLastSource<string>;
//
//   protected constructor() {
//     super();
//   }
// }

/*---*/

export interface IFormInputTextOptions<GError extends IValueValidatorError> extends IFormInputOptions<string, GError> {

}

export class FormInputText<GName extends string, GError extends IValueValidatorError> extends FormInput<GName, string, GError> {
  constructor(
    name: GName,
    options?: IFormInputTextOptions<GError>,
  ) {
    super(
      name,
      options,
    );
  }
}

export interface IFormInputNumberOptions<GError extends IValueValidatorError> extends IFormInputOptions<number, GError> {

}

export class FormInputNumber<GName extends string, GError extends IValueValidatorError> extends FormInput<GName, number, GError> {
  constructor(
    name: GName,
    options?: IFormInputNumberOptions<GError>,
  ) {
    super(
      name,
      options,
    );
  }
}

/*------------------------------*/

async function formControlExample1() {
  // const validator = StringValidator.pattern(/.+/);

  // const validator = ValueValidator.merge([
  //   // StringValidator.pattern(/.+/),
  //   StringValidator.pattern(/.+/),
  //   NumberValidator.isValid(),
  // ]);

  // const validator = ValueValidator.and(
  //   StringValidator.notEmpty(),
  //   StringValidator.pattern(/.+/),
  //   // NumberValidator.isValid(),
  // );

  const validator = ValueValidator.optional(
    StringValidator.all(
      StringValidator.notEmpty(),
      StringValidator.pattern(/.+/),
      StringValidator.email(),
    ),
  );

  // console.log(await (validator.validate(null, Abortable.never)));
  console.log(await (validator.validate('', Abortable.never)));
}

async function formControlExample2() {
  const textInput = new FormInputText('input-a', {
    validator: ValueValidator.optional(
      StringValidator.email(),
    ),
  });

  textInput.value = 'abc@mail.com';

  const numberInput = new FormInputNumber('input-b', {
    validator: ValueValidator.optional(
      NumberValidator.isValid(),
    ),
  });

  numberInput.value = 5;

  const group = new FormGroup('group-a', [
    textInput,
    numberInput,
  ]);

  group.validityState$($log);
  // numberInput.value = Number.NaN;

}

/*------------------------------*/

export async function formControlExample() {
  // await formControlExample1();
  await formControlExample2();
}
