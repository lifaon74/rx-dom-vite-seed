import { Abortable, AsyncTask, IAsyncTaskFactory, IAsyncTaskInput } from '@lirx/async-task';
import { INullish, isNullish } from '@lirx/utils';
import { IValueValidatorError } from './errors/value-validator-error.type';
import { IRequiredValidatorError } from './required-validator-error.type';
import { IValueValidatorInput } from './value-validator-input.type';


/* ALL */
export type InferValueValidatorAllValue<GFirstValidator extends IGenericValueValidator> =
  GFirstValidator extends ValueValidator<infer GValue, any>
    ? GValue
    : never;

export type InferValueValidatorAllErrorFromValidators<GValidators extends readonly IGenericValueValidator[]> =
  {
    [GKey in keyof GValidators]: GValidators[GKey] extends ValueValidator<any, infer GError>
    ? GError
    : never;
  }[number];

export type InferValueValidatorAllError<GFirstValidator extends IGenericValueValidator, GValidators extends readonly IGenericValueValidator[]> =
  InferValueValidatorAllErrorFromValidators<[GFirstValidator, ...GValidators]>;

export type IValueValidatorAllConstraint<GFirstValidator extends IGenericValueValidator> =
  GFirstValidator extends ValueValidator<infer GValue, any>
    ? readonly ValueValidator<GValue, any>[]
    : never;

/** CLASS **/

export class ValueValidator<GValue, GError extends IValueValidatorError> {
  static none<GValue>(): ValueValidator<GValue, never> {
    return new ValueValidator<GValue, never>(() => []);
  }

  // static branch<GValue, GSubValue extends GValue, GError extends IValueValidatorError>(
  //   isSubType: (value: GValue) => value is GSubValue,
  //   validatorA: ValueValidator<GSubValue, GError>,
  //   validatorB: ValueValidator<GValue, GError>,
  // ): ValueValidator<GValue, GError> {
  //   return new ValueValidator<GValue, GError>((
  //     value: GValue,
  //     abortable: Abortable,
  //   ): AsyncTask<GError[]> => {
  //     return isSubType(value)
  //      ? validatorA.validate(value, abortable)
  //      : validatorB.validate(value, abortable)
  //   });
  // }

  static required<GValue, GError extends IValueValidatorError>(
    validator?: ValueValidator<GValue, GError>,
  ): ValueValidator<GValue | INullish, GError | IRequiredValidatorError> {
    return new ValueValidator<GValue | INullish, GError | IRequiredValidatorError>(((
      value: GValue | INullish,
      abortable: Abortable,
    ): AsyncTask<GError[]> | [IRequiredValidatorError] | [] => {
      return isNullish(value)
        ? [{ name: 'required' }]
        : (
          (validator === void 0)
            ? []
            : validator.validate(value, abortable)
        );
    }) as IValueValidatorInput<GValue | INullish, GError | IRequiredValidatorError>);
  }

  static optional<GValue, GError extends IValueValidatorError>(
    validator: ValueValidator<GValue, GError>,
  ): ValueValidator<GValue | INullish, GError> {
    return new ValueValidator<GValue | INullish, GError>(((
      value: GValue | INullish,
      abortable: Abortable,
    ): AsyncTask<GError[]> | [] => {
      return isNullish(value)
        ? []
        : validator.validate(value, abortable);
    }) as IValueValidatorInput<GValue | INullish, GError>);
  }

  static all<GFirstValidator extends IGenericValueValidator, GValidators extends IValueValidatorAllConstraint<GFirstValidator>>(
    firstValidator: GFirstValidator,
    ...validators: GValidators
  ): ValueValidator<InferValueValidatorAllValue<GFirstValidator>, InferValueValidatorAllError<GFirstValidator, GValidators>> {
    type GValue = any;
    type GError = any;

    return new ValueValidator<GValue, GError>((
      value: GValue,
      abortable: Abortable,
    ): AsyncTask<GError[]> => {
      return AsyncTask.all(
        ([firstValidator, ...validators] as ValueValidator<GValue, GError>[]).map((validator: ValueValidator<GValue, GError>): IAsyncTaskFactory<GError[]> => {
          return (abortable: Abortable): IAsyncTaskInput<GError[]> => {
            return validator.validate(value, abortable);
          };
        }),
        abortable,
      )
        .successful((errors: GError[][]): GError[] => {
          return errors.flat();
        });
    });
  }

  protected readonly _validator: IValueValidatorInput<GValue, GError>;

  constructor(
    validator: IValueValidatorInput<GValue, GError>,
  ) {
    this._validator = validator;
  }

  validate(
    value: GValue,
    abortable: Abortable = Abortable.never,
  ): AsyncTask<GError[]> {
    return AsyncTask.fromFactory<GError[]>((abortable: Abortable): IAsyncTaskInput<GError[]> => {
      return this._validator(value, abortable);
    }, abortable);
  }
}

export type IGenericValueValidator = ValueValidator<any, any>;
