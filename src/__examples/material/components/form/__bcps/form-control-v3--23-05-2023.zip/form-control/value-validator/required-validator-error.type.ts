import { IValueValidatorError } from './errors/value-validator-error.type';

export interface IRequiredValidatorError extends IValueValidatorError {
  readonly name: 'required';
}
