import { Abortable, AsyncTask } from '@lirx/async-task';
import { IValueValidatorError } from './errors/value-validator-error.type';

export interface ISyncValueValidator<GValue, GError extends IValueValidatorError> {
  (
    value: GValue,
    abortable: Abortable,
  ): GError[];
}

export interface IAsyncTaskValueValidator<GValue, GError extends IValueValidatorError> {
  (
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<GError[]>;
}

export interface IPromiseValueValidator<GValue, GError extends IValueValidatorError> {
  (
    value: GValue,
    abortable: Abortable,
  ): Promise<GError[]>;
}

export type IValueValidatorInput<GValue, GError extends IValueValidatorError> =
  | ISyncValueValidator<GValue, GError>
  | IAsyncTaskValueValidator<GValue, GError>
  | IPromiseValueValidator<GValue, GError>
  ;


