import { IEmptyStringValidatorError } from '../../errors/built-in/string/empty-string-validator-error.type';
import { IValueValidatorError } from '../../errors/value-validator-error.type';
import { ValueValidator } from '../../value-validator.class';
import { IPatternMismatchValidatorError } from '../../errors/built-in/string/pattern-mismatch-validator-error.type';
import { EMAIL_PATTERN } from './patterns/email-pattern.constant';

export class StringValidator<GError extends IValueValidatorError> extends ValueValidator<string, GError> {

  static notEmpty(): StringValidator<IEmptyStringValidatorError> {
    return new StringValidator<IEmptyStringValidatorError>((value: string): IEmptyStringValidatorError[] => {
      return (value === '')
        ? [{ name: 'empty' }]
        : [];
    });
  }

  static pattern(
    pattern: RegExp,
  ): StringValidator<IPatternMismatchValidatorError> {
    return new StringValidator<IPatternMismatchValidatorError>((value: string): IPatternMismatchValidatorError[] => {
      return pattern.test(value)
        ? []
        : [{ name: 'pattern-mismatch', pattern }];
    });
  }

  static email(): StringValidator<IPatternMismatchValidatorError> {
    return this.pattern(EMAIL_PATTERN);
  }
}
