import { IObservable } from '@lirx/core';

export type IAbstractFormControlValidityState =
  | 'validating'
  | 'valid'
  | 'invalid'
;

export abstract class AbstractFormControl<GName extends string> {
  protected readonly _name: GName;
  protected readonly _validityState$: IObservable<IAbstractFormControlValidityState>;

  protected constructor(
    name: GName,
    validityState$: IObservable<IAbstractFormControlValidityState>,
  ) {
    this._name = name;
    this._validityState$ = validityState$;
  }

  /* NAME */

  get name(): GName {
    return this._name;
  }

  /* VALIDITY */

  get validityState$(): IObservable<IAbstractFormControlValidityState> {
    return this._validityState$;
  }

  /* METHODS */

  abstract reset(): void;
}

export type IGenericAbstractFormControl = AbstractFormControl<string>;

export type InferAbstractFormControlName<GAbstractFormControl extends IGenericAbstractFormControl> =
  GAbstractFormControl extends AbstractFormControl<infer GName>
    ? GName
    : never
  ;
