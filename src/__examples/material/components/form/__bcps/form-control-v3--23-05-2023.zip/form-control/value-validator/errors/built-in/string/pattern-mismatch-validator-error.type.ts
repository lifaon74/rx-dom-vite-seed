import { IValueValidatorError } from '../../value-validator-error.type';

export interface IPatternMismatchValidatorError extends IValueValidatorError {
  readonly name: 'pattern-mismatch';
  readonly pattern: RegExp;
}
