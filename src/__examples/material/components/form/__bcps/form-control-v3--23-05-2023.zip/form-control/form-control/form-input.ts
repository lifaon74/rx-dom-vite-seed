import { Abortable, AsyncTask } from '@lirx/async-task';
import {
  combineLatest,
  createMulticastReplayLastSource,
  fromPromiseFactory,
  IFromPromiseFactoryObservableNotifications,
  IMapFilterMapFunctionReturn,
  IMulticastReplayLastSource,
  IObservable,
  IObserver, let$$,
  map$$,
  MAP_FILTER_DISCARD,
  mapFilter$$,
  readObservableValue,
  shareRL$$,
  switchMap$$,
  UNABLE_TO_READ_OBSERVABLE,
} from '@lirx/core';
import { IUnknownValidatorError } from '../value-validator/errors/built-in/unknown-validator-error.type';
import { IValueValidatorError } from '../value-validator/errors/value-validator-error.type';
import { IRequiredValidatorError } from '../value-validator/required-validator-error.type';
import { ValueValidator } from '../value-validator/value-validator.class';
import { AbstractFormControl, IAbstractFormControlValidityState } from './abstract-form-control';

export type IFormInputValidatorError<GError extends IValueValidatorError> =
  | GError
  | IRequiredValidatorError
  | IUnknownValidatorError
  ;
export type IFormInputValidatorErrors<GError extends IValueValidatorError> = IFormInputValidatorError<GError>[];

export interface IFormInputOptions<GValue, GError extends IValueValidatorError> {
  value?: GValue | null;
  disabled?: boolean;
  required?: boolean;
  validator?: ValueValidator<GValue | null, GError>;
}

export abstract class FormInput<GName extends string, GValue, GError extends IValueValidatorError> extends AbstractFormControl<GName> {

  protected readonly _$value$: IMulticastReplayLastSource<GValue | null>;
  protected readonly _$disabled$: IMulticastReplayLastSource<boolean>;
  protected readonly _$required$: IMulticastReplayLastSource<boolean>;

  protected readonly _validator$: IObservable<ValueValidator<GValue | null, GError | IRequiredValidatorError>>;
  protected readonly _validity$: IObservable<IFormInputValidatorErrors<GError>>;

  protected constructor(
    name: GName,
    {
      value = null,
      disabled = false,
      required = false,
      validator,
    }: IFormInputOptions<GValue, GError> = {},
  ) {
    const $value$ = createMulticastReplayLastSource<GValue | null>(value);
    const $disabled$ = createMulticastReplayLastSource<boolean>(disabled);
    const $required$ = createMulticastReplayLastSource<boolean>(required);

    const disabled$ = $disabled$.subscribe;
    const required$ = $required$.subscribe;

    const validator$ = map$$(
      combineLatest([disabled$, required$]),
      ([disabled, required]) => {
        return disabled
          ? ValueValidator.none<GValue | null>()
          : (
            required
              ? ValueValidator.required<GValue, GError>(validator)
              : (
                (validator === void 0)
                  ? ValueValidator.none<GValue | null>()
                  : validator
              )
          );
      },
    );

    const [$validityState, validityState$] = let$$<IAbstractFormControlValidityState>('pending');

    const validity$ = shareRL$$<IFormInputValidatorErrors<GError>>(
      switchMap$$(validator$, (validator: ValueValidator<GValue | null, GError | IRequiredValidatorError>): IObservable<IFormInputValidatorErrors<GError>> => {
        return switchMap$$(this.value$, (value: GValue | null): IObservable<IFormInputValidatorErrors<GError>> => {
          return mapFilter$$<IFromPromiseFactoryObservableNotifications<IFormInputValidatorErrors<GError>>, IFormInputValidatorErrors<GError>>(
            fromPromiseFactory<IFormInputValidatorErrors<GError>>((signal: AbortSignal): Promise<IFormInputValidatorErrors<GError>> => {
              $validityState('validating');
              return validator.validate(value, Abortable.fromAbortSignal(signal)).toPromise();
            }),
            (notification: IFromPromiseFactoryObservableNotifications<IFormInputValidatorErrors<GError>>): IMapFilterMapFunctionReturn<IFormInputValidatorErrors<GError>> => {
              switch (notification.name) {
                case 'next':
                  $validityState(
                    notification.value.length === 0
                      ? 'valid'
                      : 'invalid',
                  );
                  return notification.value;
                case 'error':
                  $validityState('invalid');
                  return [
                    {
                      name: 'unknown',
                      error: notification.value,
                    },
                  ];
                default:
                  return MAP_FILTER_DISCARD;
              }
            },
          );
        });
      }),
    );

    // const validityState$ = shareRL$$<boolean>(
    //   map$$(
    //     validity$,
    //     (errors: IFormInputValidatorErrors<GError>): boolean => {
    //       return errors.length === 0;
    //     },
    //   ),
    // );

    super(
      name,
      validityState$,
    );

    this._$value$ = $value$;
    this._$disabled$ = $disabled$;
    this._$required$ = $required$;
    this._validator$ = validator$;
    this._validity$ = validity$;
  }

  /* VALUE */

  get value(): GValue | null {
    return this._$value$.getValue();
  }

  set value(
    input: GValue | null,
  ) {
    this._$value$.emit(input);
  }

  get value$(): IObservable<GValue | null> {
    return this._$value$.subscribe;
  }

  get $value(): IObserver<GValue | null> {
    return this._$value$.emit;
  }

  /* DISABLED */

  get disabled(): boolean {
    return this._$disabled$.getValue();
  }

  set disabled(
    input: boolean,
  ) {
    this._$disabled$.emit(input);
  }

  get disabled$(): IObservable<boolean> {
    return this._$disabled$.subscribe;
  }

  get $disabled(): IObserver<boolean> {
    return this._$disabled$.emit;
  }

  /* REQUIRED */

  get required(): boolean {
    return this._$required$.getValue();
  }

  set required(
    input: boolean,
  ) {
    this._$required$.emit(input);
  }

  get required$(): IObservable<boolean> {
    return this._$required$.subscribe;
  }

  get $required(): IObserver<boolean> {
    return this._$required$.emit;
  }

  /* VALIDITY */

  get validity$(): IObservable<IFormInputValidatorErrors<GError>> {
    return this._validity$;
  }

  validate(
    abortable?: Abortable,
  ): AsyncTask<IFormInputValidatorErrors<GError>> {
    return readObservableValue(
      this._validator$,
      UNABLE_TO_READ_OBSERVABLE,
    ).validate(this.value, abortable);
  }

  /* METHODS */

  override reset(): void {
    this.value = null;
  }
}

export type IGenericFormInput = FormInput<string, any, any>;

