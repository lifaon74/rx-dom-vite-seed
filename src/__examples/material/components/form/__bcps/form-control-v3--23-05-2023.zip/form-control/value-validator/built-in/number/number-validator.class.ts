import { IValueValidatorError } from '../../errors/value-validator-error.type';
import { ValueValidator } from '../../value-validator.class';
import { INotANumberValidatorError } from '../../errors/built-in/number/not-a-number-validator-error.type';

export class NumberValidator<GError extends IValueValidatorError> extends ValueValidator<number, GError> {
  static isValid(): NumberValidator<INotANumberValidatorError> {
    return new NumberValidator<INotANumberValidatorError>((value: number): INotANumberValidatorError[] => {
      return Number.isNaN(value)
        ? [{ name: 'not-a-number' }]
        : [];
    });
  }
}
