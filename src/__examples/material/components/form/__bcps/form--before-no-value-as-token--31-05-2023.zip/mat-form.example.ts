import { freeze } from '@lirx/core';
import { formControlExample } from './form-control/form-control.example';
import { matInputFieldExample } from './input-field/mat-input-field.example';
import { matInputTextExample } from './mat-input/mat-input-text.example';
// import { matInputTextExample } from './input-text/mat-input-text.example';


/*---------*/

export function matFormExample() {
  // matInputValidatorExample();
  // matFormFieldExample();
  // matInputFieldExample();
  // matInputTextExample();
  formControlExample();
  // matInputTextExample();
}
