import { IObservable, map$$, switchMap$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { IGenericFormInputText } from '../../../form-control/form-input/built-in/form-input-text/form-input-text.class';
import { MatInputFullModifier } from '../../fragments/mat-input-full/mat-input-full.modifier';

// @ts-ignore
import html from './mat-input-text.component.html?raw';
// @ts-ignore
import style from './mat-input-text.component.scss?inline';

/**
 * COMPONENT: 'mat-input-text'
 */

interface IData {
  readonly name$: IObservable<string>;
  readonly disabled$: IObservable<boolean>;
  readonly readonly$: IObservable<boolean>;
}

interface IMatInputTextComponentConfig {
  element: HTMLElement;
  inputs: [
    ['controller', IGenericFormInputText],
  ];
  data: IData;
}

export const MatInputTextComponent = createComponent<IMatInputTextComponentConfig>({
  name: 'mat-input-text',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    modifiers: [
      // MatInputModifier,
      // MatInputDisabledModifier,
      MatInputFullModifier,
    ],
  }),
  styles: [
    compileStyleAsComponentStyle(style),
  ],
  inputs: [
    ['controller'],
  ],
  init: (node: VirtualCustomElementNode<IMatInputTextComponentConfig>): IData => {
    const controller$ = node.inputs.get$('controller');

    const name$ = map$$(controller$, controller => controller.name);
    const disabled$ = switchMap$$(controller$, controller => controller.disabled$);
    const readonly$ = switchMap$$(controller$, controller => controller.readonly$);

    return {
      name$,
      disabled$,
      readonly$,
    };
  },
});



