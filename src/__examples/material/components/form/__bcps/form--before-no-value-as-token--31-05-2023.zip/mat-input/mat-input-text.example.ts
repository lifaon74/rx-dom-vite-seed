import { IObservable, single } from '@lirx/core';
import { bootstrap, compileReactiveHTMLAsComponentTemplate, createComponent } from '@lirx/dom';
import { FormInputText } from '../form-control/form-input/built-in/form-input-text/form-input-text.class';
import { MatInputTextComponent } from './built-in/mat-input-text/mat-input-text.component';

interface IMatInputTextComponentConfig {
  element: HTMLElement;
  data: {
    controller$: IObservable<FormInputText<string>>
  };
}

const MatInputTextExampleComponent = createComponent<IMatInputTextComponentConfig>({
  name: 'mat-input-text-example',
  template: compileReactiveHTMLAsComponentTemplate({
    html: `
      <form>
        <mat-input-text
          $[controller]="$.controller$"
        ></mat-input-text>
        <button type="reset">RESET</button>
      </form>
    `,
    customElements: [
      MatInputTextComponent,
    ],
  }),
  init: () => {
    const controller = new FormInputText('abc', {});

    (window as any).controller = controller;

    return {
      controller$: single(controller),
    };
  },
});

/*----------*/

export function matInputTextExample(): void {
  bootstrap(MatInputTextExampleComponent);
}
