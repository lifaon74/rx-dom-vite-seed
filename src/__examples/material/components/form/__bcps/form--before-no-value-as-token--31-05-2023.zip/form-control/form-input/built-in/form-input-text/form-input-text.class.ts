import { IObservable, IObserver, readObservableValue, UNABLE_TO_READ_OBSERVABLE } from '@lirx/core';
import { mapDistinctShareRL$$ } from '../../../../misc/map-distinct-share-replay-last-observable';
import { IFormInputWithConstraintBuilderOptions } from '../../shared/form-input-with-constraint-builder.class';
import { FormInputWithRequiredConstraintBuilder } from '../../shared/form-input-with-required-constraint-builder.class';
import { formInputTextConstraint, IFormInputTextConstraint, IFormInputTextConstraintOptions } from './form-input-text-constraint';


export interface IFormInputTextOptions extends IFormInputWithConstraintBuilderOptions<string, IFormInputTextConstraint, IFormInputTextConstraintOptions> {

}

export class FormInputText<GName extends string> extends FormInputWithRequiredConstraintBuilder<GName, string, IFormInputTextConstraint, IFormInputTextConstraintOptions> {
  protected readonly _minLength$: IObservable<number>;
  protected readonly _$minLength: IObserver<number>;

  protected readonly _maxLength$: IObservable<number>;
  protected readonly _$maxLength: IObserver<number>;

  protected readonly _pattern$: IObservable<RegExp>;
  protected readonly _$pattern: IObserver<RegExp>;

  constructor(
    name: GName,
    options?: IFormInputTextOptions,
  ) {
    super(name, formInputTextConstraint, options);

    this._minLength$ = mapDistinctShareRL$$(this.constraint$, (constraint: IFormInputTextConstraint): number => {
      return constraint.properties.minLength;
    });

    this._$minLength = (minLength: number): void => {
      this.updateConstraint({
        minLength,
      });
    };

    this._maxLength$ = mapDistinctShareRL$$(this.constraint$, (constraint: IFormInputTextConstraint): number => {
      return constraint.properties.maxLength;
    });

    this._$maxLength = (maxLength: number): void => {
      this.updateConstraint({
        maxLength,
      });
    };

    this._pattern$ = mapDistinctShareRL$$(this.constraint$, (constraint: IFormInputTextConstraint): RegExp => {
      return constraint.properties.pattern;
    });

    this._$pattern = (pattern: RegExp): void => {
      this.updateConstraint({
        pattern,
      });
    };
  }

  /* MIN LENGTH */

  get minLength(): number {
    return readObservableValue(
      this._minLength$,
      UNABLE_TO_READ_OBSERVABLE,
    );
  }

  set minLength(
    input: number,
  ) {
    this._$minLength(input);
  }

  get minLength$(): IObservable<number> {
    return this._minLength$;
  }

  get $minLength(): IObserver<number> {
    return this._$minLength;
  }

  /* MAX LENGTH */

  get maxLength(): number {
    return readObservableValue(
      this._maxLength$,
      UNABLE_TO_READ_OBSERVABLE,
    );
  }

  set maxLength(
    input: number,
  ) {
    this._$maxLength(input);
  }

  get maxLength$(): IObservable<number> {
    return this._maxLength$;
  }

  get $maxLength(): IObserver<number> {
    return this._$maxLength;
  }

  /* PATTERN */

  get pattern(): RegExp {
    return readObservableValue(
      this._pattern$,
      UNABLE_TO_READ_OBSERVABLE,
    );
  }

  set pattern(
    input: RegExp,
  ) {
    this._$pattern(input);
  }

  get pattern$(): IObservable<RegExp> {
    return this._pattern$;
  }

  get $pattern(): IObserver<RegExp> {
    return this._$pattern;
  }
}

export type IGenericFormInputText = FormInputText<any>;
