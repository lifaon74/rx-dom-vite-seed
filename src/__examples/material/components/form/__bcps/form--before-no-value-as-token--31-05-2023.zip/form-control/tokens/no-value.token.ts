export const NO_VALUE_TOKEN = Symbol('NOT_VALUE');

export type INoValueToken = typeof NO_VALUE_TOKEN;
