export const INVALID_VALUE_TYPE_TOKEN = Symbol('INVALID_VALUE_TYPE');

export type IInvalidValueTypeToken = typeof INVALID_VALUE_TYPE_TOKEN;
