import { INullish, isNullish } from '@lirx/utils';
import { IConstraint, IConstraintTestFunctionResult } from '../../constraint/constraint.type';
import { createConstraint } from '../../constraint/create-constraint';

export interface IRequiredConstraintProperties {
  readonly required: boolean;
}

export function requiredConstraint<GValue, GProperties extends object>(
  required: boolean,
  {
    test,
    properties,
  }: IConstraint<GValue, GProperties>,
): IConstraint<GValue | INullish, GProperties & IRequiredConstraintProperties> {
  return createConstraint<GValue | INullish, GProperties & IRequiredConstraintProperties>(
    (value: GValue | INullish): IConstraintTestFunctionResult<GProperties & IRequiredConstraintProperties> => {
      return isNullish(value)
        ? (required ? ['required'] : [])
        : test(value);
    },
    {
      ...properties,
      required,
    },
  );
}
