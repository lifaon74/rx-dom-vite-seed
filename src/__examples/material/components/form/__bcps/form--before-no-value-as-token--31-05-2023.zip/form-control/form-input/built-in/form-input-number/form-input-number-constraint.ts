import { INullish } from '@lirx/utils';
import { IIsNumberConstraintProperties, isNumberConstraint } from '../../../constraints/built-in/number/is-number-constraint';
import { INumberRangeConstraintProperties, numberRangeConstraint } from '../../../constraints/built-in/number/number-range-constraint';
import { IRequiredConstraintProperties, requiredConstraint } from '../../../constraints/built-in/other/required-constraint';
import { IConstraint } from '../../../constraints/constraint/constraint.type';
import { multipleConstraints } from '../../../constraints/multiple/multiple-constraints';

export interface IFormInputNumberConstraintProperties extends //
  IRequiredConstraintProperties,
  IIsNumberConstraintProperties,
  INumberRangeConstraintProperties
  //
{
}

export type IFormInputNumberConstraintOptions = Partial<IFormInputNumberConstraintProperties>;
export type IFormInputNumberConstraint = IConstraint<number | INullish, IFormInputNumberConstraintProperties>;

export function formInputNumberConstraint(
  {
    required = false,
    min,
    max,
    step,
  }: IFormInputNumberConstraintOptions = {},
): IFormInputNumberConstraint {

  const constraints: IConstraint<number, any>[] = [
    isNumberConstraint(),
  ];

  if (
    (min !== void 0)
    || (max !== void 0)
    || (step !== void 0)
  ) {
    constraints.push(
      numberRangeConstraint({
        min,
        max,
        step,
      }),
    );
  }

  return requiredConstraint(
    required,
    multipleConstraints(
      'sequential',
      constraints,
    ),
  );
}


// export function formInputNumberConstraint(
//   {
//     required = false,
//     min,
//     max,
//     step,
//   }: IFormInputNumberConstraintOptions = {},
// ): IConstraint<number | INullish, IFormInputNumberConstraintProperties> {
//   return requiredConstraint(
//     required,
//     groupConstraints(
//       'sequential',
//       isNumberConstraint(),
//       numberRangeConstraint({
//         min,
//         max,
//         step,
//       }),
//     ),
//   );
// }
