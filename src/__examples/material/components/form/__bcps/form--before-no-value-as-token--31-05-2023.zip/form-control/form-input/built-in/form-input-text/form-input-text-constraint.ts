import { INullish } from '@lirx/utils';
import { IRequiredConstraintProperties, requiredConstraint } from '../../../constraints/built-in/other/required-constraint';
import { IMaxLengthConstraintProperties, maxLengthConstraint } from '../../../constraints/built-in/string/max-length-constraint';
import { IMinLengthConstraintProperties, minLengthConstraint } from '../../../constraints/built-in/string/min-length-constraint';
import { IPatternConstraintProperties, patternConstraint } from '../../../constraints/built-in/string/pattern-constraint';
import { IConstraint } from '../../../constraints/constraint/constraint.type';
import { NO_CONSTRAINT } from '../../../constraints/constraint/no-constraint.constant';
import { multipleConstraints } from '../../../constraints/multiple/multiple-constraints';

export interface IFormInputTextConstraintProperties extends //
  IRequiredConstraintProperties,
  IMinLengthConstraintProperties,
  IMaxLengthConstraintProperties,
  IPatternConstraintProperties
  //
{
}

export type IFormInputTextConstraintOptions = Partial<IFormInputTextConstraintProperties>;
export type IFormInputTextConstraint = IConstraint<string | INullish, IFormInputTextConstraintProperties>;

export function formInputTextConstraint(
  {
    required = false,
    minLength,
    maxLength,
    pattern,
  }: IFormInputTextConstraintOptions = {},
): IFormInputTextConstraint {

  const constraints: IConstraint<string, any>[] = [];

  if (minLength !== void 0) {
    constraints.push(minLengthConstraint(minLength));
  }

  if (maxLength !== void 0) {
    constraints.push(maxLengthConstraint(maxLength));
  }

  if (pattern !== void 0) {
    constraints.push(patternConstraint(pattern));
  }

  return requiredConstraint(
    required,
    (constraints.length === 0)
      ? NO_CONSTRAINT
      : multipleConstraints(
        'sequential',
        constraints,
      ),
  );
}

// export function formInputTextConstraint(
//   {
//     required = false,
//     minLength = 0,
//     maxLength = Number.POSITIVE_INFINITY,
//     pattern = /.*/,
//   }: IFormInputTextConstraintOptions = {},
// ): IFormInputTextConstraint {
//     return requiredConstraint(
//       required,
//       groupConstraints(
//         'sequential',
//         minLengthConstraint(minLength),
//         maxLengthConstraint(maxLength),
//         patternConstraint(pattern),
//       ),
//     );
// }
