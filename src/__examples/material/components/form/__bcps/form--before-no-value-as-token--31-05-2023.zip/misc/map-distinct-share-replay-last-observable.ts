import { mapDistinct$$, mapDistinctObservable, shareObservableWithMulticastReplayLastSource, shareRL$$ } from '@lirx/core';
import { IObservable } from '@lirx/core/src/observable/type/observable.type';
import { IMapFunction } from '@lirx/core/src/observer/pipes/built-in/map/map-function.type';

export function mapDistinctShareReplayLastObservable<GIn, GOut>(
  subscribe: IObservable<GIn>,
  mapFunction: IMapFunction<GIn, GOut>,
): IObservable<GOut> {
  return shareObservableWithMulticastReplayLastSource<GOut>(
    mapDistinctObservable<GIn, GOut>(subscribe, mapFunction),
  );
}


export const mapDistinctShareRL$$ = mapDistinctShareReplayLastObservable;
