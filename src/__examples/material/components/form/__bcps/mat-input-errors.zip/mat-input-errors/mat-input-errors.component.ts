import { IObservable, map$$, single, switchMap$$ } from '@lirx/core';
import { compileStyleAsComponentStyle, createComponent, INJECT_CONTENT_TEMPLATE, VirtualCustomElementNode } from '@lirx/dom';
import { IGenericFormInput } from '../../form-control/form-input/form-input.class';

// @ts-ignore
import style from './mat-input-errors.component.scss?inline';

/**
 * COMPONENT: 'mat-input-errors'
 */

interface IMatInputErrorsComponentConfig {
  element: HTMLElement;
  inputs: [
    ['controller', IGenericFormInput],
  ];
}

export const MatInputErrorsComponent = createComponent<IMatInputErrorsComponentConfig>({
  name: 'mat-input-errors',
  template: INJECT_CONTENT_TEMPLATE,
  styles: [
    compileStyleAsComponentStyle(style),
  ],
  inputs: [
    ['controller'],
  ],
  init: (node: VirtualCustomElementNode<IMatInputErrorsComponentConfig>): void => {
    const controller$ = node.inputs.get$('controller');

    // const validity$ = switchMap$$(controller$, controller => controller.validity$);
    // node.setReactiveClass('mat--required', validity$);
  },
});



