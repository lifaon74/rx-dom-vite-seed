import { createMulticastSource, debounceTime$$, first$$, function$$, IObservable, IObserver, map$$, mergeMapS$$, noop } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
  virtualDOMNodeQuerySelectorIterator,
} from '@lirx/dom';
import {
  filter$$,
} from '../../../../../../../../../lirx/core/dist/src/observable/pipes/built-in/without-notifications/observer-pipe-related/filter/filter-observable.shortcut';
import { MatBasicButtonSecondaryComponent } from '../../../../buttons/button/built-in/basic/secondary/mat-basic-button-secondary.component';
import { closeMatOverlayWithAnimation } from '../../helpers/close-mat-overlay-with-animation';
import { openMatOverlayWithAnimation } from '../../helpers/open-mat-overlay-with-animation';

// @ts-ignore
import html from './mat-snackbar.component.html?raw';
// @ts-ignore
import style from './mat-snackbar.component.scss?inline';

/** TYPES **/

export type IMatSnackbarComponentOptionsHorizontalPosition =
  | 'left'
  | 'center'
  | 'right'
  ;

export type IMatSnackbarComponentOptionsVerticalPosition =
  | 'top'
  | 'bottom'
  ;

export type IMatSnackbarComponentOptionsWidth =
  | 'auto'
  | 'static'
  ;

export interface IMatSnackbarComponentOptionsPosition {
  horizontal: IMatSnackbarComponentOptionsHorizontalPosition;
  vertical: IMatSnackbarComponentOptionsVerticalPosition;
}

export interface IMatSnackbarComponentOptionsAction {
  text: string;
  onClick?: IObserver<MouseEvent>;
}

export interface IMatSnackbarComponentOptions {
  message: string;
  position?: IMatSnackbarComponentOptionsPosition;
  width?: IMatSnackbarComponentOptionsWidth;
  action?: IMatSnackbarComponentOptionsAction;
}

/**
 * COMPONENT: 'mat-snackbar'
 */

interface IData {
  readonly message$: IObservable<string>;
  readonly hasAction$: IObservable<boolean>;
  readonly actionText$: IObservable<string>;
  readonly $onClickActionButton: IObserver<MouseEvent>;
}

export interface IMatSnackbarComponentConfig {
  element: HTMLElement;
  inputs: [
    ['options', IMatSnackbarComponentOptions],
  ];
  data: IData;
}

export const MatSnackbarComponent = createComponent<IMatSnackbarComponentConfig>({
  name: 'mat-snackbar',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatBasicButtonSecondaryComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['options'],
  ],
  init: (node: VirtualCustomElementNode<IMatSnackbarComponentConfig>): IData => {

    // OPTIONS
    const $options = node.inputs.get$('options');

    const message$ = map$$($options, (options: IMatSnackbarComponentOptions): string => options.message);
    const hasAction$ = map$$($options, (options: IMatSnackbarComponentOptions): boolean => (options.action !== void 0));
    const actionText$ = map$$($options, (options: IMatSnackbarComponentOptions): string => (options.action?.text ?? ''));

    const $onClickActionButton = (event: MouseEvent): void => {
      node.inputs.get('options').action?.onClick?.(event);
      $onCloseTriggered();
    };

    // POSITION
    const horizontalPosition$ = map$$($options, (options: IMatSnackbarComponentOptions): IMatSnackbarComponentOptionsHorizontalPosition => options.position?.horizontal ?? 'left');
    const verticalPosition$ = map$$($options, (options: IMatSnackbarComponentOptions): IMatSnackbarComponentOptionsVerticalPosition => options.position?.vertical ?? 'bottom');
    const width$ = map$$($options, (options: IMatSnackbarComponentOptions): IMatSnackbarComponentOptionsWidth => options.width ?? 'auto');

    const classList$ = function$$(
      [horizontalPosition$, verticalPosition$, width$],
      (horizontalPosition, verticalPosition, width) => {
        return new Set([
          `mat-position-${horizontalPosition}`,
          `mat-position-${verticalPosition}`,
          `mat-width-${width}`,
        ]);
      },
    );
    node.setReactiveClassNamesList(classList$);


    // OPEN / CLOSE
    const { emit: $onCloseTriggered, subscribe: onCloseTriggered$ } = createMulticastSource<void>();

    const open$ = openMatOverlayWithAnimation(node);

    const onClose$ = mergeMapS$$(
      first$$(onCloseTriggered$),
      (): IObservable<void> => {
        return closeMatOverlayWithAnimation(node);
      },
    );

    open$(noop);
    
    onClose$((): void => {
      node.detach();
      // node.outputs.set('close', void 0);
    });

    return {
      message$,
      hasAction$,
      actionText$,
      $onClickActionButton,
    };
  },
});
