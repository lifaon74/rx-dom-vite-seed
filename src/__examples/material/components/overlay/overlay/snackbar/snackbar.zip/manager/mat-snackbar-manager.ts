import { empty, IObservable } from '@lirx/core';
import { VirtualCustomElementNode } from '@lirx/dom';
import { MatOverlayManager } from '../../../manager/mat-overlay-manager';
import { IMatSnackbarComponentOptions, MatSnackbarComponent } from '../snackbar/mat-snackbar.component';

// // @ts-ignore
// import style from './mat-overlay-manager.scss?inline';

export type IMatSnackbarState =
  | 'opening'
  | 'opened'
  | 'closing'
  | 'closed'
  ;

export interface IMatSnackbarManagerClose {
  (): void;
}

export interface IMatSnackbarManagerOpenResult {
  node: VirtualCustomElementNode<any>; // TODO
  close: IMatSnackbarManagerClose;
  state$: IObservable<IMatSnackbarState>;
}

export class MatSnackbarManager {

  protected readonly _manager: MatOverlayManager;

  constructor(
    manager: MatOverlayManager,
  ) {
    this._manager = manager;
  }

  get manager(): MatOverlayManager {
    return this._manager;
  }

  open(
    options: IMatSnackbarComponentOptions,
  ): IMatSnackbarManagerOpenResult {
    const node = this.manager.open(MatSnackbarComponent);
    node.inputs.set('options', options);

    const close = () => {

    };

    const state$ = empty<IMatSnackbarState>();

    return {
      node,
      close,
      state$,
    };
  }
}
