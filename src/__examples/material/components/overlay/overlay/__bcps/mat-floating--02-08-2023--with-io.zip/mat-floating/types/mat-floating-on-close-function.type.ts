import { IMatFloatingComponentCloseType } from './mat-floating-component-close-type.type';

export interface IMatFloatingOnCloseFunction {
  (
    type: IMatFloatingComponentCloseType,
  ): void;
}
