import { ComputePositionConfig } from '@floating-ui/dom';

export type IMatFloatingOptions = Partial<ComputePositionConfig>;
