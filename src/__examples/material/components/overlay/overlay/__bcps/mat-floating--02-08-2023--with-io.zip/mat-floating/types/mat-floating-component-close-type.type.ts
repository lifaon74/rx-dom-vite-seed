import { IMatFloatingContainerComponentCloseType } from '../../../fragments/mat-floating-container/mat-floating-container.component';

export type IMatFloatingComponentCloseType = IMatFloatingContainerComponentCloseType;
