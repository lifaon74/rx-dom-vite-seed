import { ReferenceElement } from '@floating-ui/dom';
import { IGenericVirtualReactiveElementNode, VirtualReactiveElementNode } from '@lirx/dom';

export type IMatFloatingReference =
  | ReferenceElement
  | IGenericVirtualReactiveElementNode
  ;

export function matFloatingReferenceToReferenceElement(
  input: IMatFloatingReference,
): ReferenceElement {
  if (input instanceof VirtualReactiveElementNode) {
    return input.elementNode;
  } else {
    return input;
  }
}
