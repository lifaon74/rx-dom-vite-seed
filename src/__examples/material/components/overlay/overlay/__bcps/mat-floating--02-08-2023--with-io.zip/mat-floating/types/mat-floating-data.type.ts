import { IMatFloatingReference } from './mat-floating-reference.type';
import { IMatFloatingOptions } from './mat-floating-options.type';
import { IMatFloatingOnCloseFunction } from './mat-floating-on-close-function.type';
import { IObservableLike } from '@lirx/core';

export interface IMatFloatingData {
  reference: IObservableLike<IMatFloatingReference>;
  options: IObservableLike<IMatFloatingOptions>;
  onClose?: IMatFloatingOnCloseFunction;
}
