import {
  combineLatestSpread,
  createUnicastReplayLastSource,
  debounceMicrotask$$,
  IObservable,
  IObserver,
  map$$,
  switchMap$$,
} from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { ElementReferenceModifier } from '@lirx/dom-material';
import {
  MatFloatingContentComponent,
} from '../../fragments/mat-floating-container/fragments/mat-floating-content/mat-floating-content.component';
import {
  IMatFloatingContainerComponentCloseType,
  MatFloatingContainerComponent,
} from '../../fragments/mat-floating-container/mat-floating-container.component';
import { createFloatingElementObservable, IFloatingElementPosition } from '../../functions/create-floating-element-observable';
import { IUnsubscribe } from '@lirx/utils';
import { matFloatingReferenceToReferenceElement, IMatFloatingReference } from './types/mat-floating-reference.type';
import { IMatFloatingOptions } from './types/mat-floating-options.type';
import { IMatFloatingComponentCloseType } from './types/mat-floating-component-close-type.type';

// @ts-ignore
import html from './mat-floating.component.html?raw';
// @ts-ignore
import style from './mat-floating.component.scss?inline';

/**
 * COMPONENT: 'mat-floating'
 */


interface IData {
  readonly $onMatFloatingContainerClose: IObserver<IMatFloatingContainerComponentCloseType>;
  readonly $matFloatingContentElement: IObserver<HTMLElement>;
}

export type IMatFloatingComponentInputs =
  | ['reference', IMatFloatingReference]
  | ['options', IMatFloatingOptions]
  ;

export type IMatFloatingComponentOutputs =
  | ['close', IMatFloatingComponentCloseType]
  ;

export interface IMatFloatingComponentConfig {
  element: HTMLElement;
  inputs: IMatFloatingComponentInputs;
  outputs: IMatFloatingComponentOutputs;
  data: IData;
}

export const MatFloatingComponent = createComponent<IMatFloatingComponentConfig>({
  name: 'mat-floating',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatFloatingContainerComponent,
      MatFloatingContentComponent,
    ],
    modifiers: [
      ElementReferenceModifier,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['reference'],
    ['options'],
  ],
  outputs: [
    ['close'],
  ],
  init: (node: VirtualCustomElementNode<IMatFloatingComponentConfig>): IData => {
    // INPUTS
    const reference$ = node.inputs.get$('reference');
    const options$ = node.inputs.get$('options');

    // OUTPUTS
    const $close = node.outputs.$set('close');

    // CLOSE
    const $onMatFloatingContainerClose = $close;

    // POSITION
    const referenceNormalized$ = map$$(reference$, matFloatingReferenceToReferenceElement);

    const {
      emit: $matFloatingContentElement,
      subscribe: matFloatingContentElement$,
    } = createUnicastReplayLastSource<HTMLElement>();

    const position$ = switchMap$$(
      debounceMicrotask$$(combineLatestSpread(referenceNormalized$, matFloatingContentElement$, options$)),
      ([reference, matFloatingContentElement, options]): IObservable<IFloatingElementPosition> => {
        return createFloatingElementObservable(reference, matFloatingContentElement, options);
      },
    );

    node.onConnected((): IUnsubscribe => {
      return position$(({ x, y, floating }: IFloatingElementPosition): void => {
        Object.assign(floating.style, {
          left: `${x}px`,
          top: `${y}px`,
        });
      });
    });

    return {
      $onMatFloatingContainerClose,
      $matFloatingContentElement,
    };
  },
});
