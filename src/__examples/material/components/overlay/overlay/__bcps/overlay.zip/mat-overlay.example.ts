import {
  applyCreateComponentStyles,
  IComponentConfig,
  IComponentInitFunction,
  IComponentStyle,
  IComponentTemplate,
  ICreateComponentOptions,
  InferComponentConfigData,
  InferComponentInitFunctionReturn,
  InferComponentInitInterface,
  injectCreateComponentTemplate,
  IResolveCreateComponentOptions,
  IVirtualCustomElementNodeConfig,
  IVirtualCustomElementNodeOptions,
  IVirtualCustomElementNodeSlotsMap,
  PartialInterfaceIfDataIsUndefined,
  resolveCreateComponent,
  resolveCreateComponentInit,
  VirtualCustomElementNode, VirtualDOMNode, VirtualRootNode,
} from '@lirx/dom';
import { IMulticastReplayLastSource, IObservable, let$$, map$$ } from '@lirx/core';


/*----------------------------*/

export type IMatOverlayState =
  | 'pending'
  | 'opened'
  | 'closed'
  ;

export class MatOverlay<GConfig extends IComponentConfig> extends VirtualCustomElementNode<GConfig> {
  protected _$state$: IMulticastReplayLastSource<IMatOverlayState>;
  protected _closed$: IObservable<boolean>;


  constructor(
    options: IVirtualCustomElementNodeOptions<GConfig>,
  ) {
    super(options);
    this._$state$ = let$$<IMatOverlayState>('pending');
    this._closed$ = map$$(this._$state$.subscribe, (state: IMatOverlayState) => (state === 'closed'));
  }

  get closed(): boolean {
    return (this._$state$.getValue() !== 'opened');
  }

  get closed$(): IObservable<boolean> {
    return this._closed$;
  }

  override attach(
    parentNode: VirtualDOMNode,
  ): boolean {
    if (
      (parentNode === getMatOverlayManager())
      && (this._$state$.getValue() === 'pending')
    ) {
      this._$state$.emit('opened');
      return super.attach(parentNode);
    } else {
      throw new Error(`Cannot attach this node`);
    }
  }

  override detach(): boolean {
    if (this._$state$.getValue() === 'opened') {
      this._$state$.emit('closed');
      return super.detach();
    } else {
      throw new Error(`Cannot detach this node`);
    }
  }

  close(): void {
    this.detach();
  }
}



export interface IMatOverlayComponentInitFunction<GConfig extends IComponentConfig> {
  (node: MatOverlay<GConfig>): ReturnType<IComponentInitFunction<GConfig>>;
}

export declare type InferMatOverlayComponentInitInterface<GConfig extends IComponentConfig> = PartialInterfaceIfDataIsUndefined<GConfig['data'], {
  init: IMatOverlayComponentInitFunction<GConfig>;
}>;

export type ICreateMatOverlayComponentOptions<GConfig extends IComponentConfig> =
  Omit<ICreateComponentOptions<GConfig>, 'init'>
  & InferMatOverlayComponentInitInterface<GConfig>;



export interface IMatOverlayOpenFunction<GConfig extends IVirtualCustomElementNodeConfig> {
  (
    slots?: IVirtualCustomElementNodeSlotsMap,
  ): MatOverlay<GConfig>;
}

export interface IMatOverlayComponent<GConfig extends IVirtualCustomElementNodeConfig> {
  readonly name: string;
  readonly open: IMatOverlayOpenFunction<GConfig>;
}

export function createMatOverlayComponent<GConfig extends IComponentConfig>(
  {
    name,
    ...options
  }: ICreateMatOverlayComponentOptions<GConfig>,
): IMatOverlayComponent<GConfig> {
  const open = (
    slots: IVirtualCustomElementNodeSlotsMap = new Map(),
  ): MatOverlay<GConfig> => {

    const node = new MatOverlay<GConfig>({
      ...options,
      name,
      slots,
    } as IVirtualCustomElementNodeOptions<GConfig>);

    resolveCreateComponent({
      ...options,
      node,
      slots,
    } as IResolveCreateComponentOptions<GConfig>);

    node.attach(getMatOverlayManager());

    return node;
  };

  return {
    name,
    open,
  };
}



/*----------------------------*/

// @ts-ignore
import style from './manager/mat-overlay-manager.component.scss?inline';

let MAT_OVERLAY_MANAGER: VirtualRootNode<HTMLElement>;


export function initMatOverlayManager(
  element: HTMLElement,
): void {
  if (MAT_OVERLAY_MANAGER === void 0) {
    MAT_OVERLAY_MANAGER = new VirtualRootNode<HTMLElement>(element);

    const styleElement = document.createElement('style');

    styleElement.setAttribute('host', 'mat-overlay-manager');
    styleElement.textContent = style;
    document.head.appendChild(styleElement);

    element.setAttribute('mat-overlay-manager', '');
  } else {
    throw new Error('MatOverlayManager is already initialized');
  }
}

export function createMatOverlayManager(): void {
  const matOverlayManagerElement = document.createElement('mat-overlay-manager');
  initMatOverlayManager(matOverlayManagerElement);
  document.body.appendChild(matOverlayManagerElement);
}

export function getMatOverlayManager(): VirtualRootNode<HTMLElement> {
  if (MAT_OVERLAY_MANAGER === void 0) {
    throw new Error('MatOverlayManager is not initialized');
  } else {
    return MAT_OVERLAY_MANAGER;
  }
}

/*----------------------------*/

export function matOverlayExample(): void {
  createMatOverlayManager();

  const MyModalComponent = createMatOverlayComponent({
    name: 'my-modal',
  });

  const modal = MyModalComponent.open();
  window.onclick = () => modal.close();
}
