import { ComputePositionConfig, ReferenceElement } from '@floating-ui/dom';
import {
  combineLatestSpread,
  createUnicastReplayLastSource,
  debounceMicrotask$$,
  IObservable,
  IObserver,
  map$$,
  switchMap$$,
} from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent, IGenericVirtualReactiveElementNode,
  VirtualCustomElementNode, VirtualReactiveElementNode,
} from '@lirx/dom';
import { ElementReferenceModifier } from '@lirx/dom-material';
import {
  MatFloatingContentComponent,
} from '../../fragments/mat-floating-container/fragments/mat-floating-content/mat-floating-content.component';
import {
  IMatFloatingContainerComponentCloseType,
  MatFloatingContainerComponent,
} from '../../fragments/mat-floating-container/mat-floating-container.component';
import { createFloatingElementObservable, IFloatingElementPosition } from '../../functions/create-floating-element-observable';

// @ts-ignore
import html from './mat-floating.component.html?raw';
// @ts-ignore
import style from './mat-floating.component.scss?inline';

/** TYPES **/

export type IMatFloatingComponentCloseType = IMatFloatingContainerComponentCloseType;

export type IMatFloatingReference =
  | ReferenceElement
  | IGenericVirtualReactiveElementNode
  ;

export function matFloatingReferenceToReferenceElement(
  input: IMatFloatingReference,
): ReferenceElement {
  if (input instanceof VirtualReactiveElementNode) {
    return input.elementNode;
  } else {
    return input;
  }
}


export type IMatFloatingOptions = Partial<ComputePositionConfig>;

/**
 * COMPONENT: 'mat-floating'
 */

interface IData {
  readonly $close: IObserver<IMatFloatingContainerComponentCloseType>;
  readonly $matFloatingContentElement: IObserver<HTMLElement>;
}

export interface IMatFloatingComponentConfig {
  element: HTMLElement;
  inputs: [
    ['reference', IMatFloatingReference],
    ['options', IMatFloatingOptions],
  ],
  outputs: [
    ['close', IMatFloatingComponentCloseType],
  ],
  data: IData;
}

export const MatFloatingComponent = createComponent<IMatFloatingComponentConfig>({
  name: 'mat-floating',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatFloatingContainerComponent,
      MatFloatingContentComponent,
    ],
    modifiers: [
      ElementReferenceModifier,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['reference'],
    ['options'],
  ],
  outputs: [
    ['close'],
  ],
  init: (node: VirtualCustomElementNode<IMatFloatingComponentConfig>): IData => {
    /* CLOSE */

    const $close = node.outputs.$set('close');

    /* POSITION */

    const reference$ = node.inputs.get$('reference');
    const options$ = node.inputs.get$('options');

    const referenceElement$ = map$$(reference$, matFloatingReferenceToReferenceElement);

    const {
      emit: $matFloatingContentElement,
      subscribe: matFloatingContentElement$,
    } = createUnicastReplayLastSource<HTMLElement>();

    const position$ = switchMap$$(
      debounceMicrotask$$(combineLatestSpread(referenceElement$, matFloatingContentElement$, options$)),
      ([referenceElement, matFloatingContentElement, options]): IObservable<IFloatingElementPosition> => {
        return createFloatingElementObservable(referenceElement, matFloatingContentElement, options);
      },
    );

    node.onConnected$(position$)(({ x, y, floating }: IFloatingElementPosition): void => {
      Object.assign(floating.style, {
        left: `${x}px`,
        top: `${y}px`,
      });
    });

    return {
      $close,
      $matFloatingContentElement,
    };
  },
});
