import { compileStyleAsComponentStyle, createComponent, INJECT_CONTENT_TEMPLATE } from '@lirx/dom';

// @ts-ignore
import style from './mat-floating-content.component.scss?inline';

/**
 * COMPONENT: 'mat-floating-content'
 *
 * Represents the "main element" of a floating overlay.
 */

export interface IMatFloatingContentComponentConfig {
  element: HTMLElement;
}

export const MatFloatingContentComponent = createComponent<IMatFloatingContentComponentConfig>({
  name: 'mat-floating-content',
  template: INJECT_CONTENT_TEMPLATE,
  styles: [compileStyleAsComponentStyle(style)],
});
