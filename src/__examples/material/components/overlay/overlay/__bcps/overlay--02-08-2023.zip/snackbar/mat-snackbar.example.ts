import { single } from '@lirx/core';
import { VirtualCustomElementNode } from '@lirx/dom';
import {
  IMatSnackbarComponentConfig,
  IMatSnackbarData,
  MatOverlay,
  MatSnackbarController,
  MatSnackbarQueueController,
} from '@lirx/dom-material';

/*----------------------------*/

function getRandomText(): string {
  const texts = [
    `Cordially convinced did incommode existence put out suffering certainly.`,
    `Besides another and saw ferrars limited ten say unknown.`,
    `Να ατ προσωπικών χρειάζεται κατανοήσει.`,
    `Ecstatic advanced and procured civility not absolute put continue. Overcame breeding or my concerns removing desirous so absolute. My melancholy unpleasing imprudence considered in advantages so impression. Almost unable put piqued talked likely houses her met. Met any nor may through resolve entered. An mr cause tried oh do shade happy.`,
  ];
  return texts[Math.floor(Math.random() * texts.length)];
}

function matSnackbarExample1(): void {

  const openButton = document.createElement('button');
  openButton.innerText = 'open';
  document.body.appendChild(openButton);

  let snackbar: MatOverlay<VirtualCustomElementNode<IMatSnackbarComponentConfig>> | undefined;

  openButton.onclick = () => {
    if (snackbar === void 0) {
      snackbar = MatSnackbarController.open();

      snackbar.node.inputs.set('message', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas tincidunt');
      snackbar.node.inputs.set('horizontalPosition', 'right');
      snackbar.node.inputs.set('verticalPosition', 'bottom');
      snackbar.node.inputs.set('actionText', 'Click me');
      snackbar.node.bindOutputWithObserver('clickAction', () => {
        snackbar?.close();
      });
    } else {
      snackbar.close();
      snackbar = void 0;
    }
  }
}

function matSnackbarExample2(): void {

  const openButton = document.createElement('button');
  openButton.innerText = 'open';
  document.body.appendChild(openButton);

  const open = () => {
    const openPromise = MatSnackbarQueueController.open({
      message$: getRandomText(),
      horizontalPosition$: 'left',
      verticalPosition$: 'bottom',
      actionText$: 'Click me',
      $clickAction: () => {
        openPromise.then((snackbar) => snackbar.close());
      },
    }, { displayDuration: 10000 });
  };

  openButton.onclick = open;
}

/*----------------------------*/

export function matSnackbarExample(): void {
  // matSnackbarExample1();
  matSnackbarExample2();
}
