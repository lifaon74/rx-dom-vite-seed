import { compileStyleAsComponentStyle, createComponent, INJECT_CONTENT_TEMPLATE } from '@lirx/dom';

// @ts-ignore
import style from './mat-menu-container.component.scss?inline';

/**
 * COMPONENT: 'mat-menu-container'
 */

export interface IMatMenuContainerComponentConfig {
  element: HTMLElement;
}

export const MatMenuContainerComponent = createComponent<IMatMenuContainerComponentConfig>({
  name: 'mat-menu-container',
  template: INJECT_CONTENT_TEMPLATE,
  styles: [compileStyleAsComponentStyle(style)],
});
