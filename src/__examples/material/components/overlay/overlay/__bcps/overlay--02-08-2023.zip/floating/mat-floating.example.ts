import { flip, offset, shift, size } from '@floating-ui/dom';
import { $log, IObservable } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { IMatOverlayInput, MAT_OVERLAY_INPUT_NAME, MAT_OVERLAY_INPUT } from '@lirx/dom-material';
import { MatFloatingFactory } from './mat-floating-factory.class';


/*----------------------------*/

interface IData {
  readonly text$: IObservable<string>;
}

export interface IMyFloatingComponentConfig {
  element: HTMLElement;
  inputs:
    | ['text', string]
    | IMatOverlayInput<IMyFloatingComponentConfig>;
  data: IData;
}

const MyFloating = createComponent<IMyFloatingComponentConfig>({
  name: 'my-floating',
  template: compileReactiveHTMLAsComponentTemplate({
    html: `
      floating: {{ $.$text }}
    `,
  }),
  inputs: [
    ['text'],
    MAT_OVERLAY_INPUT,
  ],
  init: (node: VirtualCustomElementNode<IMyFloatingComponentConfig>): IData => {

    const text$ = node.inputs.get$('text');

    return {
      text$,
    };
  },
});

const MyFloatingFactory = new MatFloatingFactory(MyFloating);

/*----------------------------*/

/*----------------------------*/

export function matFloatingExample(): void {
  const button = document.createElement('button');
  button.innerText = 'open';
  button.style.margin = '20px';
  document.body.appendChild(button);

  const open = () => {
    // const instance = MyFloatingFactory.openWithData(
    //   button,
    //   'Hello world !',
    // );
    //
    // instance.node.
  };

  button.onclick = open;

  open();
}
