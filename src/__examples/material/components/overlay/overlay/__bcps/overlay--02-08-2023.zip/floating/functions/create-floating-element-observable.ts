import {
  autoUpdate,
  computePosition,
  ComputePositionConfig,
  ComputePositionReturn,
  FloatingElement,
  ReferenceElement,
} from '@floating-ui/dom';
import { IObservable, IObserver, IUnsubscribeOfObservable } from '@lirx/core';

export interface IFloatingElementPosition extends ComputePositionReturn {
  reference: ReferenceElement;
  floating: FloatingElement;
}

export function createFloatingElementObservable(
  reference: ReferenceElement,
  floating: FloatingElement,
  options?: Partial<ComputePositionConfig>,
): IObservable<IFloatingElementPosition> {
  return (emit: IObserver<IFloatingElementPosition>): IUnsubscribeOfObservable => {
    let running: boolean = true;
    let id: number = 0;

    const endAutoUpdate = autoUpdate(
      reference,
      floating,
      (): void => {
        id++;
        const current: number = id;

        computePosition(reference, floating, options)
          .then((result: ComputePositionReturn): void => {
            if (
              (id === current)
              && running
            ) {
              emit({
                ...result,
                reference,
                floating,
              });
            }
          });
      },
    );

    return (): void => {
      if (running) {
        running = false;
        endAutoUpdate();
      }
    };
  };
}


