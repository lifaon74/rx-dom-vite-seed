import { compileStyleAsComponentStyle, createComponent, INJECT_CONTENT_TEMPLATE } from '@lirx/dom';

// @ts-ignore
import style from './mat-menu-item.component.scss?inline';

/**
 * COMPONENT: 'mat-menu-item'
 */

export interface IMatMenuItemComponentConfig {
  element: HTMLElement;
}

export const MatMenuItemComponent = createComponent<IMatMenuItemComponentConfig>({
  name: 'mat-menu-item',
  template: INJECT_CONTENT_TEMPLATE,
  styles: [compileStyleAsComponentStyle(style)],
});
