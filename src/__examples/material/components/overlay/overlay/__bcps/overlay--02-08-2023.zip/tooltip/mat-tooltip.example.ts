import { flip, offset, shift, size } from '@floating-ui/dom';
import { $log, IObservable } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { getMatOverlayData$$, IMatOverlayInput, MAT_OVERLAY_INPUT_NAME } from '@lirx/dom-material';
import { createFloatingElementObservable } from '../floating/functions/create-floating-element-observable';
import { MatFloatingComponent } from '../floating/built-in/mat-floating/mat-floating.component';
import { MatFloatingFactory } from '../floating/mat-floating-factory.class';

/*----------------------------*/

interface IData {
  readonly text$: IObservable<string>;
}

export interface IMyModalComponentConfig {
  element: HTMLElement;
  inputs: [
    IMatOverlayInput<IMyModalComponentConfig, string>,
  ],
  data: IData;
}

const MyModalComponent = createComponent<IMyModalComponentConfig>({
  name: 'my-modal',
  template: compileReactiveHTMLAsComponentTemplate({
    html: `
      <mat-floating
      
      >
        {{ $.text$ }}
      </mat-floating>
    `,
    customElements: [
      MatFloatingComponent,
    ],
  }),
  inputs: [
    [MAT_OVERLAY_INPUT_NAME],
  ],
  init: (node: VirtualCustomElementNode<IMyModalComponentConfig>): IData => {
    const data$ = getMatOverlayData$$<IMyModalComponentConfig>(node);

    const text$ = data$;

    return {
      text$,
    };
  },
});

const MyModalFactory = new MatFloatingFactory(MyModalComponent, {
  animationDuration: 150,
});

/*----------------------------*/

/*----------------------------*/

export function matTooltipExample(): void {
  const button = document.createElement('button');
  button.innerText = 'open';
  button.style.margin = '20px';
  document.body.appendChild(button);

  const open = () => {
    const instance = MyModalFactory.openStatic(
      'Hello world !'.repeat(100),
    );

    instance.state$($log);

    // const node = instance.node.elementNode.querySelector<HTMLElement>('mat-floating-content')!;
    // node.style.position = 'absolute';
    //
    // const position$ = createFloatingElementObservable(button, node, {
    //   placement: 'bottom-start',
    //   middleware: [
    //     offset(6),
    //     flip(),
    //     shift(),
    //     size({
    //       apply({availableWidth, availableHeight, elements}: any) {
    //         // Do things with the data, e.g.
    //         Object.assign(elements.floating.style, {
    //           maxWidth: `${availableWidth - 10}px`,
    //           maxHeight: `${availableHeight}px`,
    //         });
    //       },
    //     }),
    //   ],
    // });
    //
    // position$((r) => {
    //   console.log(r);
    //   const {x, y} = r;
    //   Object.assign(node.style, {
    //     left: `${x}px`,
    //     top: `${y}px`,
    //   });
    // });
  };

  button.onclick = open;

  open();
}
