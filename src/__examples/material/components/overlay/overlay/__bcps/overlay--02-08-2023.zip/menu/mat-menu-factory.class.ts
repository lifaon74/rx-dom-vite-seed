import { IVirtualCustomElementNodeConfig } from '@lirx/dom';
import { MatFloatingFactory } from '../floating/mat-floating-factory.class';

/** CLASS **/

export class MatMenuFactory<GConfig extends IVirtualCustomElementNodeConfig> extends MatFloatingFactory<GConfig> {
}

