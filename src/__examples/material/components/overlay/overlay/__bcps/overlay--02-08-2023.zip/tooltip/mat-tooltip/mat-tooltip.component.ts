import {
  ComputePositionConfig,
  ComputePositionReturn,
  flip,
  FloatingElement,
  offset,
  ReferenceElement,
  shift,
  size,
} from '@floating-ui/dom';
import {
  combineLatest,
  combineLatestSpread,
  createUnicastReplayLastSource,
  createUnicastSource,
  IObservable,
  IObserver,
  map$$,
  merge,
  switchMap$$,
} from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { ElementReferenceModifier } from '@lirx/dom-material';
import {
  MatFloatingContentComponent
} from '../../floating/fragments/mat-floating-container/fragments/mat-floating-content/mat-floating-content.component';
import {
  IMatFloatingContainerComponentCloseType,
  MatFloatingContainerComponent,
} from '../../floating/fragments/mat-floating-container/mat-floating-container.component';
import { createFloatingElementObservable, IFloatingElementPosition } from '../../floating/functions/create-floating-element-observable';


// @ts-ignore
import html from './mat-tooltip.component.html?raw';
// @ts-ignore
import style from './mat-tooltip.component.scss?inline';


export interface IMatTooltipData {
  message: string;
  actionText?: string | undefined;
  horizontalPosition?: IMatSnackbarComponentHorizontalPosition | undefined;
  verticalPosition?: IMatSnackbarComponentVerticalPosition | undefined;
  width?: IMatSnackbarComponentWidth | undefined;
  onClickAction?: IMatSnackbarOnClickAction;
}

/**
 * COMPONENT: 'mat-tooltip'
 */

interface IData {
  readonly $close: IObserver<IMatFloatingContainerComponentCloseType>;
  readonly $matFloatingContentElement: IObserver<HTMLElement>;
}

export interface IMatFloatingComponentConfig {
  element: HTMLElement;
  inputs: [
    IMatOverlayInput<IMatSnackbarComponentConfig, IMatSnackbarData>,
  ],
  data: IData;
}

export const MatTooltipComponent = createComponent<IMatFloatingComponentConfig>({
  name: 'mat-tooltip',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatFloatingContainerComponent,
      MatFloatingContentComponent,
    ],
    modifiers: [
      ElementReferenceModifier,
    ]
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['reference'],
    ['options'],
  ],
  outputs: [
    ['close'],
  ],
  init: (node: VirtualCustomElementNode<IMatFloatingComponentConfig>): IData => {
    /* CLOSE */

    const $close = node.outputs.$set('close');

    /* POSITION */

    const reference$ = node.inputs.get$('reference');
    const options$ = node.inputs.get$('options');

    const {
      emit: $matFloatingContentElement,
      subscribe: matFloatingContentElement$,
    } = createUnicastReplayLastSource<HTMLElement>();

    const position$ = switchMap$$(
      combineLatestSpread(reference$, matFloatingContentElement$, options$),
      ([reference, matFloatingContentElement, options]): IObservable<IFloatingElementPosition> => {
        return createFloatingElementObservable(reference, matFloatingContentElement, options);
      },
    );

    node.onConnected$(position$)(({ x, y, floating }) => {
      Object.assign(floating.style, {
        left: `${x}px`,
        top: `${y}px`,
      });
    });

    return {
      $close,
      $matFloatingContentElement,
    };
  },
});
