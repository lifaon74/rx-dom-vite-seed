import {
  fromEventTarget,
  fromSelfEventTarget,
  IMapFilterMapFunctionReturn,
  map$$,
  MAP_FILTER_DISCARD,
  mapFilter$$,
  merge,
} from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { MatFocusTrapComponent } from '@lirx/dom-material';
import { IUnsubscribe } from '@lirx/utils';

// @ts-ignore
import html from './mat-floating-container.component.html?raw';
// @ts-ignore
import style from './mat-floating-container.component.scss?inline';

/** TYPES **/

export type IMatFloatingContainerComponentCloseType =
  | 'backdrop'
  | 'escape'
  ;

/**
 * COMPONENT: 'mat-floating-container'
 *
 * This is the main container for a floating overlay. It includes a backdrop and a "content" area·
 */

export interface IMatFloatingContainerComponentConfig {
  element: HTMLElement;
  outputs:
    | ['close', IMatFloatingContainerComponentCloseType];
}

export type IMatFloatingContainerVirtualCustomElementNode = VirtualCustomElementNode<IMatFloatingContainerComponentConfig>;

export const MatFloatingContainerComponent = createComponent<IMatFloatingContainerComponentConfig>({
  name: 'mat-floating-container',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatFocusTrapComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  outputs: [
    'close',
  ],
  init: (node: IMatFloatingContainerVirtualCustomElementNode): void => {
    /* CLOSE */

    const $close = node.outputs.$set('close');

    const backdropClose$ = map$$(
      fromSelfEventTarget<'click', MouseEvent>(node.elementNode, 'click'),
      (): IMatFloatingContainerComponentCloseType => 'backdrop',
    );

    const escapeClose$ = mapFilter$$(
      fromEventTarget<'keydown', KeyboardEvent>(node.elementNode, 'keydown'),
      (event: KeyboardEvent): IMapFilterMapFunctionReturn<IMatFloatingContainerComponentCloseType> => {
        return (event.key === 'Escape')
          ? 'escape'
          : MAP_FILTER_DISCARD;
      },
    );

    const close$ = merge([
      backdropClose$,
      escapeClose$,
    ]);

    node.onConnected((): IUnsubscribe => {
      return close$($close);
    });
  },
});
