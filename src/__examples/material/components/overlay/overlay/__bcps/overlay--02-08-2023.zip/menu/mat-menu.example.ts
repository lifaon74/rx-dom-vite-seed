import { IObservable } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { IMatOverlayInput, MAT_OVERLAY_INPUT_NAME } from '@lirx/dom-material';
import { MatMenuFactory } from './mat-menu-factory.class';
import { MatMenuItemComponent } from './mat-menu/fragments/mat-menu-item/mat-menu-item.component';
import { MatMenuComponent } from './mat-menu/mat-menu.component';

/*----------------------------*/

interface IData {
  readonly text$: IObservable<string>;
}

export interface IMyMenuComponentConfig {
  element: HTMLElement;
  inputs:
    | ['text', string]
    | IMatOverlayInput<IMyMenuComponentConfig>;
  data: IData;
}

const MyMenu = createComponent<IMyMenuComponentConfig>({
  name: 'my-menu',
  template: compileReactiveHTMLAsComponentTemplate({
    html: `
      <mat-menu>
        <mat-menu-item>
          Option 1
        </mat-menu-item>
        <mat-menu-item>
          {{ $.text$ }}
        </mat-menu-item>
      </mat-menu>
    `,
    customElements: [
      MatMenuComponent,
      MatMenuItemComponent,
    ],
  }),
  inputs: [
    ['text'],
    [MAT_OVERLAY_INPUT_NAME],
  ],
  init: (node: VirtualCustomElementNode<IMyMenuComponentConfig>): IData => {
    const text$ = node.inputs.get$('text');

    return {
      text$,
    };
  },
});

const MyMenuFactory = new MatMenuFactory(MyMenu);

/*----------------------------*/

/*----------------------------*/

export function matMenuExample(): void {
  const button = document.createElement('button');
  button.innerText = 'open';
  button.style.margin = '20px';
  document.body.appendChild(button);

  const open = () => {
    const instance = MyMenuFactory.open();

    instance.node.inputs.set('text', 'Hello world !');
  };

  button.onclick = open;

  open();
}
