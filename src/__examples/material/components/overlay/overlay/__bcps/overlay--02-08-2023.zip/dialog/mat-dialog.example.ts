import { $log, IObservable, IObserver } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import {
  createMatOverlayCloseObserver,
  IMatDialogBasicComponentCloseType,
  IMatOverlayInput,
  MatButtonModifier,
  MatDialogBasicComponent,
  MatDialogFactory,
  MatFlatButtonPrimaryModifier,
  MAT_OVERLAY_INPUT,
} from '@lirx/dom-material';

/*----------------------------*/

interface IData {
  readonly $close: IObservable<IObserver<IMatDialogBasicComponentCloseType>>;
  readonly text$: IObservable<string>;
  readonly $onClickCancelButton: IObservable<IObserver<MouseEvent>>;
}

export interface IMyModalComponentConfig {
  element: HTMLElement;
  inputs:
    | IMatOverlayInput<IMyModalComponentConfig>
    | ['text', string];
  data: IData;
}

const MyModalComponent = createComponent<IMyModalComponentConfig>({
  name: 'my-modal',
  template: compileReactiveHTMLAsComponentTemplate({
    html: `
      <mat-dialog-basic \${close}="$.$close">
        <rx-slot name="title">
          My modal
        </rx-slot>

        <rx-slot name="content">
          {{ $.text$ }}
        </rx-slot>

        <rx-slot name="actions">
          <button
            #mat-button
            {click}="$.$onClickCancelButton"
          >
            Cancel
          </button>
          <button #mat-flat-button-primary>
            Go
          </button>
        </rx-slot>
      </mat-dialog-basic>
    `,
    customElements: [
      MatDialogBasicComponent,
    ],
    modifiers: [
      MatButtonModifier,
      MatFlatButtonPrimaryModifier,
    ],
  }),
  inputs: [
    MAT_OVERLAY_INPUT,
    ['text'],
  ],
  init: (node: VirtualCustomElementNode<IMyModalComponentConfig>): IData => {
    const text$ = node.inputs.get$('text');

    const $onClickCancelButton = createMatOverlayCloseObserver(node);

    // const $close = createMatOverlayCloseObserver(node, (type: IMatDialogBasicComponentCloseType): boolean => {
    //   return type !== 'backdrop';
    // });

    const $close = createMatOverlayCloseObserver(node);

    return {
      $close,
      text$,
      $onClickCancelButton,
    };
  },
});

// type C<G> = [G] extends [never] ? true : false;
// type A = InferMatOverlayDataFromVirtualCustomElementNodeConfig<IMyModalComponentConfig>;
// type B = IMatOverlayFactoryOpenOptionsFromData<never>;
// type D = C<never>;

const MyModalFactory = new MatDialogFactory(MyModalComponent, {
  animationDuration: 150,
});

/*----------------------------*/

export function matDialogExample(): void {
  const button = document.createElement('button');
  button.innerText = 'open';
  document.body.appendChild(button);

  const open = () => {
    const instance = MyModalFactory.open();

    instance.node.inputs.set('text', 'true');

    instance.state$($log);

    // instance.untilState('opened')
    //   .then(() => {
    //     console.log('opened');
    //
    //     setTimeout(() => {
    //       instance.close()
    //         .then(() => {
    //           console.log('closed');
    //         });
    //     }, 1000);
    //   })
  };

  button.onclick = open;

  open();
  open();
}
