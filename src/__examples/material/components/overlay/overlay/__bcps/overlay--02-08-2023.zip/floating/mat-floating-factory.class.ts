import {
  createManualStylePropertyTransition,
  createNumberTransition,
  IVoidTransitionFunction,
  mapTransition,
  parallelTransitions,
} from '@lirx/animations';
import { toObservable, toObservableThrowIfUndefined } from '@lirx/core';
import { IComponent, IVirtualCustomElementNodeConfig, querySelectorOrThrow, VirtualCustomElementNode } from '@lirx/dom';
import {
  createMatOverlayFactoryOptionsFromReversibleTransitionFactory,
  MatOverlayFactory,
  IMatOverlayFactoryOpenOptions,
  MatOverlay,
} from '@lirx/dom-material';
import { IMatFloatingData } from './built-in/mat-floating/types/mat-floating-data.type';

/** CLASS **/

export interface IMatFloatingFactoryOptions {
  animationDuration?: number;
}

export class MatFloatingFactory<GConfig extends IVirtualCustomElementNodeConfig> extends MatOverlayFactory<GConfig> {

  constructor(
    component: IComponent<GConfig>,
    {
      animationDuration = 150,
    }: IMatFloatingFactoryOptions = {},
  ) {
    super(
      component,
      createMatOverlayFactoryOptionsFromReversibleTransitionFactory({
        transitionFactory: (
          node: VirtualCustomElementNode<GConfig>,
        ): IVoidTransitionFunction => {
          return getMatFloatingAnimationTransition({
            element: node.elementNode as HTMLElement,
          });
        },
        duration: animationDuration,
      }),
    );
  }

  openWithData(
    {
      reference,
      options,
      onClose,
    }: IMatFloatingData,
    openOptions?: IMatOverlayFactoryOpenOptions,
  ): MatOverlay<VirtualCustomElementNode<GConfig>> {
    const overlay: MatOverlay<VirtualCustomElementNode<GConfig>> = this.open(openOptions);

    overlay.node.bindInputWithObservable('reference', toObservable(reference) as any);

    if (options !== void 0) {
      overlay.node.bindInputWithObservable('options', toObservableThrowIfUndefined(options) as any);
    }

    if (onClose !== void 0) {
      overlay.node.bindOutputWithObserver('close', onClose as any);
    }

    return overlay;
  }
}

/** FUNCTIONS **/

/* TRANSITION */

interface IGetMatFloatingAnimationTransitionOptions {
  element: HTMLElement;
}

function getMatFloatingAnimationTransition(
  {
    element,
  }: IGetMatFloatingAnimationTransitionOptions,
): IVoidTransitionFunction {

  const containerElement: HTMLElement = querySelectorOrThrow(element, 'mat-floating-container');
  const contentElement: HTMLElement = querySelectorOrThrow(containerElement, 'mat-floating-content');

  const opacityTransition = createManualStylePropertyTransition(
    containerElement,
    'opacity',
    mapTransition(createNumberTransition(0, 1), String),
  );

  const transformTransition = createManualStylePropertyTransition(
    contentElement,
    'transform',
    mapTransition(createNumberTransition(0.75, 1), _ => `scale(${_})`),
  );

  const transition = parallelTransitions([
    opacityTransition,
    transformTransition,
  ]);

  containerElement.style.willChange = 'opacity';
  contentElement.style.willChange = 'transform';

  transition(0);

  return transition;
}
