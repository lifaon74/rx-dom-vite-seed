import { IObservable, IObserver } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { MatFloatingComponent } from '../../floating/built-in/mat-floating/mat-floating.component';
import { IMatFloatingContainerComponentCloseType } from '../../floating/fragments/mat-floating-container/mat-floating-container.component';
import { IMatFloatingReference } from '../../floating/built-in/mat-floating/types/mat-floating-reference.type';
import { IMatFloatingOptions } from '../../floating/built-in/mat-floating/types/mat-floating-options.type';
import { IMatFloatingComponentCloseType } from '../../floating/built-in/mat-floating/types/mat-floating-component-close-type.type';

// @ts-ignore
import html from './mat-menu.component.html?raw';
// @ts-ignore
import style from './mat-menu.component.scss?inline';

/**
 * COMPONENT: 'mat-menu'
 */

interface IData {
  readonly reference$: IObservable<IMatFloatingReference>;
  readonly options$: IObservable<IMatFloatingOptions>;
  readonly $close: IObserver<IMatFloatingContainerComponentCloseType>;
}

export interface IMatFloatingComponentConfig {
  element: HTMLElement;
  inputs:
    | ['reference', IMatFloatingReference]
    | ['options', IMatFloatingOptions];
  outputs:
    | ['close', IMatFloatingComponentCloseType];
  data: IData;
}

export const MatMenuComponent = createComponent<IMatFloatingComponentConfig>({
  name: 'mat-menu',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatFloatingComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['reference'],
    ['options', void 0],
  ],
  outputs: [
    ['close'],
  ],
  init: (node: VirtualCustomElementNode<IMatFloatingComponentConfig>): IData => {
    // INPUTS
    const reference$ = node.inputs.get$('reference');
    const options$ = node.inputs.get$('options');

    // OUTPUTS
    const $close = node.outputs.$set('close');

    return {
      reference$,
      options$,
      $close,
    };
  },
});
