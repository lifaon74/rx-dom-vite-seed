import { IPosition2D } from '../position/position-2d.type';
import { ISize2D } from '../size/size-2d.type';

export interface IPositionAndSize2D extends IPosition2D, ISize2D {

}

