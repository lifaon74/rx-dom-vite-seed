export interface ISize2D {
  width: number;
  height: number;
}

export type IPartialSize2D = Partial<ISize2D>;
