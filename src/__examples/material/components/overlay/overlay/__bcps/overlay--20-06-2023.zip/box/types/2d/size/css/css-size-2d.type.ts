export interface ICSSSize2D {
  width: string;
  height: string;
}
