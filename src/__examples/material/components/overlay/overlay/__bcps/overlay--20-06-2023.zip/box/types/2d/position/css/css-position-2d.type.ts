export interface ICSSPosition2D {
  left: string;
  top: string;
}
