export interface IPosition2D {
  left: number;
  top: number;
}

export type IPartialPosition2D = Partial<IPosition2D>;

