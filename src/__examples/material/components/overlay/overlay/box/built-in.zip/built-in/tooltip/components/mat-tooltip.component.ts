import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { applyCSSPositionAndSize2D } from '../../types/2d/position-and-size/css/apply-css-position-and-size-2d';
import { ICSSPositionAndSize2D } from '../../types/2d/position-and-size/css/css-position-and-size-2d.type';

// @ts-ignore
import html from './mat-tooltip-sticky.component.html?raw';
// @ts-ignore
import style from './mat-tooltip.component.scss?inline';

/**
 * COMPONENT: 'mat-tooltip'
 */

export interface IMatTooltipComponentConfig {
  element: HTMLElement;
  inputs: [
    ['config', ICSSPositionAndSize2D]
  ];
}

export const MatTooltipComponent = createComponent<IMatTooltipComponentConfig>({
  name: 'mat-tooltip',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['config'],
  ],
  init: (node: VirtualCustomElementNode<IMatTooltipComponentConfig>): void => {
    const config$ = node.inputs.get$('config');

    node.onConnected$(config$)((positionAndSize: ICSSPositionAndSize2D): void => {
      applyCSSPositionAndSize2D(
        node.elementNode,
        positionAndSize,
      );
    });
  },
});


