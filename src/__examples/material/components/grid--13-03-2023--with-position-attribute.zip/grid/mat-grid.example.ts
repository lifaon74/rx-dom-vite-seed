import {
  bootstrap,
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
} from '@lirx/dom';
import { MatGridItemComponent } from './grid-item/mat-grid-item.component';
import { MatGridComponent } from './grid/mat-grid.component';


interface IMatGridExampleComponentConfig {
  element: HTMLElement;
}

export const MatGridExampleComponent = createComponent<IMatGridExampleComponentConfig>({
  name: 'mat-grid-example',
  template: compileReactiveHTMLAsComponentTemplate({
    html: `
      <mat-grid style="--mat-grid-rows: 5;">
<!--        <div>A</div>-->
<!--        <div style="&#45;&#45;mat-grid-item-left: 2; background: blue">B</div>-->
      <mat-grid-item position="1, 0, 1, 2">A</mat-grid-item>
      </mat-grid>
    `,
    customElements: [
      MatGridComponent,
      MatGridItemComponent,
    ]
  }),
  styles: [compileStyleAsComponentStyle(`
  :host {
    display: block;
  }
  `)]
});


/** BOOTSTRAP FUNCTION **/

export function matGridExample() {
  bootstrap(MatGridExampleComponent);
}
