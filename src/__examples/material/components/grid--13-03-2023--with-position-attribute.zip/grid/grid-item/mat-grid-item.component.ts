import { MAP_FILTER_DISCARD, mapDistinct$$ } from '@lirx/core';
import { IMapFilterMapFunctionReturn } from '@lirx/core/src/observer/pipes/built-in/map-filter/map-filter-map-function.type';
import {
  bindVirtualCustomElementInputWithAttribute,
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  IAttributeValue,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { stringToMatGridItemPosition } from './helpers/mat-grid-item-position';
import { IMatGridItemPosition } from './helpers/mat-grid-item-position.type';

// @ts-ignore
import html from './mat-grid-item.component.html?raw';
// @ts-ignore
import style from './mat-grid-item.component.scss?inline';

/**
 * COMPONENT: 'app-grid-item'
 **/

interface IData {
}

interface IGridItemComponentConfig {
  element: HTMLElement;
  inputs: [
    ['position', IMatGridItemPosition],
  ];
  data: IData;
}

export const MatGridItemComponent = createComponent<IGridItemComponentConfig>({
  name: 'mat-grid-item',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['position'],
  ],
  init: (node: VirtualCustomElementNode<IGridItemComponentConfig>): IData => {
    const position$ = node.inputs.get$('position');

    bindVirtualCustomElementInputWithAttribute(
      node,
      'position',
      (input: IAttributeValue): IMapFilterMapFunctionReturn<IMatGridItemPosition> => {
        return (input === null)
          ? MAP_FILTER_DISCARD
          : stringToMatGridItemPosition(input);
      },
    );

    const left$ = mapDistinct$$(position$, ([left]) => String(left));
    const top$ = mapDistinct$$(position$, ([, top]) => String(top));
    const width$ = mapDistinct$$(position$, ([, , width]) => String(width));
    const height$ = mapDistinct$$(position$, ([, , , height]) => String(height));

    node.setReactiveStyleProperty('--mat-grid-item-left', left$);
    node.setReactiveStyleProperty('--mat-grid-item-top', top$);
    node.setReactiveStyleProperty('--mat-grid-item-width', width$);
    node.setReactiveStyleProperty('--mat-grid-item-height', height$);

    return {};
  },
});
