import { IObservable, map$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';

// @ts-ignore
import html from './mat-grid.component.html?raw';
// @ts-ignore
import style from './mat-grid.component.scss?inline';

/**
 * COMPONENT: 'mat-grid'
 */

interface IData {
}

interface IMatGridComponentConfig {
  element: HTMLElement;
}

export const MatGridComponent = createComponent<IMatGridComponentConfig>({
  name: 'mat-grid',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
  }),
  styles: [compileStyleAsComponentStyle(style)],
  init: (node: VirtualCustomElementNode<IMatGridComponentConfig>): IData => {
    return {};
  },
});
