export function booleanToString(
  input: boolean,
): string {
  return input
    ? 'true'
    : 'false';
}

