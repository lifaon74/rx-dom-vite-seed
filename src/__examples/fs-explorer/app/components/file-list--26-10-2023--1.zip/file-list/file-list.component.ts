import { map$$, single, IObservable, $log } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  IClassNamesList,
  VirtualComponentNode,
  Input,
  Output,
  Component,
  input,
  output,
  VirtualElementNode,
} from '@lirx/dom';

import {
  HTMLElementListController,
  HTMLElementListKeyboardController, HTMLElementListPointerDownElementController,
} from './store/html-element-list-controller';
import { IUnsubscribe, mergeUnsubscribeFunctions } from '@lirx/unsubscribe';
import { NodeReferenceModifier } from '@lirx/dom-material';

// @ts-ignore
import html from './file-list.component.html?raw';
// @ts-ignore
import style from './file-list.component.scss?inline';

/** TYPES **/

export type IAppFileListCardComponentView =
  | 'card'
  | 'table'
  ;

export interface IFileEntry {
  readonly id: string;
  readonly name: string;
  readonly previewURL: string;
  readonly size: string;
  readonly modified: string;
}

export type IFileList = readonly IFileEntry[];

export type ISelectedFiles = ReadonlySet<IFileEntry>;

/**
 * COMPONENT: 'app-file-list'
 */

interface IAppFileListComponentData {
  readonly files: Input<IFileList>;
  readonly view: Input<IAppFileListCardComponentView>;
  readonly selectedFiles: Output<ISelectedFiles>;
}

interface ITemplateData {
  readonly files$: IObservable<IFileList>;
  readonly isFileSelected: (file: IFileEntry) => IObservable<boolean>;
  readonly setFilesContainerElement: (node: VirtualElementNode<HTMLElement>) => void;
  readonly setFileElement: (node: VirtualElementNode<HTMLElement>, file: IFileEntry, index$: IObservable<number>) => void;
  // readonly pointerSelectAreaVisible$: IObservable<boolean>;
  // readonly pointerSelectAreaStyleLeft$: IObservable<ISetStylePropertyOrNull>;
  // readonly pointerSelectAreaStyleTop$: IObservable<ISetStylePropertyOrNull>;
  // readonly pointerSelectAreaStyleWidth$: IObservable<ISetStylePropertyOrNull>;
  // readonly pointerSelectAreaStyleHeight$: IObservable<ISetStylePropertyOrNull>;
}

export const AppFileListComponent = new Component<HTMLElement, IAppFileListComponentData, ITemplateData>({
  name: 'app-file-list',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    components: [],
    modifiers: [
      NodeReferenceModifier,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  componentData: (): IAppFileListComponentData => {
    return {
      files: input<IFileList>([]),
      view: input<IAppFileListCardComponentView>('card'),
      selectedFiles: output<ISelectedFiles>(),
    };
  },
  templateData: (node: VirtualComponentNode<HTMLElement, IAppFileListComponentData>): ITemplateData => {
    /* VIEW */

    const view$ = node.input$('view');

    const classNames$ = map$$(view$, (view: IAppFileListCardComponentView): IClassNamesList => {
      return new Set<string>([
        `view-${view}`,
      ]);
    });

    node.setReactiveClassNamesList(classNames$);

    /* FILES */

    const dummyFiles = Array.from({ length: 100 }, (_, index: number): IFileEntry => {
      return {
        id: String(index),
        name: `file-${index}.txt`,
        previewURL: `/assets/images/0${Math.floor(Math.random() * 3 + 1)}.jpg`,
        size: '5KB',
        modified: 'Today',
      };
    });

    const files$ = single<IFileList>(dummyFiles);

    /* link between FileEntry and HTMLElement */

    const fileEntryToHTMLElementMap = new Map<IFileEntry, HTMLElement>();
    const virtualElementNodeToFileEntryMap = new Map<HTMLElement, IFileEntry>();

    const linkFileEntryWithHTMLElement = (
      file: IFileEntry,
      element: HTMLElement,
    ): void => {
      if (fileEntryToHTMLElementMap.has(file)) {
        throw new Error(`FileEntry already linked with an element`);
      } else {
        fileEntryToHTMLElementMap.set(file, element);
        virtualElementNodeToFileEntryMap.set(element, file);
      }
    };

    const unlinkFileEntryWithHTMLElement = (
      file: IFileEntry,
      element: HTMLElement,
    ): void => {
      if (
        !fileEntryToHTMLElementMap.delete(file)
        || !virtualElementNodeToFileEntryMap.delete(element)
      ) {
        throw new Error(`FileEntry not linked with an element`);
      }
    };

    const linkFileEntryWithHTMLElementWithUnsubscribe = (
      file: IFileEntry,
      element: HTMLElement,
    ): IUnsubscribe => {
      linkFileEntryWithHTMLElement(
        file,
        element,
      );
      return (): void => {
        unlinkFileEntryWithHTMLElement(
          file,
          element,
        );
      };
    };

    const getHTMLElementFromFileEntry = (
      file: IFileEntry,
    ): HTMLElement => {
      const element: HTMLElement | undefined = fileEntryToHTMLElementMap.get(file);
      if (element === void 0) {
        throw new Error(`FileEntry not linked with an element.`);
      }
      return element;
    };

    const getFileEntryFromHTMLElement = (
      element: HTMLElement,
    ): IFileEntry => {
      const file: IFileEntry | undefined = virtualElementNodeToFileEntryMap.get(element);
      if (file === void 0) {
        throw new Error(`element not linked with a FileEntry.`);
      }
      return file;
    };

    /* control */

    const htmlElementListController = new HTMLElementListController();
    const htmlElementListPointerDownElementController = new HTMLElementListPointerDownElementController(htmlElementListController);

    const isFileSelected = (
      file: IFileEntry,
    ): IObservable<boolean> => {
      return htmlElementListController.isElementSelected(getHTMLElementFromFileEntry(file)).toObservable();
    };

    const setFilesContainerElement = (
      node: VirtualElementNode<HTMLElement>,
    ): void => {
      node.onConnected((): IUnsubscribe => {
        return new HTMLElementListKeyboardController(htmlElementListController, node.elementNode).start();
      });
    };

    const setFileElement = (
      node: VirtualElementNode<HTMLElement>,
      file: IFileEntry,
      index$: IObservable<number>
    ): void => {
      index$($log);

      const unlink = linkFileEntryWithHTMLElementWithUnsubscribe(file, node.elementNode)

      node.onConnected((): IUnsubscribe => {
        return mergeUnsubscribeFunctions([
          htmlElementListPointerDownElementController.startForElement(node.elementNode),
          unlink,
        ]);
      });
    };

    const selectedFiles$ = map$$(htmlElementListController.selectedElements.toObservable(), (selectedElements: ReadonlySet<HTMLElement>): ISelectedFiles => {
      return new Set<IFileEntry>(
        Array.from(selectedElements, (selectedElement: HTMLElement): IFileEntry => {
          return getFileEntryFromHTMLElement(selectedElement);
        }),
      );
    });

    selectedFiles$(node.$output('selectedFiles'));

    /*---------*/

    // const childrenWithMetadata$ = notificationsToValuesObservable(fs.list(new URL('google-drive://'), { withMetadata: true }));
    //
    // const files$ = switchMap$$(childrenWithMetadata$, (files: IFileSystemEntryWithMetadata<IGoogleDriveFileSystemMetadata>[]): IObservable<IFileList> => {
    //     return combineLatest(
    //       files
    //         .sort(compareFileSystemEntry)
    //         .map((file: IFileSystemEntryWithMetadata<IGoogleDriveFileSystemMetadata>): IObservable<IFileEntry> => {
    //           const metadata: IGoogleDriveFileSystemMetadata = file.metadata!;
    //           const previewURL$ = generateFilePreviewURL({
    //             mimeType: metadata.mimeType,
    //             previewURL: metadata.thumbnailLink,
    //             types: metadata.types,
    //           });
    //
    //           return map$$(notificationsToLastValueObservable(previewURL$), (previewURL: string): IFileEntry => {
    //             return {
    //               id: file.url.href,
    //               name: metadata.name,
    //               previewURL,
    //               size: '1o',
    //               modified: '1o',
    //             };
    //           });
    //         }),
    //     );
    //   },
    // );

    //
    // // FILE CONTAINER
    //
    // const fileContainerElement$ = map$$(filesContainer$, (filesContainer: VirtualElementNode<HTMLElement>): HTMLElement => {
    //   return filesContainer.elementNode;
    // });
    //
    //
    //
    // // FILES
    //
    // const filesExtended$ = pipe$$(files$, [
    //   map$$$<IFileList, IFileListExtended>((files: IFileList): IFileListExtended => {
    //     return files.map((file: IFileEntry): IFileEntryExtended => {
    //       return {
    //         ...file,
    //         $reference$: createMulticastReplayLastSource<VirtualElementNode<HTMLElement>>(),
    //       };
    //     });
    //   }),
    //   shareRL$$$<IFileListExtended>(),
    // ]);
    //
    // const fileSelector$ = shareRL$$(
    //   function$$(
    //     [fileContainerElement$, fileListObservableToFileIdWithElementList$$(filesExtended$)],
    //     createFileSelector,
    //   ),
    // );
    //
    // const selectedFile$ = pipe$$(fileSelector$, [
    //   switchMap$$$<ICreateFileSelectorResult, ISelectedFileIds>(({ selectedFile$ }): IObservable<ISelectedFileIds> => selectedFile$),
    //   shareRL$$$<ISelectedFileIds>(),
    // ]);
    //
    // const pointerSelectArea$ = pipe$$(fileSelector$, [
    //   switchMap$$$<ICreateFileSelectorResult, IPointerSelectAreaOrNull>(({ pointerSelectArea$ }): IObservable<IPointerSelectAreaOrNull> => pointerSelectArea$),
    //   shareRL$$$<IPointerSelectAreaOrNull>(),
    // ]);
    //
    // const {
    //   pointerSelectAreaVisible$,
    //   pointerSelectAreaStyleLeft$,
    //   pointerSelectAreaStyleTop$,
    //   pointerSelectAreaStyleWidth$,
    //   pointerSelectAreaStyleHeight$,
    // } = getPointerSelectAreaObservables(pointerSelectArea$);

    return {
      files$,
      isFileSelected,
      setFilesContainerElement,
      setFileElement,
      // pointerSelectAreaVisible$,
      // pointerSelectAreaStyleLeft$,
      // pointerSelectAreaStyleTop$,
      // pointerSelectAreaStyleWidth$,
      // pointerSelectAreaStyleHeight$,
    };
  },
});
