import {
  createMulticastReplayLastSource,
  debounceFrame$$$,
  debounceTime$$,
  fromPromiseFactory,
  functionI$$,
  IObservable,
  IObserver,
  ISource,
  let$$,
  map$$,
  merge,
  notificationsToLastValueObservable,
  pipe$$,
  share$$,
  share$$$,
  shareRL$$,
  single,
} from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
  VirtualDOMNode,
} from '@lirx/dom';
import { INPUT_VALUE_MODIFIER, NODE_REFERENCE_MODIFIER } from '@lirx/dom-material';
import type { IIconComponent, IMatIconMetadata, IMatIconMetadataMap } from '@lirx/mdi';

// @ts-ignore
import html from './mat-icons-demo.component.html?raw';
// @ts-ignore
import style from './mat-icons-demo.component.scss?inline';

/** COMPONENT **/

interface IIcon extends IMatIconMetadata {
  readonly $containerRef: IObserver<VirtualDOMNode>;
}

interface IData {
  readonly $inputValue$: ISource<string>;
  readonly icons$: IObservable<readonly IIcon[]>;
  readonly count$: IObservable<number>;
  readonly total$: IObservable<number>;
  readonly isLoadMoreButtonVisible$: IObservable<boolean>;
  readonly $onClickLoadMoreButton: IObserver<MouseEvent>;
}

export interface IMatIconsDemoComponentConfig {
  element: HTMLElement;
  data: IData;
}

export const MatIconsDemoComponent = createComponent<IMatIconsDemoComponentConfig>({
  name: 'mat-icons-demo',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    modifiers: [
      INPUT_VALUE_MODIFIER,
      NODE_REFERENCE_MODIFIER,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  init: (node: VirtualCustomElementNode<IMatIconsDemoComponentConfig>): IData => {
    /* LIMIT */
    const limitIncrement: number = 100;
    const [$limit, limit$, getLimit] = let$$<number>(limitIncrement);

    const resetLimit = () => {
      $limit(limitIncrement);
    };

    const increaseLimit = () => {
      $limit(getLimit() + limitIncrement);
    };

    /* INPUT */
    const $inputValue$ = createMulticastReplayLastSource<string>('');

    const { subscribe: inputValue$ } = $inputValue$;

    const inputValueDebounced$ = shareRL$$(debounceTime$$(inputValue$, 500));

    // resets the limit when the input changes
    node.onConnected$(inputValueDebounced$)(resetLimit);

    /* ICONS */
    const fetchIconsMetadata$ = fromPromiseFactory<IMatIconMetadataMap>(() => {
      return import('@lirx/mdi')
        .then(_ => _.MAT_ICONS_METADATA);
    });

    const iconsMetadata$ = notificationsToLastValueObservable(fetchIconsMetadata$);

    const allIcons$ = share$$(
      map$$(iconsMetadata$, (iconsList: IMatIconMetadataMap): IIcon[] => {
        return Array.from(iconsList.values())
          .map((
            metadata: IMatIconMetadata,
          ): IIcon => {
            const loadComponent = (): Promise<IIconComponent> => {
              return import('@lirx/mdi')
                // return import(`@lirx/mdi/src/icons/${fileName}.mjs`)
                //   .finally(() => new Promise(_ => setTimeout(_, 1000)))
                .then(_ => _[metadata.componentName] as IIconComponent);
            };

            const $containerRef = (
              container: VirtualDOMNode,
            ): void => {
              loadComponent()
                .then((component: IIconComponent) => {
                  requestAnimationFrame(() => {
                    component.create().attach(container);
                  });
                });
            };

            return {
              ...metadata,
              $containerRef,
            };
          });
      }),
    );

    // filter icons
    const filteredIcons$ = share$$(
      functionI$$(
        [allIcons$, inputValueDebounced$],
        (allIcons: IIcon[], inputValue: string): IIcon[] => {
          const reg = new RegExp(inputValue.trim(), 'i');
          return allIcons
            .filter((icon: IIcon): boolean => {
              return reg.test(icon.name)
                || icon.aliases.some(alias => reg.test(alias))
                || icon.tags.some(tag => reg.test(tag))
                ;
            });
        }),
    );

    const count$ = share$$(merge([single(0), map$$(filteredIcons$, _ => _.length)]));
    const total$ = map$$(allIcons$, (allIcons: IIcon[]) => allIcons.length);

    // displayed list of icons
    const icons$ = pipe$$(
      functionI$$(
        [filteredIcons$, limit$],
        (icons: IIcon[], limit: number): IIcon[] => {
          return icons.slice(0, limit);
        },
      ),
      [
        debounceFrame$$$(),
        share$$$<IIcon[]>(),
      ],
    );

    /* BUTTON */

    const isLoadMoreButtonVisible$ = functionI$$(
      [limit$, count$],
      (limit: number, count: number): boolean => {
        return limit < count;
      },
    );

    const $onClickLoadMoreButton = increaseLimit;

    return {
      $inputValue$,
      icons$,
      count$,
      total$,
      isLoadMoreButtonVisible$,
      $onClickLoadMoreButton,
    };
  },
});
