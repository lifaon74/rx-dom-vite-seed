import { bootstrap } from '@lirx/dom';
import { MatIconsDemoComponent } from './mat-icons-demo.component';

export function matIconsDemoExample(): void {
  bootstrap(MatIconsDemoComponent);
}
