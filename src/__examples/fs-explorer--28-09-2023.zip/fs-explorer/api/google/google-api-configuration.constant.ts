export const GOOGLE_API_CONFIGURATION = {
  clientId: '661275394634-ll4emhbb175osacp9t669oh16mcbim5n.apps.googleusercontent.com',
  apiKey: 'AIzaSyBsfdos2CKgCJh7UjLgkNACtO-f5z2qbjk',
};
