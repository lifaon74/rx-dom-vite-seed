export const GOOGLE_DRIVE_DEFAULT_SCOPE_CONSTANT = 'https://www.googleapis.com/auth/drive';
