export function numberToString(
  input: number,
): string {
  return String(input);
}
