import { bootstrap } from '@lirx/dom';
import { TicTacToeComponent } from './tic-tac-toe.component';

/** BOOTSTRAP FUNCTION **/

export function ticTacToeExample() {
  bootstrap(TicTacToeComponent);
}
