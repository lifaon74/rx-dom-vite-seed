import { IPluralRulesFormatFunction } from '../../../intl/plural-rules/plural-rules-format-function.type';
import { IFluentSelectEntry, IFluentSelectEntryValue, IFluentSelectFunction } from './fluent-select-function.type';

export function createFluentSelectFunction(
  selectNumber: IPluralRulesFormatFunction,
): IFluentSelectFunction {
  return (
    value: unknown,
    entries: readonly IFluentSelectEntry[],
  ): string => {
    const length: number = entries.length;
    let defaultFnc!: IFluentSelectEntryValue;

    for (let i = 0; i < length; i++) {
      const [key, fnc, isDefault]: IFluentSelectEntry = entries[i];
      if (value === key) {
        return fnc();
      }
      if (isDefault) {
        defaultFnc = fnc;
      }
    }

    if (typeof value === 'number') {
      const _value: string = selectNumber(value);
      for (let i = 0; i < length; i++) {
        const [key, fnc]: IFluentSelectEntry = entries[i];
        if (_value === key) {
          return fnc();
        }
      }
    }

    return defaultFnc();
  };
}

