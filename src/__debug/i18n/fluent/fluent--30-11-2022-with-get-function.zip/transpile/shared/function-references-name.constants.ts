/**
 * @deprecated
 */
export const FUNCTION_REFERENCES_NAME = 'functionReferences';
