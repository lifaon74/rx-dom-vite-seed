export const MAP_NAME = 'map';
