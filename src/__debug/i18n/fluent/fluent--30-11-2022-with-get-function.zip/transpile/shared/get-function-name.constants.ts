export const GET_FUNCTION_NAME = 'getFunction';
