import { ILines, indentLines } from '@lirx/dom';
import { GET_FUNCTION_NAME } from './get-function-name.constants';
import { GET_VARIABLE_NAME } from './get-variable-name.constants';
import { SELECT_NAME } from './select-name.constants';

export interface IGenerateJSLinesForFluentFormatFunctionOptions {
  bodyLines: ILines;
}

export function generateJSLinesForFluentFormatFunction(
  {
    bodyLines,
  }: IGenerateJSLinesForFluentFormatFunctionOptions,
): ILines {
  return [
    `({`,
    ...indentLines([
      `${SELECT_NAME},`,
      `${GET_VARIABLE_NAME},`,
      `${GET_FUNCTION_NAME},`,
    ]),
    `}) => {`,
    ...indentLines(bodyLines),
    `}`,
  ];
}

