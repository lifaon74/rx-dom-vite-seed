import { Message } from '@fluent/syntax';
import { ILines, indentLines } from '@lirx/dom';
import { transpileFluentPatternNodeToJSLines } from '../pattern/transpile-fluent-pattern-node-to-js-lines';
import { generateJSLinesForFluentFormatFunction } from '../shared/generate-js-lines-for-fluent-format-function';
import { MAP_NAME } from '../shared/map-name.constants';

export interface ITranspileFluentMessageNodeToJSLinesOptions {
  messageNode: Message;
}

export function transpileFluentMessageNodeToJSLines(
  {
    messageNode,
    ...options
  }: ITranspileFluentMessageNodeToJSLinesOptions,
): ILines {
  return [
    `${MAP_NAME}.set(`,
    ...indentLines([
      `${JSON.stringify(messageNode.id.name)},`,
      ...generateJSLinesForFluentFormatFunction({
        bodyLines: [
          `return (`,
          ...indentLines(
            transpileFluentPatternNodeToJSLines({
              patternNode: messageNode.value!, // TODO support null case
            }),
          ),
          `);`,
        ],
      }),
    ]),
    `);`,
  ];
}
