import { BaseNode, Message, Pattern, TextElement } from '@fluent/syntax/esm/ast';
import { map$$, single } from '@lirx/core';
import {
  DEFAULT_COMPONENT_TEMPLATE_VALUES_TO_IMPORT, PRIMARY_TRANSPILERS_FOR_VIRTUAL_NODE_CONSTANT,
  toObservableThrowIfUndefined,
  VirtualContainerNode,
  VirtualDOMNode,
  VirtualReactiveTextNode,
  VirtualRootNode,
  VirtualTextNode,
} from '@lirx/dom';
import { isMessageNode, isResourceNode, isTextElementNode } from './fluent/fluent';
import { transpileFluentTextElementNodeToJSLines } from './fluent/transpile/text-element/transpile-fluent-text-element-node-to-js-lines';
import { transpileFluentUnknownNodeToJsLines } from './fluent/transpile/unknown/transpile-fluent-unknown-node-to-js-lines';
import { ILocalesInput } from './intl/locale/locales-input.type';
import { getIntlMessageFormat } from './intl/message-format/get-intl-message-format';
import {
  IGenericMessageKind,
  IMessageFormatRuntimeOptions,
  isMessageLiteral,
  isMessageValue,
  isResolvedMessage,
} from './intl/message-format/message-format.type';
import { parse, Resource } from '@fluent/syntax';

/*
website: https://projectfluent.org/
lib: https://github.com/projectfluent/fluent.js/tree/master/fluent-syntax
*/

/*--------------*/

// function fluentResourceNodeToVirtualDOMNode(
//   input: Resource,
// ): VirtualDOMNode {
//   const node: VirtualContainerNode = new VirtualContainerNode();
//   for (let i = 0, l = input.body.length; i < l; i++) {
//     fluentUnknownNodeToVirtualDOMNode(input.body[i]).attach(node);
//   }
//   return node;
// }

// export function fluentResourceNodeToVirtualDOMNode(
//   input: Resource,
// ): VirtualDOMNode {
//   const node: VirtualContainerNode = new VirtualContainerNode();
//   for (let i = 0, l = input.body.length; i < l; i++) {
//     fluentUnknownNodeToVirtualDOMNode(input.body[i]).attach(node);
//   }
//   return node;
// }
//
// export function fluentMessageNodeToVirtualDOMNode(
//   input: Message,
// ): VirtualDOMNode {
//   const node: VirtualContainerNode = new VirtualContainerNode();
//   for (let i = 0, l = input.body.length; i < l; i++) {
//     fluentUnknownNodeToVirtualDOMNode(input.body[i]).attach(node);
//   }
//   return node;
// }
//
// export function fluentPatternNodeToVirtualDOMNode(
//   input: Pattern,
// ): VirtualDOMNode {
//   const node: VirtualContainerNode = new VirtualContainerNode();
//   for (let i = 0, l = input.body.length; i < l; i++) {
//     fluentUnknownNodeToVirtualDOMNode(input.body[i]).attach(node);
//   }
//   return node;
// }
//
// export function fluentTextElementNodeToVirtualDOMNode(
//   input: TextElement,
// ): VirtualDOMNode {
//   return new VirtualTextNode(input.value);
// }
//
// /*--------------*/
//
// export function fluentUnknownNodeToVirtualDOMNode(
//   input: BaseNode,
// ): VirtualDOMNode {
//   if (isResourceNode(input)) {
//     return fluentResourceNodeToVirtualDOMNode(input);
//   } else if (isMessageNode(input)) {
//     return fluentMessageNodeToVirtualDOMNode(input);
//   } else if (isTextElementNode(input)) {
//     return fluentTextElementNodeToVirtualDOMNode(input);
//   } else {
//     throw new Error(`Unknown Node: ${input.type}`);
//   }
// }

/*--------------*/

/*
EXAMPLES:

`hello = Hello, world!`

 */

/*--------------*/

export function debugFluent(): void {
//   const res = parse(`
// -brand-name = Foo 3000
// welcome = Welcome, {$name}, to {-brand-name}!
// `, {});

  const msg = `hello = Hello, world!`;
  // const msg = `remove-bookmark = Really remove { $title }?`;
  // const msg = `emails = You have { NUMBER($unreadEmails) } unread emails.`;

  const res = parse(msg, {
    withSpans: false,
  });

  // console.log(res);
  console.log(res.body[0].value);

  const lines = transpileFluentUnknownNodeToJsLines({
    node: res.body[0].value as any,
    transpilers: PRIMARY_TRANSPILERS_FOR_VIRTUAL_NODE_CONSTANT,
  });

  console.log(lines!.join('\n'));

  // VirtualRootNode.body.attach(node);
}
