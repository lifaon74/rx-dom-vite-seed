import { TextElement } from '@fluent/syntax/esm/ast';
import { generateJSLinesForStaticTextNodeIfNotEmpty, IHavingPrimaryTranspilersOptions, ILinesOrNull } from '@lirx/dom';

export interface ITranspileFluentTextElementNodeToJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  textElementNode: TextElement;
}

export function transpileFluentTextElementNodeToJSLines(
  {
    textElementNode,
    ...options
  }: ITranspileFluentTextElementNodeToJSLinesOptions,
): ILinesOrNull {
  return generateJSLinesForStaticTextNodeIfNotEmpty({
    ...options,
    value: textElementNode.value,
  });
}
