import { Pattern } from '@fluent/syntax/esm/ast';
import { IHavingPrimaryTranspilersOptions, ILines, ILinesOrNull, nullIfEmptyLines } from '@lirx/dom';
import { transpileFluentUnknownNodeToJsLines } from '../unknown/transpile-fluent-unknown-node-to-js-lines';

export interface ITranspileFluentPatternNodeToJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  patternNode: Pattern;
}

export function transpileFluentPatternNodeToJsLines(
  {
    patternNode,
    ...options
  }: ITranspileFluentPatternNodeToJSLinesOptions,
): ILinesOrNull {
  const lines: ILines = [];
  for (let i = 0, l = patternNode.elements.length; i < l; i++) {
    const result: ILinesOrNull = transpileFluentUnknownNodeToJsLines({
      node: patternNode.elements[i],
      ...options,
    });
    if (result !== null) {
      lines.push(...result);
    }
  }
  return nullIfEmptyLines(lines);
}
