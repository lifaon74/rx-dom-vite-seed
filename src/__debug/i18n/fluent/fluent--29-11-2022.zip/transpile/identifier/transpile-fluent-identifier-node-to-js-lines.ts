import { Identifier } from '@fluent/syntax';
import { IHavingPrimaryTranspilersOptions, ILines } from '@lirx/dom';

export interface ITranspileFluentIdentifierNodeToJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  identifierNode: Identifier;
}

export function transpileFluentIdentifierNodeToJsLines(
  {
    identifierNode,
    ...options
  }: ITranspileFluentIdentifierNodeToJSLinesOptions,
): ILines {
  return [
    `$.${identifierNode.name}`,
  ];
}
