import { Placeable } from '@fluent/syntax/esm/ast';
import { generateJSLinesForReactiveTextNode, IHavingPrimaryTranspilersOptions, ILines, linesOrNullToLines } from '@lirx/dom';
import { transpileFluentUnknownNodeToJsLines } from '../unknown/transpile-fluent-unknown-node-to-js-lines';

export interface ITranspileFluentPlaceableNodeToJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  placeableNode: Placeable;
}

export function transpileFluentPlaceableNodeToJsLines(
  {
    placeableNode,
    ...options
  }: ITranspileFluentPlaceableNodeToJSLinesOptions,
): ILines {
  return generateJSLinesForReactiveTextNode({
    ...options,
    value: linesOrNullToLines(
      transpileFluentUnknownNodeToJsLines({
        ...options,
        node: placeableNode.expression,
      }),
    ),
  });
}
