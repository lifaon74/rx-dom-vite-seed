import { BaseNode } from '@fluent/syntax/esm/ast';
import { IHavingPrimaryTranspilersOptions, ILines, ILinesOrNull } from '@lirx/dom';
import { isIdentifierNode, isPatternNode, isPlaceableNode, isTextElementNode, isVariableReferenceNode } from '../../fluent';
import { transpileFluentIdentifierNodeToJsLines } from '../identifier/transpile-fluent-identifier-node-to-js-lines';
import { transpileFluentPatternNodeToJsLines } from '../pattern/transpile-fluent-pattern-node-to-js-lines';
import { transpileFluentPlaceableNodeToJsLines } from '../placeable/transpile-fluent-placeable-node-to-js-lines';
import { transpileFluentTextElementNodeToJSLines } from '../text-element/transpile-fluent-text-element-node-to-js-lines';
import { transpileFluentVariableReferenceNodeToJsLines } from '../variable-reference/transpile-fluent-variable-reference-node-to-js-lines';

export interface ITranspileFluentUnknownNodeToJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  node: BaseNode;
}

export function transpileFluentUnknownNodeToJsLines(
  {
    node,
    ...options
  }: ITranspileFluentUnknownNodeToJSLinesOptions,
): ILinesOrNull {
  if (isTextElementNode(node)) {
    return transpileFluentTextElementNodeToJSLines({
      ...options,
      textElementNode: node,
    });
  } else if (isPatternNode(node)) {
    return transpileFluentPatternNodeToJsLines({
      ...options,
      patternNode: node,
    });
  } else if (isPlaceableNode(node)) {
    return transpileFluentPlaceableNodeToJsLines({
      ...options,
      placeableNode: node,
    });
  } else if (isIdentifierNode(node)) {
    return transpileFluentIdentifierNodeToJsLines({
      ...options,
      identifierNode: node,
    });
  } else if (isVariableReferenceNode(node)) {
    return transpileFluentVariableReferenceNodeToJsLines({
      ...options,
      variableReferenceNode: node,
    });
  } else {
    throw new Error(`Unknown Node: ${node.type}`);
  }
}
