import { VariableReference } from '@fluent/syntax';
import { IHavingPrimaryTranspilersOptions, ILines } from '@lirx/dom';
import { transpileFluentIdentifierNodeToJsLines } from '../identifier/transpile-fluent-identifier-node-to-js-lines';

export interface ITranspileFluentVariableReferenceNodeToJSLinesOptions extends IHavingPrimaryTranspilersOptions {
  variableReferenceNode: VariableReference;
}

export function transpileFluentVariableReferenceNodeToJsLines(
  {
    variableReferenceNode,
    ...options
  }: ITranspileFluentVariableReferenceNodeToJSLinesOptions,
): ILines {
  return transpileFluentIdentifierNodeToJsLines({
    ...options,
    identifierNode: variableReferenceNode.id,
  });
}
