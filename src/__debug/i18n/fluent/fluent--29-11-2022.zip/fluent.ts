import { Identifier, Placeable, Resource, VariableReference } from '@fluent/syntax';
import { BaseNode, Message, Pattern, TextElement } from '@fluent/syntax/esm/ast';

export function isResourceNode(
  value: BaseNode,
): value is Resource {
  return (value.type === 'Resource');
}

export function isMessageNode(
  value: BaseNode,
): value is Message {
  return (value.type === 'Message');
}

export function isIdentifierNode(
  value: BaseNode,
): value is Identifier {
  return (value.type === 'Identifier');
}

export function isPatternNode(
  value: BaseNode,
): value is Pattern {
  return (value.type === 'Pattern');
}

export function isPlaceableNode(
  value: BaseNode,
): value is Placeable {
  return (value.type === 'Placeable');
}

export function isVariableReferenceNode(
  value: BaseNode,
): value is VariableReference {
  return (value.type === 'VariableReference');
}


export function isTextElementNode(
  value: BaseNode,
): value is TextElement {
  return (value.type === 'TextElement');
}
