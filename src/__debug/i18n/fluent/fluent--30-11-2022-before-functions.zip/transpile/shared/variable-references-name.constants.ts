export const VARIABLE_REFERENCES_NAME = 'variableReferences';
