import { ILines, indentLines } from '@lirx/dom';
import { FUNCTION_REFERENCES_NAME } from './function-references-name.constants';
import { VARIABLE_REFERENCES_NAME } from './variable-references-name.constants';

export interface IGenerateJSLinesForFluentFormatFunctionOptions {
  bodyLines: ILines;
}

export function generateJSLinesForFluentFormatFunction(
  {
    bodyLines,
  }: IGenerateJSLinesForFluentFormatFunctionOptions,
): ILines {
  return [
    `(`,
    ...indentLines([
      `${VARIABLE_REFERENCES_NAME},`,
      `${FUNCTION_REFERENCES_NAME},`,
    ]),
    `) => {`,
    ...indentLines(bodyLines),
    `}`,
  ];
}

