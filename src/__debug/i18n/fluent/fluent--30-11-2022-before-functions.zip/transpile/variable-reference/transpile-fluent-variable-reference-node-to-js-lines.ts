import { VariableReference } from '@fluent/syntax';
import { ILines } from '@lirx/dom';
import { VARIABLE_REFERENCES_NAME } from '../shared/variable-references-name.constants';

export interface ITranspileFluentVariableReferenceNodeToJSLinesOptions {
  variableReferenceNode: VariableReference;
  withDefault?: boolean;
}

export function transpileFluentVariableReferenceNodeToJSLines(
  {
    variableReferenceNode,
    withDefault = false,
    ...options
  }: ITranspileFluentVariableReferenceNodeToJSLinesOptions,
): ILines {
  return [
    `get(${variableReferenceNode.id.name})`,
  ];
}
