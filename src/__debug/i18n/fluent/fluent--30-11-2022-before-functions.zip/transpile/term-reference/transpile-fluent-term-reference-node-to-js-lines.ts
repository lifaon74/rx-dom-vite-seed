import { NamedArgument, TermReference } from '@fluent/syntax/esm/ast';
import { ILines, indentLines, inlineLastLines, wrapLinesWithCurlyBrackets, wrapLinesWithRoundBrackets } from '@lirx/dom';
import { transpileFluentLiteralNodeToJSLines } from '../literal/transpile-fluent-literal-node-to-js-lines';
import { FUNCTION_REFERENCES_NAME } from '../shared/function-references-name.constants';
import { MAP_NAME } from '../shared/map-name.constants';
import { VARIABLE_REFERENCES_NAME } from '../shared/variable-references-name.constants';

export interface ITranspileFluentTermReferenceNodeToJSLinesOptions {
  termReferenceNode: TermReference;
}

export function transpileFluentTermReferenceNodeToJSLines(
  {
    termReferenceNode,
    ...options
  }: ITranspileFluentTermReferenceNodeToJSLinesOptions,
): ILines {
  return [
    `${MAP_NAME}.get(${JSON.stringify(`-${termReferenceNode.id.name}`)})(`,
    ...indentLines([
      ...(
        (
          (termReferenceNode.arguments === null)
          || (termReferenceNode.arguments.named.length === 0)
        )
          ? [
            `${VARIABLE_REFERENCES_NAME},`,
          ]
          : inlineLastLines(
            wrapLinesWithCurlyBrackets(
              [
                `...${VARIABLE_REFERENCES_NAME},`,
                ...termReferenceNode.arguments.named.flatMap((namedArgument: NamedArgument): ILines => {
                  return [
                    ...inlineLastLines(
                      [`${namedArgument.name.name}: `],
                      wrapLinesWithRoundBrackets( // could be optional
                        transpileFluentLiteralNodeToJSLines({
                          ...options,
                          literalNode: namedArgument.value,
                        }),
                      ),
                      [','],
                    ),
                  ];
                }),
              ],
              false,
            ),
            [','],
          )
      ),
      `${FUNCTION_REFERENCES_NAME},`,
    ]),
    `)`,
  ];
}
