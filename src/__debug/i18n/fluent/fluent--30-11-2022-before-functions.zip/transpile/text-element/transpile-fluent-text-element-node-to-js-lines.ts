import { TextElement } from '@fluent/syntax/esm/ast';
import { ILines } from '@lirx/dom';

export interface ITranspileFluentTextElementNodeToJSLinesOptions {
  textElementNode: TextElement;
}

export function transpileFluentTextElementNodeToJSLines(
  {
    textElementNode,
    ...options
  }: ITranspileFluentTextElementNodeToJSLinesOptions,
): ILines {
  return [
    JSON.stringify(textElementNode.value),
  ];
}
