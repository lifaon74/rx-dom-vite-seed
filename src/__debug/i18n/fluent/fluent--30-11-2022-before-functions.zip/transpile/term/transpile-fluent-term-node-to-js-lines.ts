import { Term } from '@fluent/syntax/esm/ast';
import { ILines, indentLines } from '@lirx/dom';
import { transpileFluentPatternNodeToJSLines } from '../pattern/transpile-fluent-pattern-node-to-js-lines';
import { generateJSLinesForFluentFormatFunction } from '../shared/generate-j-s-lines-for-fluent-format-function';
import { MAP_NAME } from '../shared/map-name.constants';

export interface ITranspileFluentTermNodeToJSLinesOptions {
  termNode: Term;
}

export function transpileFluentTermNodeToJSLines(
  {
    termNode,
    ...options
  }: ITranspileFluentTermNodeToJSLinesOptions,
): ILines {
  return [
    `${MAP_NAME}.set(`,
    ...indentLines([
      `${JSON.stringify(`-${termNode.id.name}`)},`,
      ...generateJSLinesForFluentFormatFunction({
        bodyLines: [
          `return (`,
          ...indentLines(
            transpileFluentPatternNodeToJSLines({
              patternNode: termNode.value,
            }),
          ),
          `);`,
        ],
      }),
    ]),
    `);`,
  ];

  // return transpileFluentMessageNodeToJSLines({
  //   messageNode: termNode as unknown as Message,
  // });
}
