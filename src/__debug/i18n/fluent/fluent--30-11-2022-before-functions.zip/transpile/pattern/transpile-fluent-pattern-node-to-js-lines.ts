import { Pattern, PatternElement } from '@fluent/syntax/esm/ast';
import { ILines, ILinesOrNull, inlineLastLines, wrapLinesWithRoundBrackets } from '@lirx/dom';
import { transpileFluentPatternElementNodeToJSLines } from './transpile-fluent-pattern-element-node-to-js-lines';

export interface ITranspileFluentPatternNodeToJSLinesOptions {
  patternNode: Pattern;
}

export function transpileFluentPatternNodeToJSLines(
  {
    patternNode,
    ...options
  }: ITranspileFluentPatternNodeToJSLinesOptions,
): ILines {
  const lines: ILines = [];
  for (let i = 0, l = patternNode.elements.length; i < l; i++) {
    const result: ILinesOrNull = transpileFluentPatternElementNodeToJSLines({
      patternElementNode: patternNode.elements[i],
      ...options,
    });
    if (result !== null) {
      lines.push(...result);
    }
  }
  return wrapLinesWithRoundBrackets(
    patternNode.elements.flatMap((patternElementNode: PatternElement, index: number): ILines => {
      const lines: ILines = transpileFluentPatternElementNodeToJSLines({
        patternElementNode,
        ...options,
      });
      return (index === 0)
        ? lines
        : inlineLastLines(
          ['+ '],
          lines,
        );
    }),
  );
}
