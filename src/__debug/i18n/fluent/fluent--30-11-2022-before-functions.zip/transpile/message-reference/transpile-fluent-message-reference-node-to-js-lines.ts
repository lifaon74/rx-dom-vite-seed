import { MessageReference } from '@fluent/syntax/esm/ast';
import { ILines, indentLines } from '@lirx/dom';
import { FUNCTION_REFERENCES_NAME } from '../shared/function-references-name.constants';
import { MAP_NAME } from '../shared/map-name.constants';
import { VARIABLE_REFERENCES_NAME } from '../shared/variable-references-name.constants';

export interface ITranspileFluentMessageReferenceNodeToJSLinesOptions {
  messageReferenceNode: MessageReference;
}

export function transpileFluentMessageReferenceNodeToJSLines(
  {
    messageReferenceNode,
    ...options
  }: ITranspileFluentMessageReferenceNodeToJSLinesOptions,
): ILines {
  return [
    `${MAP_NAME}.get(${JSON.stringify(messageReferenceNode.id.name)})(`,
    ...indentLines([
      `${VARIABLE_REFERENCES_NAME},`,
      `${FUNCTION_REFERENCES_NAME},`,
    ]),
    `)`,
  ];
}
