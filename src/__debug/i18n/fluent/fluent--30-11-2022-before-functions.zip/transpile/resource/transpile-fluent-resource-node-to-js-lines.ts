import { Entry, Resource } from '@fluent/syntax';
import { ILines, indentLines } from '@lirx/dom';
import { MAP_NAME } from '../shared/map-name.constants';
import { transpileFluentResourceEntryNodeToJSLines } from './transpile-fluent-resource-entry-node-to-js-lines';

export interface ITranspileFluentResourceNodeToJSLinesOptions {
  resourceNode: Resource;
}

export function transpileFluentResourceNodeToJSLines(
  {
    resourceNode,
    ...options
  }: ITranspileFluentResourceNodeToJSLinesOptions,
): ILines {
  return [
    `(${MAP_NAME}) => {`,
    ...indentLines(
      resourceNode.body
        .flatMap((entry: Entry): ILines => {
          return transpileFluentResourceEntryNodeToJSLines({
            entryNode: entry,
          });
        }),
    ),
    `}`,
  ];
}
