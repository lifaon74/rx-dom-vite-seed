import { parse } from '@fluent/syntax';
import { linesToString } from '../../../../../lirx/dom/dist';
import { transpileFluentResourceNodeToJSLines } from './transpile/resource/transpile-fluent-resource-node-to-js-lines';

/*
website: https://projectfluent.org/
lib: https://github.com/projectfluent/fluent.js/tree/master/fluent-syntax
*/

/*--------------*/

/*
EXAMPLES:

`hello = Hello, world!`

V1)

new Map([
  [
    'hello',
    () => {
      return reactiveTemplateString`Hello, world!`;
    },
  ],
]);

V2)

(map) => {
  map.set(
    'hello',
    () => {
      return reactiveTemplateString([
        'Hello, world!',
      ]);
    },
  );
};

V3)

(map) => {
  map.set(
    'hello',
    () => {
      return `Hello, world!`;
    },
  );
};

---

`remove-bookmark = Really remove { $title }?`

V1)

new Map([
  [
    'remove-bookmark',
    ($) => {
      return reactiveTemplateString`Really remove ${$.title}?`;
    }
  ],
]);


V2)

(map) => {
  map.set(
    'remove-bookmark',
    () => {
      return reactiveTemplateString(
        [
          'Really remove',
          '?',
        ],
        $.title,
      );
    },
  );
};

V3)

(map) => {
  map.set(
    'remove-bookmark',
    ($) => {
      // return `Really remove ${$.title}?`;
      return 'Really remove' + $.title + '?';
    },
  );
};


---

`emails = You have { NUMBER($unreadEmails) } unread emails.`

V1)

new Map([
  [
    'emails',
    ($) => {
      return reactiveTemplateString`You have ${ numberObservable($.unreadEmails) } unread emails.`;
    }
  ],
]);


V3)
(map) => {
  map.set(
    'remove-bookmark',
    ($) => {
      return `You have ${ formatToNumber($.unreadEmails) } unread emails.`;
    },
  );
};

---

emails =
    { $unreadEmails ->
        [one] You have one unread email.
       *[other] You have { $unreadEmails } unread emails.
    }

 V3)
(map) => {
  map.set(
    'remove-bookmark',
    ($) => {
      return `You have ${ formatToNumber($.unreadEmails) } unread emails.`;
    },
  );
};


 */

/*--------------*/

function selector(
  value: unknown,
) {

}

/*--------------*/

export function debugFluent(): void {
//   const res = parse(`
// -brand-name = Foo 3000
// welcome = Welcome, {$name}, to {-brand-name}!
// `, {});

  // const msg = `# some comment`;
  // const msg = `hello = Hello, world!`;
  // const msg = `remove-bookmark = Really remove { $title }?`;
  // const msg = `time-elapsed = Time elapsed: { NUMBER($duration, maximumFractionDigits: 0) }s.`;
//   const msg = `
// menu-save = Save
// help-menu-save = Click { menu-save } to save the file.
//   `;
//   const msg = `
// -https = https://{ $host }
// visit = Visit { -https(host: "example.com") } for more information.
//   `;
//   const msg = `about = Informacje o { -brand-name(case: "locative") }.`;
  const msg = `
emails =
    { $unreadEmails ->
        [one] You have one unread email.
       *[other] You have { $unreadEmails } unread emails.
    }
  `;
//   const msg = `
// # Simple things are simple.
// hello-user = Hello, {$userName}!
//
// # Complex things are possible.
// shared-photos =
//     {$userName} {$photoCount ->
//         [one] added a new photo
//        *[other] added {$photoCount} new photos
//     } to {$userGender ->
//         [male] his stream
//         [female] her stream
//        *[other] their stream
//     }.
//   `;

  const res = parse(msg, {
    withSpans: false,
  });

  console.log(res);

  const lines = transpileFluentResourceNodeToJSLines({
    resourceNode: res,
  });

  const code: string = linesToString(lines);

  console.log(code);

  // const run = new Function('map', `return (${code})(map);`);
  //
  // const map = new Map();
  // run(map);
  // // console.log(map.get('visit')());
  // console.log(
  //   map.get('shared-photos')({
  //     userName: 'Alice',
  //     photoCount: 5,
  //   }, {})
  // );
}
