export interface IFluentListFormatFunction {
  (
    value: Iterable<string>,
    options?: Intl.ListFormatOptions,
  ): string;
}
