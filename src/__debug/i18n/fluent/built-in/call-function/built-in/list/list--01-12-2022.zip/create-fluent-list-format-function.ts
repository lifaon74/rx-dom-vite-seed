import { ILocalesInput } from '../../../../../intl/locale/locales-input.type';
import { IFluentListFormatFunction } from './fluent-list-format-function.type';

export function createFluentListFormatFunction(
  locales?: ILocalesInput,
  _options?: Intl.ListFormatOptions,
): IFluentListFormatFunction {
  return (
    value: Iterable<string>,
    options?: Intl.ListFormatOptions,
  ): string => {
    return new Intl.ListFormat(
      locales as any,
      {
        ..._options,
        ...options,
      },
    ).format(value);
  };
}
