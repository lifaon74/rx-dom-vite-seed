import { debugFluent } from './fluent/debug-fluent';


export function debugI18n(): void {
  // debugMessageFormat2();
  debugFluent();
}
