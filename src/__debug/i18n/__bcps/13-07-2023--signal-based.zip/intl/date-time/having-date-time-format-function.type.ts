import { IDateTimeFormatFunction } from './date-time-format-function.type';

export interface IHavingDateTimeFormatFunction {
  dateTimeFormat: IDateTimeFormatFunction;
}

