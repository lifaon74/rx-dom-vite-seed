import { IPluralRulesSelectFunction } from './plural-rules-select-function.type';

export interface IHavingPluralRulesSelectFunction {
  pluralRulesSelect: IPluralRulesSelectFunction;
}

