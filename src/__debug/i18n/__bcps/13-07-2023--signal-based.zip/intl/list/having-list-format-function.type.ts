import { IListFormatFunction } from './list-format-function.type';

export interface IHavingListFormatFunction {
  listFormat: IListFormatFunction;
}

