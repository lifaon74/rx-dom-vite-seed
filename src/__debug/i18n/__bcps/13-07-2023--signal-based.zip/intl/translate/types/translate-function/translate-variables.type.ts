export type ITranslateVariableType = string | number;

export type ITranslateVariables = Record<string, ITranslateVariableType>;
