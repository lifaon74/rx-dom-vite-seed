import { debugFluent1 } from './examples/debug-fluent-1';
import { debugFluent2 } from './examples/debug-fluent-2';
import { debugFluent3 } from './examples/debug-fluent-3';

/*
website: https://projectfluent.org/
lib: https://github.com/projectfluent/fluent.js/tree/master/fluent-syntax
*/

export function debugFluent(): void {
  // debugFluent1();
  // debugFluent2();
  debugFluent3();
}
