export const RENDER_MESSAGE_NAME = 'renderMessage';
