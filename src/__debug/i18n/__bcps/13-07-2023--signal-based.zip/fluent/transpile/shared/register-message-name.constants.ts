export const REGISTER_MESSAGE_NAME = 'registerMessage';
