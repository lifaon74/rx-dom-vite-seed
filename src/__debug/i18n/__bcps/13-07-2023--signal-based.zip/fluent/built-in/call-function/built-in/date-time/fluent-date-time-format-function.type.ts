import { IDateTimeFormatFunction } from '../../../../../intl/date-time/date-time-format-function.type';

export type IFluentDateTimeFormatFunction = IDateTimeFormatFunction;
