import { INumberFormatFunction } from '../../../../../intl/number/number-format-function.type';

export type IFluentNumberFormatFunction = INumberFormatFunction;
