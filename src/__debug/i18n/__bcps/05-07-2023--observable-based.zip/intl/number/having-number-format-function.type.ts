import { INumberFormatFunction } from './number-format-function.type';

export interface IHavingNumberFormatFunction {
  numberFormat: INumberFormatFunction;
}

