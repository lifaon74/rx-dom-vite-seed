export interface IGenericFormatFunction {
  (...args: any[]): string;
}
