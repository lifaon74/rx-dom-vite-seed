import { IObservable } from '@lirx/core';
import { IPartialTranslateFunctions, ITranslateFunctions } from '../../../types/translate-function/translate-functions.type';

export type IReactiveTranslateFunctions = IObservable<ITranslateFunctions>;

export type IPartialReactiveTranslateFunctions = IObservable<IPartialTranslateFunctions>;

