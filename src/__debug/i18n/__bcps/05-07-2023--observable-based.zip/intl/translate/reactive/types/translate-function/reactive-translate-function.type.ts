import { IObservable } from '@lirx/core';
import { IReactiveTranslateFunctions } from './reactive-translate-functions.type';
import { IReactiveTranslateVariables } from './reactive-translate-variables.type';

export interface IReactiveTranslateFunction {
  (
    variables$: IReactiveTranslateVariables,
    functions$: IReactiveTranslateFunctions,
  ): IObservable<string>;
}
