import { function$$, IObservable, map$$, single, switchMap$$ } from '@lirx/core';
import { DEFAULT_TRANSLATIONS_STORE_FUNCTIONS } from '../default-translations-store-functions.constant';
import { ITranslationsStoreMissingKeyReturn, ITranslationsStoreOptions } from '../translations-store.class';
import { IPartialTranslateFunctions, ITranslateFunctions } from '../types/translate-function/translate-functions.type';
import { IReactiveTranslationsStoreTranslations } from './types/reactive-translations-store-translations.type';
import { IReactiveTranslateFunction } from './types/translate-function/reactive-translate-function.type';
import {
  IPartialReactiveTranslateFunctions,
  IReactiveTranslateFunctions,
} from './types/translate-function/reactive-translate-functions.type';
import { IReactiveTranslateVariables } from './types/translate-function/reactive-translate-variables.type';

type IReactiveTranslationsStoreMap = ReadonlyMap<string, IReactiveTranslateFunction>;

export class ReactiveTranslationsStore {
  readonly #translations$: IObservable<IReactiveTranslationsStoreMap>;
  readonly #defaultFunctions$: IReactiveTranslateFunctions;
  readonly #missingReturn: ITranslationsStoreMissingKeyReturn;

  constructor(
    translations$: IObservable<IReactiveTranslationsStoreTranslations>,
    defaultFunctions$: IPartialReactiveTranslateFunctions = single({}),
    {
      missingReturn = 'throw',
    }: ITranslationsStoreOptions = {},
  ) {
    this.#translations$ = map$$(translations$, (translations: IReactiveTranslationsStoreTranslations): IReactiveTranslationsStoreMap => {
      return (translations instanceof Map)
        ? translations
        : new Map<string, IReactiveTranslateFunction>(translations);
    });

    this.#defaultFunctions$ = map$$(defaultFunctions$, (defaultFunctions: IPartialTranslateFunctions): ITranslateFunctions => {
      return {
        ...DEFAULT_TRANSLATIONS_STORE_FUNCTIONS,
        ...defaultFunctions,
      };
    });

    this.#missingReturn = missingReturn;
  }

  translate$(
    key: string,
    variables$: IReactiveTranslateVariables = single({}),
    functions$?: IPartialReactiveTranslateFunctions,
  ): IObservable<string> {
    const _functions$ = (functions$ === void 0)
      ? this.#defaultFunctions$
      : function$$(
        [this.#defaultFunctions$, functions$],
        (defaultFunctions: ITranslateFunctions, functions: IPartialTranslateFunctions): ITranslateFunctions => {
          return {
            ...defaultFunctions,
            ...functions,
          } as ITranslateFunctions;
        });

    return switchMap$$(this.#translations$, (translations: IReactiveTranslationsStoreMap): IObservable<string> => {
      if (translations.has(key)) {
        return translations.get(key)!(variables$, _functions$);
      } else {
        switch (this.#missingReturn) {
          case 'key':
            return single(key);
          case 'throw':
            throw new Error(`Missing translation for "${key}"`);
        }
      }
    });
  }
}



