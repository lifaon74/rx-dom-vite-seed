import { IObservable } from '@lirx/core';
import { ITranslateVariables } from '../../../types/translate-function/translate-variables.type';

export type IReactiveTranslateVariables = IObservable<ITranslateVariables>;
