import { IReactiveTranslateFunction } from './translate-function/reactive-translate-function.type';

export type IReactiveTranslationsStoreTranslationEntry = [
  key: string,
  translate: IReactiveTranslateFunction,
];

export type IReactiveTranslationsStoreTranslations = Iterable<IReactiveTranslationsStoreTranslationEntry>;
