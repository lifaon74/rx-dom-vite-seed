import { ILocalesList } from './locales-list.type';

export type ILocalesInput =
  | string
  | ILocalesList
  ;

