export type ILocalesList = readonly string[];
