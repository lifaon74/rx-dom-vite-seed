import { IPluralRulesSelectFunction } from '../../../../../intl/plural-rules/plural-rules-select-function.type';

export type IFluentPluralRulesSelectFunction = IPluralRulesSelectFunction;
