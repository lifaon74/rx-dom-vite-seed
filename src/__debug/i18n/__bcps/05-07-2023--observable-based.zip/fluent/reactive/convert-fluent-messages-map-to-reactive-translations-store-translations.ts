import {
  IReactiveTranslationsStoreTranslationEntry,
  IReactiveTranslationsStoreTranslations,
} from '../../intl/translate/reactive/types/reactive-translations-store-translations.type';
import { IFluentMessageFunction } from '../built-in/message/fluent-message-function.type';
import { IReadonlyFluentMessagesMap } from '../built-in/message/map/fluent-messages-map.type';
import { convertFluentMessageFunctionToReactiveTranslateFunction } from './convert-fluent-message-function-to-reactive-translate-function';

export function convertFluentMessagesMapToReactiveTranslationsStoreTranslations(
  fluentMessagesMap: IReadonlyFluentMessagesMap,
): IReactiveTranslationsStoreTranslations {
  return Array.from(
    fluentMessagesMap.entries(),
    ([key, fluentMessageFunction]: [string, IFluentMessageFunction]): IReactiveTranslationsStoreTranslationEntry => {
      return [
        key,
        convertFluentMessageFunctionToReactiveTranslateFunction(fluentMessageFunction),
      ];
    },
  );
}

