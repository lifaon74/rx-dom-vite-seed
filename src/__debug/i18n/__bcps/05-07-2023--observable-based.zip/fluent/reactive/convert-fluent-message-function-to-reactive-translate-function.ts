import { function$$, IObservable, map$$, mapDistinct$$, shareRL$$ } from '@lirx/core';
import { IReactiveTranslateFunction } from '../../intl/translate/reactive/types/translate-function/reactive-translate-function.type';
import { IReactiveTranslateFunctions } from '../../intl/translate/reactive/types/translate-function/reactive-translate-functions.type';
import { IReactiveTranslateVariables } from '../../intl/translate/reactive/types/translate-function/reactive-translate-variables.type';
import { IGenericTranslateFunctions, ITranslateFunctions } from '../../intl/translate/types/translate-function/translate-functions.type';
import { ITranslateVariables } from '../../intl/translate/types/translate-function/translate-variables.type';
import { createFluentDefaultCallFunctionEntries } from '../built-in/call-function/built-in/create-fluent-default-call-function-entries';
import { IFluentDateTimeFormatFunction } from '../built-in/call-function/built-in/date-time/fluent-date-time-format-function.type';
import {
  convertListFormatFunctionToFluentListFormat,
} from '../built-in/call-function/built-in/list/convert-list-format-function-to-fluent-list-format';
import { IFluentListFormatFunction } from '../built-in/call-function/built-in/list/fluent-list-format-function.type';
import { IFluentNumberFormatFunction } from '../built-in/call-function/built-in/number/fluent-number-format-function.type';
import { IFluentPluralRulesSelectFunction } from '../built-in/call-function/built-in/plural-rules/fluent-plural-rules-select-function.type';
import { createFluentCallFunctionFunction, IFluentCallFunctionEntry } from '../built-in/call-function/create-fluent-call-function-function';
import { createFluentConcatFunction, IFluentConcatFunction } from '../built-in/concat/create-fluent-concat-function';
import { createFluentGetVariableFunction } from '../built-in/get-variable/create-fluent-get-variable-function';
import { IFluentGetVariableFunction } from '../built-in/get-variable/fluent-get-variable-function.type';
import { IFluentMessageFunction, IFluentMessageOptions } from '../built-in/message/fluent-message-function.type';
import { createFluentSelectFunction } from '../built-in/select/create-fluent-select-function';
import { IFluentSelectFunction } from '../built-in/select/fluent-select-function.type';

export function convertFluentMessageFunctionToReactiveTranslateFunction(
  fluentMessageFunction: IFluentMessageFunction,
): IReactiveTranslateFunction {
  return (
    variables$: IReactiveTranslateVariables,
    functions$: IReactiveTranslateFunctions,
  ): IObservable<string> => {

    const sharedFunctions$ = shareRL$$(functions$);

    const fluentNumberFormat$ = shareRL$$(
      mapDistinct$$(sharedFunctions$, ({ numberFormat }: ITranslateFunctions): IFluentNumberFormatFunction => {
        return numberFormat;
      }),
    );

    const fluentDateTimeFormat$ = shareRL$$(
      mapDistinct$$(sharedFunctions$, ({ dateTimeFormat }: ITranslateFunctions): IFluentDateTimeFormatFunction => {
        return dateTimeFormat;
      }),
    );

    const fluentListFormat$ = shareRL$$(
      mapDistinct$$(sharedFunctions$, ({ listFormat }: ITranslateFunctions): IFluentListFormatFunction => {
        return convertListFormatFunctionToFluentListFormat(listFormat);
      }),
    );

    const fluentPluralRulesSelect$ = shareRL$$(
      mapDistinct$$(sharedFunctions$, ({ pluralRulesSelect }: ITranslateFunctions): IFluentPluralRulesSelectFunction => {
        return pluralRulesSelect;
      }),
    );

    const otherFunctions$ = map$$(
      sharedFunctions$, (
        {
          numberFormat,
          dateTimeFormat,
          listFormat,
          pluralRulesSelect,
          ...otherFunctions
        }: ITranslateFunctions,
      ): IGenericTranslateFunctions => {
        return otherFunctions;
      });

    const fluentDefaultCallFunctionEntries$ = function$$(
      [
        fluentNumberFormat$,
        fluentDateTimeFormat$,
        fluentListFormat$,
        fluentPluralRulesSelect$,
      ],
      (
        fluentNumberFormat: IFluentNumberFormatFunction,
        fluentDateTimeFormat: IFluentDateTimeFormatFunction,
        fluentListFormat: IFluentListFormatFunction,
        fluentPluralRulesSelect: IFluentPluralRulesSelectFunction,
      ): IFluentCallFunctionEntry[] => {
        return createFluentDefaultCallFunctionEntries({
          fluentNumberFormat,
          fluentDateTimeFormat,
          fluentListFormat,
          fluentPluralRulesSelect,
        });
      },
    );

    const fluentOtherCallFunctionEntries$ = map$$(
      otherFunctions$,
      (otherFunctions: IGenericTranslateFunctions): IFluentCallFunctionEntry[] => {
        return Object.entries(otherFunctions);
      },
    );

    const fluentCallFunctionEntries$ = function$$(
      [
        fluentDefaultCallFunctionEntries$,
        fluentOtherCallFunctionEntries$,
      ],
      (
        fluentDefaultCallFunctionEntries: IFluentCallFunctionEntry[],
        fluentOtherCallFunctionEntries: IFluentCallFunctionEntry[],
      ): IFluentCallFunctionEntry[] => {
        return [
          ...fluentDefaultCallFunctionEntries,
          ...fluentOtherCallFunctionEntries,
        ];
      },
    );

    /*--*/

    const getVariable$ = map$$(variables$, (variables: ITranslateVariables): IFluentGetVariableFunction => {
      return createFluentGetVariableFunction(Object.entries(variables));
    });

    const concat$ = function$$(
      [fluentNumberFormat$, fluentDateTimeFormat$],
      (fluentNumberFormat: IFluentNumberFormatFunction, fluentDateTimeFormat: IFluentDateTimeFormatFunction): IFluentConcatFunction => {
        return createFluentConcatFunction({
          fluentNumberFormat,
          fluentDateTimeFormat,
        });
      },
    );

    const select$ = map$$(
      fluentPluralRulesSelect$,
      (fluentPluralRulesSelect: IFluentPluralRulesSelectFunction): IFluentSelectFunction => {
        return createFluentSelectFunction({
          fluentPluralRulesSelect,
        });
      },
    );

    const callFunction$ = map$$(fluentCallFunctionEntries$, createFluentCallFunctionFunction);

    const options$ = function$$(
      [getVariable$, concat$, select$, callFunction$],
      (getVariable, concat, select, callFunction): IFluentMessageOptions => {
        return {
          getVariable,
          concat,
          select,
          callFunction,
        };
      },
    );

    return map$$(options$, fluentMessageFunction);
  };
}
