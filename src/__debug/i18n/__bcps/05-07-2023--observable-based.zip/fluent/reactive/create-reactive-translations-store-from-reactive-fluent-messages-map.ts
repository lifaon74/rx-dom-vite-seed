import { IObservable, map$$ } from '@lirx/core';
import { ReactiveTranslationsStore } from '../../intl/translate/reactive/reactive-translations-store.class';
import { IReadonlyFluentMessagesMap } from '../built-in/message/map/fluent-messages-map.type';
import {
  convertFluentMessagesMapToReactiveTranslationsStoreTranslations,
} from './convert-fluent-messages-map-to-reactive-translations-store-translations';

export function createReactiveTranslationsStoreFromReactiveFluentMessagesMap(
  fluentMessagesMap$: IObservable<IReadonlyFluentMessagesMap>,
): ReactiveTranslationsStore {
  return new ReactiveTranslationsStore(
    map$$(fluentMessagesMap$, convertFluentMessagesMapToReactiveTranslationsStoreTranslations),
  );
}
