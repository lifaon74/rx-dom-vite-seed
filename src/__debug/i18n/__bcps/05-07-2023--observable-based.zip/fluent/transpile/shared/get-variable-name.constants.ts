export const GET_VARIABLE_NAME = 'getVariable';
