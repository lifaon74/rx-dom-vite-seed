import {
  $log,
  combineLatest,
  computed,
  debounceMicrotask$$,
  IObservable,
  IObservableLike,
  ISignal,
  isMaybeObservable,
  isSignal,
  let$$,
  mapDistinct$$,
  signal,
  single,
  toObservableThrowIfUndefined,
  toSignal,
} from '@lirx/core';
import { IReactiveTranslateVariables } from '../../intl/translate/reactive/types/translate-function/reactive-translate-variables.type';
import { ISignalTranslateVariables } from '../../intl/translate/signal/types/translate-function/signal-translate-variables.type';
import { TranslationsStore } from '../../intl/translate/translations-store.class';
import { ITranslateFunctions } from '../../intl/translate/types/translate-function/translate-functions.type';
import { ITranslateVariables, ITranslateVariableType } from '../../intl/translate/types/translate-function/translate-variables.type';
import {
  ITranslationsStoreTranslationEntry,
  ITranslationsStoreTranslations,
} from '../../intl/translate/types/translations-store-translations.type';
import {
  convertListFormatFunctionToFluentListFormat,
} from '../built-in/call-function/built-in/list/convert-list-format-function-to-fluent-list-format';
import { createFluentMessageOptions } from '../built-in/message/create-fluent-message-options';
import {
  createReactiveTranslationsStoreFromReactiveFluentMessagesMap,
} from '../reactive/create-reactive-translations-store-from-reactive-fluent-messages-map';
import {
  createSignalTranslationsStoreFromSignalFluentMessagesMap,
} from '../signal/create-signal-translations-store-from-signal-fluent-messages-map';

import messages from './samples/01/sample-01.en';

/*----*/

// function debugFluentStore1(): void {
//   const store: TranslationsStore = new TranslationsStore([
//     ['abc', ({ name }) => `Hello ${name}`],
//   ]);
//
//   const str = store.translate('abc', {
//     name: 'Alice',
//   }, {
//     numberFormat: createNumberFormatFunction(),
//     dateTimeFormat: createDateTimeFormatFunction(),
//     abc: createDateTimeFormatFunction(),
//   });
//
//   console.log(str);
// }

function debugFluentStore2(): void {

  const translations: ITranslationsStoreTranslations = Array.from(messages.entries(), ([key, fluentMessageFunction]): ITranslationsStoreTranslationEntry => {
    return [
      key,
      (
        variables: ITranslateVariables,
        functions: ITranslateFunctions,
      ): string => {
        const {
          numberFormat,
          dateTimeFormat,
          listFormat,
          pluralRulesSelect,
          ..._functions
        } = functions;

        return fluentMessageFunction(
          createFluentMessageOptions({
            fluentNumberFormat: numberFormat,
            fluentDateTimeFormat: dateTimeFormat,
            fluentPluralRulesSelect: pluralRulesSelect,
            fluentListFormat: convertListFormatFunctionToFluentListFormat(listFormat),
            variables: Object.entries(variables),
            functions: Object.entries(_functions),
          }),
        );
      },
    ];
  });

  const store: TranslationsStore = new TranslationsStore(translations);

  const str = store.translate('shared-photos', {
    userName: 'Alice',
    photoCount: 5,
    userGender: 'female',
  });

  console.log(str);
}

export type ITranslateVariablesAsObjectOfObservableLikes = Record<string, IObservableLike<ITranslateVariableType>>;

export function convertObjectOfObservableLikesToReactiveTranslateVariables(
  variables: ITranslateVariablesAsObjectOfObservableLikes,
): IReactiveTranslateVariables {
  const entries: [string, IObservable<ITranslateVariableType>][] = Object.entries(variables)
    .map(([key, value]: [string, IObservableLike<ITranslateVariableType>]): [string, IObservable<ITranslateVariableType>] => {
      return [
        key.endsWith('$')
          ? key.slice(0, -1)
          : key,
        toObservableThrowIfUndefined(value),
      ];
      // if (key.endsWith('$')) {
      //   if (isMaybeObservable(value)) {
      //     return [key.slice(0, -1), value];
      //   } else if (isSignal(value)) {
      //     return [key.slice(0, -1), value.toObservable()];
      //   } else {
      //     throw new Error(`Key "${key}" is not an observable nor signal`);
      //   }
      // } else {
      //   if (isMaybeObservable(value) || isSignal(value)) {
      //     throw new Error(`Key "${key}" is an observable or signal but doesn't ends with $`);
      //   } else {
      //     return [key, single(value)];
      //   }
      // }
    });

  const observables: IObservable<ITranslateVariableType>[] = entries.map(_ => _[1]);

  return mapDistinct$$(
    debounceMicrotask$$(combineLatest(observables)),
    (values: readonly ITranslateVariableType[]): ITranslateVariables => {
      return Object.fromEntries(
        values.map((value: ITranslateVariableType, index: number): [string, ITranslateVariableType] => {
          return [entries[index][0], value];
        }),
      );
    },
  );
}

export function convertObjectOfObservableLikesToSignalTranslateVariables(
  variables: ITranslateVariablesAsObjectOfObservableLikes,
): ISignalTranslateVariables {
  const entries: [string, ISignal<ITranslateVariableType>][] = Object.entries(variables)
    .map(([key, value]: [string, IObservableLike<ITranslateVariableType>]): [string, ISignal<ITranslateVariableType>] => {
      return [
        key.endsWith('$')
          ? key.slice(0, -1)
          : key,
        isSignal(value)
          ? value
          : (
            isMaybeObservable(value)
              ? toSignal(value)
              : signal(value)
          ),
      ];
    });

  return computed(() => {
    return Object.fromEntries(
      entries.map(([key, value]: [string, ISignal<ITranslateVariableType>], index: number): [string, ITranslateVariableType] => {
        return [key, value()];
      }),
    );
  });
}

function debugFluentStore3(): void {
  const store = createReactiveTranslationsStoreFromReactiveFluentMessagesMap(single(messages));

  const [$userName, userName$] = let$$('Alice');
  const photoCount = signal(0);
  const userGender = signal('female');

  const variables$ = convertObjectOfObservableLikesToReactiveTranslateVariables({
    userName$,
    photoCount,
    userGender,
  });

  const str$ = store.translate$('shared-photos', variables$);

  str$($log);

  $userName('Bob');
  userGender.set('male');
}

function debugFluentStore4(): void {
  const store = createSignalTranslationsStoreFromSignalFluentMessagesMap(signal(messages));

  const userName = signal('Alice');
  const photoCount = signal(0);
  const userGender = signal('female');

  const variables$ = convertObjectOfObservableLikesToSignalTranslateVariables({
    userName,
    photoCount,
    userGender,
  });

  const translated = store.translate('shared-photos', variables$);

  // translated.toObservable()($log);

  console.log(translated());
  userName.set('Bob');
  console.log(translated());
  userGender.set('male');
  console.log(translated());
}

/*----*/

export function debugFluent3(): void {
  // debugFluentStore1();
  // debugFluentStore2();
  // debugFluentStore3();
  debugFluentStore4();
}


