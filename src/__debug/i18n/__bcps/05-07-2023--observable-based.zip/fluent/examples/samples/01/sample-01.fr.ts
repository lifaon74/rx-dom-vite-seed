import { compileFluentResource } from '../../../compile/compile-fluent-resource';

// @ts-ignore
import ftl from './sample-01.fr.ftl?raw';

export default compileFluentResource(ftl);
