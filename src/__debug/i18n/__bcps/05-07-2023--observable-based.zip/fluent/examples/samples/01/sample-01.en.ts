import { compileFluentResource } from '../../../compile/compile-fluent-resource';

// @ts-ignore
import ftl from './sample-01.en.ftl?raw';

export default compileFluentResource(ftl);
