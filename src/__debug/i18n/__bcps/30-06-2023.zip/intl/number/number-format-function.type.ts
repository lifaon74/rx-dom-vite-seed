export interface INumberFormatFunction {
  (
    value: number,
  ): string;
}
