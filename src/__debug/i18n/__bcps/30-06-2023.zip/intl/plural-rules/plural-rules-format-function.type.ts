export interface IPluralRulesFormatFunction {
  (
    value: number,
  ): Intl.LDMLPluralRule;
}
