export const RENDER_TERM_NAME = 'renderTerm';
