export const REGISTER_TERM_NAME = 'registerTerm';
