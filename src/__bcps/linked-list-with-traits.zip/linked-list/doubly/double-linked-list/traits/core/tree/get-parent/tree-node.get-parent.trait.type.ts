import { ITreeNodeGetParentFunction } from './tree-node.get-parent.function.type';

export interface ITreeNodeGetParentTrait<GNode> {
  getParent: ITreeNodeGetParentFunction<GNode>;
}

