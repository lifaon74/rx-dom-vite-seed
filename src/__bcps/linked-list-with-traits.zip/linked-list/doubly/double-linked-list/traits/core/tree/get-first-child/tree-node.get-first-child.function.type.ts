export interface ITreeNodeGetFirstChildFunction<GNode> {
  (): GNode | null;
}
