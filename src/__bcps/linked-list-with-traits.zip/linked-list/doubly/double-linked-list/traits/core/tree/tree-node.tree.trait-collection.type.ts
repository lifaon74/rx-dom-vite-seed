import { ITreeNodeGetFirstChildTrait } from './get-first-child/tree-node.get-first-child.trait.type';
import { ITreeNodeGetNextTrait } from './get-next/tree-node.get-next.trait.type';
import { ITreeNodeGetParentTrait } from './get-parent/tree-node.get-parent.trait.type';
import { ITreeNodeGetPreviousTrait } from './get-previous/tree-node.get-previous.trait.type';

export interface ITreeNodeTreeTraitCollection<GNode> extends //
  ITreeNodeGetFirstChildTrait<GNode>,
  ITreeNodeGetNextTrait<GNode>,
  ITreeNodeGetParentTrait<GNode>,
  ITreeNodeGetPreviousTrait<GNode>
//
{
}

