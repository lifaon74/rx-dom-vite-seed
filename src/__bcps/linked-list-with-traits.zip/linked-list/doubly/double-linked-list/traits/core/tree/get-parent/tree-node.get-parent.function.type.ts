export interface ITreeNodeGetParentFunction<GNode> {
  (): GNode | null;
}
