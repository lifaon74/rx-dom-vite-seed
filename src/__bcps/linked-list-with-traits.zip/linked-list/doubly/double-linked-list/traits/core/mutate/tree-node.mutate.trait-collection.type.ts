import { ITreeNodeAttachTrait } from './attach/tree-node.attach.trait.type';
import { ITreeNodeDetachTrait } from './detach/tree-node.detach.trait.type';

export interface ITreeNodeMutateTraitCollection<GNode> extends //
  ITreeNodeAttachTrait<GNode>,
  ITreeNodeDetachTrait
//
{
}

