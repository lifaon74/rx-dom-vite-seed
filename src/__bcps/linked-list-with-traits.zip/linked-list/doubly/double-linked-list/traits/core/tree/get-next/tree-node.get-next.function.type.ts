export interface ITreeNodeGetNextFunction<GNode> {
  (): GNode | null;
}
