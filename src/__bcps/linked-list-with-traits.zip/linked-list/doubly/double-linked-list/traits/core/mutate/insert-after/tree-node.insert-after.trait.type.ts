import { ITreeNodeAttachFunction } from './tree-node.insert-after.function.type';

export interface ITreeNodeAttachTrait<GNode> {
  attach: ITreeNodeAttachFunction<GNode>;
}

