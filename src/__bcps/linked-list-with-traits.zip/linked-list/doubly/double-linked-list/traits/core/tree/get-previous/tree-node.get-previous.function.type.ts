export interface ITreeNodeGetPreviousFunction<GNode> {
  (): GNode | null;
}
