import { ITreeNodeRemoveFunction } from './tree-node.remove.function.type';

export interface ITreeNodeRemoveTrait {
  remove: ITreeNodeRemoveFunction;
}

