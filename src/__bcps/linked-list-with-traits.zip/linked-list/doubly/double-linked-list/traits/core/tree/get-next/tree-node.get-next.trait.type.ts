import { ITreeNodeGetNextFunction } from './tree-node.get-next.function.type';

export interface ITreeNodeGetNextTrait<GNode> {
  getNext: ITreeNodeGetNextFunction<GNode>;
}

