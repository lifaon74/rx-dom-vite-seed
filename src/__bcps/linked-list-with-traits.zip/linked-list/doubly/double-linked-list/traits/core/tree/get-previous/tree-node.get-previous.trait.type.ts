import { ITreeNodeGetPreviousFunction } from './tree-node.get-previous.function.type';

export interface ITreeNodeGetPreviousTrait<GNode> {
  getPrevious: ITreeNodeGetPreviousFunction<GNode>;
}

