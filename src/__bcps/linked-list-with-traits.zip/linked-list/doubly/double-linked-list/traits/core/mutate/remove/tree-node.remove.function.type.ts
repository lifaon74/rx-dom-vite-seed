export interface ITreeNodeRemoveFunction {
  (): void;
}
