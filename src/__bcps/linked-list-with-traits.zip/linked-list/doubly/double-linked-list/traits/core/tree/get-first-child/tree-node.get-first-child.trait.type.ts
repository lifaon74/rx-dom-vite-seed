import { ITreeNodeGetFirstChildFunction } from './tree-node.get-first-child.function.type';

export interface ITreeNodeGetFirstChildTrait<GNode> {
  getFirstChild: ITreeNodeGetFirstChildFunction<GNode>;
}

