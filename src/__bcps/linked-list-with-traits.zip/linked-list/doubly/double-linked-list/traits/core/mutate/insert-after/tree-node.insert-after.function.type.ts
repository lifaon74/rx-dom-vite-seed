export interface ITreeNodeInsertAfterFunction<GNode> {
  (
    node: GNode,
  ): void;
}
