export interface IDoublyLinkedNodeGetPreviousFunction<GNode> {
  (): GNode | null;
}
