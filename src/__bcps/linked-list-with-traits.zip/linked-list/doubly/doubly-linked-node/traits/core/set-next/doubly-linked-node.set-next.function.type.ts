export interface IDoublyLinkedNodeSetNextFunction<GNode> {
  (
    node: GNode | null,
  ): void;
}
