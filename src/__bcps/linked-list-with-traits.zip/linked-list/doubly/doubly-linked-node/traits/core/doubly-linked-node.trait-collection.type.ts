import { IDoublyLinkedNodeGetFirstChildTrait } from './get-first-child/tree-node.get-first-child.trait.type';
import { IDoublyLinkedNodeGetNextTrait } from './get-next/doubly-linked-node.get-next.trait.type';
import { IDoublyLinkedNodeGetParentTrait } from './get-parent/tree-node.get-parent.trait.type';
import { IDoublyLinkedNodeGetPreviousTrait } from './get-previous/doubly-linked-node.get-previous.trait.type';

export interface IDoublyLinkedNodeTreeTraitCollection<GNode> extends //
  IDoublyLinkedNodeGetFirstChildTrait<GNode>,
  IDoublyLinkedNodeGetNextTrait<GNode>,
  IDoublyLinkedNodeGetParentTrait<GNode>,
  IDoublyLinkedNodeGetPreviousTrait<GNode>
//
{
}

