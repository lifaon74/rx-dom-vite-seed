import { IDoublyLinkedNodeGetNextFunction } from './doubly-linked-node.get-next.function.type';

export interface IDoublyLinkedNodeGetNextTrait<GNode> {
  getNext: IDoublyLinkedNodeGetNextFunction<GNode>;
}

