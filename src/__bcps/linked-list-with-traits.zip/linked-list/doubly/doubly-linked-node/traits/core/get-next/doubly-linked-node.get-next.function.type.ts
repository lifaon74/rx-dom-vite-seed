export interface IDoublyLinkedNodeGetNextFunction<GNode> {
  (): GNode | null;
}
