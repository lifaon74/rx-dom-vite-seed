import { IDoublyLinkedNodeSetNextFunction } from './doubly-linked-node.set-next.function.type';

export interface IDoublyLinkedNodeSetNextTrait<GNode> {
  setNext: IDoublyLinkedNodeSetNextFunction<GNode>;
}

