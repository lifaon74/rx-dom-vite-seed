import { IDoublyLinkedNodeGetPreviousFunction } from './doubly-linked-node.get-previous.function.type';

export interface IDoublyLinkedNodeGetPreviousTrait<GNode> {
  getPrevious: IDoublyLinkedNodeGetPreviousFunction<GNode>;
}

