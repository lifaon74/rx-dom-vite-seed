import { IDoublyLinkedNodeSetNextFunction } from './doubly-linked-node.set-previous.function.type';

export interface IDoublyLinkedNodeSetNextTrait<GNode> {
  setNext: IDoublyLinkedNodeSetNextFunction<GNode>;
}

