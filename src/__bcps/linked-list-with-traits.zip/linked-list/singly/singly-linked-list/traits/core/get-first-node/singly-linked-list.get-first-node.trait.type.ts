import {
  IGenericSinglyLinkedNodeCoreTraitCollection
} from '../../../../singly-linked-node/traits/core/singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedListGetFirstNodeFunction } from './singly-linked-list.get-first-node.function.type';

export interface ISinglyLinkedListGetFirstNodeTrait<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  getFirstNode: ISinglyLinkedListGetFirstNodeFunction<GNode>;
}

