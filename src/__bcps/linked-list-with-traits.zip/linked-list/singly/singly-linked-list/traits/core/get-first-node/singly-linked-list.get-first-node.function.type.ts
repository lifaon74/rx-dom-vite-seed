import {
  IGenericSinglyLinkedNodeCoreTraitCollection
} from '../../../../singly-linked-node/traits/core/singly-linked-node.core.trait-collection.generic.type';

export interface ISinglyLinkedListGetFirstNodeFunction<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  (): GNode | null;
}
