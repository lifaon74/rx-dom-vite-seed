import {
  IGenericSinglyLinkedNodeCoreTraitCollection
} from '../../../singly-linked-node/traits/core/singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedListGetFirstNodeTrait } from './get-first-node/singly-linked-list.get-first-node.trait.type';

export interface ISinglyLinkedListCoreTraitCollection<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> extends //
  ISinglyLinkedListGetFirstNodeTrait<GNode>
//
{
}

