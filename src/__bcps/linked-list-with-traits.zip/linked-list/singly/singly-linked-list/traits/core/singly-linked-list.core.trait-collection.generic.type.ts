import {
  IGenericSinglyLinkedNodeCoreTraitCollection,
} from '../../../singly-linked-node/traits/core/singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedListCoreTraitCollection } from './singly-linked-list.core.trait-collection.type';

export type IGenericSinglyLinkedListCoreTraitCollection = ISinglyLinkedListCoreTraitCollection<IGenericSinglyLinkedNodeCoreTraitCollection>;
