import { IGenericSinglyLinkedListNodeCoreTraitCollection } from './singly-linked-list-node.core.trait-collection.generic.type';

export interface ISinglyLinkedListNodeCoreTraitCollection<GNode extends IGenericSinglyLinkedListNodeCoreTraitCollection> extends //
  ISinglyLinkedListNodeGetNextTrait<GNode>,
  ISinglyLinkedListNodeSetNextTrait<GNode>
//
{
}

