import { ISinglyLinkedListNodeCoreTraitCollection } from './singly-linked-list-node.core.trait-collection.type';

export type IGenericSinglyLinkedListNodeCoreTraitCollection = ISinglyLinkedListNodeCoreTraitCollection<any>;

