import { IGenericSinglyLinkedListCoreTraitCollection } from '../../../traits/core/singly-linked-list.core.trait-collection.generic.type';
import { ISinglyLinkedListNodeGetListFunction } from './singly-linked-list-node.get-list.function.type';

export interface ISinglyLinkedListNodeGetListTrait<GList extends IGenericSinglyLinkedListCoreTraitCollection> {
  getList: ISinglyLinkedListNodeGetListFunction<GList>;
}

