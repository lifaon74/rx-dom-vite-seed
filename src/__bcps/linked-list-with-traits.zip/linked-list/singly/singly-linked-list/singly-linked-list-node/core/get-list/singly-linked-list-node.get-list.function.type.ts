import { IGenericSinglyLinkedListCoreTraitCollection } from '../../../traits/core/singly-linked-list.core.trait-collection.generic.type';

export interface ISinglyLinkedListNodeGetListFunction<GList extends IGenericSinglyLinkedListCoreTraitCollection> {
  (): GList;
}
