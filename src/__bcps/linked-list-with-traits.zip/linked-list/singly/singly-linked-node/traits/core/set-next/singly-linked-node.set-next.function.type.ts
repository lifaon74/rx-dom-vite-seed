import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../singly-linked-node.core.trait-collection.generic.type';

export interface ISinglyLinkedNodeSetNextFunction<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  (
    node: GNode | null,
  ): void;
}
