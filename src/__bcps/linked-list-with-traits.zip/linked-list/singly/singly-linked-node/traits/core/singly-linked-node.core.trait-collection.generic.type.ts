import { ISinglyLinkedNodeCoreTraitCollection } from './singly-linked-node.core.trait-collection.type';

export type IGenericSinglyLinkedNodeCoreTraitCollection = ISinglyLinkedNodeCoreTraitCollection<any>;

