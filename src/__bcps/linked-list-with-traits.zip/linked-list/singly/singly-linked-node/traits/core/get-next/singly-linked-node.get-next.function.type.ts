import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../singly-linked-node.core.trait-collection.generic.type';

export interface ISinglyLinkedNodeGetNextFunction<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  (): GNode | null;
}
