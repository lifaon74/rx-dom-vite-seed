import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedNodeSetNextFunction } from './singly-linked-node.set-next.function.type';

export interface ISinglyLinkedNodeSetNextTrait<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  setNext: ISinglyLinkedNodeSetNextFunction<GNode>;
}

