import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedNodeGetNextFunction } from './singly-linked-node.get-next.function.type';

export interface ISinglyLinkedNodeGetNextTrait<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  getNext: ISinglyLinkedNodeGetNextFunction<GNode>;
}

