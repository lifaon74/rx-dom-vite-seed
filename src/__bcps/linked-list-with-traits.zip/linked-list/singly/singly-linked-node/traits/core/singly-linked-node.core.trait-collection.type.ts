import { ISinglyLinkedNodeGetNextTrait } from './get-next/singly-linked-node.get-next.trait.type';
import { ISinglyLinkedNodeSetNextTrait } from './set-next/singly-linked-node.set-next.trait.type';
import { IGenericSinglyLinkedNodeCoreTraitCollection } from './singly-linked-node.core.trait-collection.generic.type';

export interface ISinglyLinkedNodeCoreTraitCollection<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> extends //
  ISinglyLinkedNodeGetNextTrait<GNode>,
  ISinglyLinkedNodeSetNextTrait<GNode>
//
{
}

