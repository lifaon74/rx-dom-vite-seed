import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../core/singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedNodeCoreTraitCollection } from '../core/singly-linked-node.core.trait-collection.type';
import {
  ISinglyLinkedNodeGetNextNodesIteratorTrait
} from './get-next-nodes-iterator/singly-linked-node.get-next-nodes-iterator.trait.type';

export interface ISinglyLinkedNodeExtendedMethodsOnlyTraitCollection<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> extends //
  ISinglyLinkedNodeGetNextNodesIteratorTrait<GNode>
//
{
}

export interface ISinglyLinkedNodeExtendedTraitCollection<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> extends //
  ISinglyLinkedNodeCoreTraitCollection<GNode>,
  ISinglyLinkedNodeExtendedMethodsOnlyTraitCollection<GNode>
//
{
}

