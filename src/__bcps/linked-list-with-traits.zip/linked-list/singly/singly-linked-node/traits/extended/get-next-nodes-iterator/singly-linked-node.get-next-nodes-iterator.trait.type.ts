import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../../core/singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedNodeGetNextNodesIteratorFunction } from './singly-linked-node.get-next-nodes-iterator.function.type';

export interface ISinglyLinkedNodeGetNextNodesIteratorTrait<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  getNextNodesIterator: ISinglyLinkedNodeGetNextNodesIteratorFunction<GNode>;
}

