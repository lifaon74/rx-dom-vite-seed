import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../../core/singly-linked-node.core.trait-collection.generic.type';

export interface ISinglyLinkedNodeGetNextNodesIteratorFunction<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> {
  (): Iterator<GNode>;
}
