import {
  ISinglyLinkedNodeExtendedMethodsOnlyTraitCollection,
  ISinglyLinkedNodeExtendedTraitCollection,
} from './singly-linked-node.extended.trait-collection.type';

export type IGenericSinglyLinkedNodeExtendedMethodsOnlyTraitCollection = ISinglyLinkedNodeExtendedMethodsOnlyTraitCollection<any>;

export type IGenericSinglyLinkedNodeExtendedTraitCollection = ISinglyLinkedNodeExtendedTraitCollection<any>;

