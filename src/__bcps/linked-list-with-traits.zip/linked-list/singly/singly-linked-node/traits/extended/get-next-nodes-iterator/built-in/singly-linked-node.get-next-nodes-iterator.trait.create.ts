import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../../../core/singly-linked-node.core.trait-collection.generic.type';
import {
  getSinglyLinkedNodeGetNextNodesIteratorUsingGetNext,
  IGetSinglyLinkedNodeGetNextNodesIteratorUsingGetNextOptions,
} from '../functions/get-singly-linked-node-get-next-nodes-iterator-using-get-next';
import { ISinglyLinkedNodeGetNextNodesIteratorTrait } from '../singly-linked-node.get-next-nodes-iterator.trait.type';

export function singlyLinkedNodeGetNextNodesIteratorTraitCreate<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection>(
  options: IGetSinglyLinkedNodeGetNextNodesIteratorUsingGetNextOptions<GNode>,
): ISinglyLinkedNodeGetNextNodesIteratorTrait<GNode> {
  return {
    getNextNodesIterator: (): Iterator<GNode> => {
      return getSinglyLinkedNodeGetNextNodesIteratorUsingGetNext<GNode>(options);
    },
  };
}

