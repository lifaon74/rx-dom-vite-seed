import { ISinglyLinkedNodeGetNextTrait } from '../../../core/get-next/singly-linked-node.get-next.trait.type';
import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../../../core/singly-linked-node.core.trait-collection.generic.type';

export interface IGetSinglyLinkedNodeGetNextNodesIteratorUsingGetNextOptions<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection> extends //
  ISinglyLinkedNodeGetNextTrait<GNode> {
}

export function* getSinglyLinkedNodeGetNextNodesIteratorUsingGetNext<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection>(
  {
    getNext,
  }: IGetSinglyLinkedNodeGetNextNodesIteratorUsingGetNextOptions<GNode>,
): Generator<GNode> {
  let node: GNode | null;
  while ((node = getNext()) !== null) {
    yield node;
  }
}
