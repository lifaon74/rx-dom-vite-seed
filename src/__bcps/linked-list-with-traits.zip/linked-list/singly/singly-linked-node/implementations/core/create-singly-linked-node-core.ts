import { IGenericSinglyLinkedNodeCoreTraitCollection } from '../../traits/core/singly-linked-node.core.trait-collection.generic.type';
import { ISinglyLinkedNodeCoreTraitCollection } from '../../traits/core/singly-linked-node.core.trait-collection.type';

export function createSinglyLinkedNodeCore<GNode extends IGenericSinglyLinkedNodeCoreTraitCollection>(): ISinglyLinkedNodeCoreTraitCollection<GNode> {
  let next: GNode | null = null;

  const getNext = (): GNode | null => {
    return next;
  };

  const setNext = (
    node: GNode | null,
  ): void => {
    next = node;
  };

  return {
    getNext,
    setNext,
  };
}
