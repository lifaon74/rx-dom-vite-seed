import {
  singlyLinkedNodeGetNextNodesIteratorTraitCreate,
} from '../../traits/extended/get-next-nodes-iterator/built-in/singly-linked-node.get-next-nodes-iterator.trait.create';
import {
  IGenericSinglyLinkedNodeExtendedTraitCollection,
} from '../../traits/extended/singly-linked-node.extended.trait-collection.generic.type';
import { ISinglyLinkedNodeExtendedTraitCollection } from '../../traits/extended/singly-linked-node.extended.trait-collection.type';
import { createSinglyLinkedNodeCore } from '../core/create-singly-linked-node-core';

export function createSinglyLinkedNodeExtended<GNode extends IGenericSinglyLinkedNodeExtendedTraitCollection>(): ISinglyLinkedNodeExtendedTraitCollection<GNode> {
  const node = createSinglyLinkedNodeCore<GNode>();
  const getNextNodesIteratorTrait = singlyLinkedNodeGetNextNodesIteratorTraitCreate<GNode>(node);

  return {
    ...node,
    ...getNextNodesIteratorTrait,
  };
}
