import { createCounter } from '../misc/create-counter';
import {
  IGenericGenericVirtualCustomElementNode
} from '../virtual-node/dom/nodes/reactive/custom-element/virtual-custom-element-node.class';
import { IComponentStyle } from './create/create-component';

const COMPONENT_STYLES_ID = createCounter();

export function compileStyleAsComponentStyle(
  style: string,
): IComponentStyle {
  const id: string = `style-${COMPONENT_STYLES_ID()}`;

  // TODO improve
  const _style: string = style.replace(/:host/g, `[${id}]`);

  const styleElement = document.createElement('style');
  styleElement.setAttribute('host', id);
  styleElement.textContent = _style;

  let count: number = 0;

  const connect = (): void => {
    count++;
    if (count === 1) {
      document.head.appendChild(styleElement);
    }
  };

  const disconnect = (): void => {
    count--;
    if (count === 0) {
      document.head.removeChild(styleElement);
    }
  };

  return (
    node: IGenericGenericVirtualCustomElementNode,
  ): void => {
    node.setAttribute(id, '');

    let fistConnected: boolean = true;
    node.isConnected$((connected: boolean): void => {
      if (connected) {
        connect();
      } else if (!fistConnected) {
        disconnect();
      }
      fistConnected = false;
    });
  };
}


