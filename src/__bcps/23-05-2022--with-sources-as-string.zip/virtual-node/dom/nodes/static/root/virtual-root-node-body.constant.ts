import { VirtualRootNode } from './virtual-root-node.class';

export const BODY_ROOT = new VirtualRootNode(document.body);
