import { IObservable } from '@lirx/core';
import { IVirtualReactiveDOMNodeTemplate } from '../../../types/virtual-reactive-dom-node-template.type';
import { VirtualContainerNode } from '../../static/container/virtual-container-node.class';
import { trackByIdentity } from './track-by/track-by-identity';

/** TYPES **/

export type IVirtualReactiveForLoopNodeTemplateArgument<GItem> = {
  item: GItem;
  index: IObservable<number>;
};

export type IVirtualReactiveForLoopNodeTemplate<GItem> = IVirtualReactiveDOMNodeTemplate<IVirtualReactiveForLoopNodeTemplateArgument<GItem>>;

export interface IVirtualReactiveForLoopNodeOptionsTrackByFunction<GItem> {
  (item: GItem): any;
}

/** CLASS **/

export class VirtualReactiveForLoopNode<GItem> extends VirtualContainerNode {
  constructor(
    items$: IObservable<Iterable<GItem>>,
    template: IVirtualReactiveForLoopNodeTemplate<GItem>,
    trackBy: IVirtualReactiveForLoopNodeOptionsTrackByFunction<GItem> = trackByIdentity,
  ) {
    super();

    this.onConnected$(items$)((items: Iterable<GItem>): void => {

    });
  }
}

