export type IClassNamesList = Set<string>; // NORMALIZED
