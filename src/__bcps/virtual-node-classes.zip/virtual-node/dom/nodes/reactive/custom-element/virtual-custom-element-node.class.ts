import { HTML_NAMESPACE_URI_CONSTANT } from '../../../../../misc/namespace-uri/html-namespace-uri.constant';
import { IVirtualDOMNodeTemplate } from '../../../types/virtual-dom-node-template.type';
import { VirtualReactiveElementNode } from '../element/virtual-reactive-element-node.class';

export type IVirtualCustomElementNodeSlotTemplate = IVirtualDOMNodeTemplate<[]>; // IGenericVirtualReactiveDOMNodeTemplate

export type IVirtualCustomElementNodeSlotsMap = ReadonlyMap<string | '*', IVirtualCustomElementNodeSlotTemplate>

export interface IVirtualCustomElementNodeOptions {
  name: string;
  parentName?: string;
  slots: IVirtualCustomElementNodeSlotsMap;
}

export class VirtualCustomElementNode<GElementNode extends HTMLElement> extends VirtualReactiveElementNode<GElementNode> {

  protected readonly _name: string;
  protected readonly _parentName: string | undefined;
  protected readonly _slots: IVirtualCustomElementNodeSlotsMap;

  constructor(
    {
      name,
      parentName,
      slots,
    }: IVirtualCustomElementNodeOptions,
  ) {
    super(
      HTML_NAMESPACE_URI_CONSTANT,
      (parentName === void 0)
        ? name
        : parentName,
    );
    this._name = name;
    this._parentName = parentName;
    this._slots = slots;

    if (parentName !== void 0) {
      this.setAttribute(name, '');
    }
  }

  get name(): string {
    return this._name;
  }

  get parentName(): string | undefined {
    return this._parentName;
  }

  get slots(): IVirtualCustomElementNodeSlotsMap {
    return this._slots;
  }
}


