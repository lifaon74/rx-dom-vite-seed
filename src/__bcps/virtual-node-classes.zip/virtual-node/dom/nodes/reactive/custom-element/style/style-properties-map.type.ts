import { ISetStyleProperty } from '../../../static/element/style/style-property.type';

export type IStylePropertiesMap = Map<string, ISetStyleProperty>;
