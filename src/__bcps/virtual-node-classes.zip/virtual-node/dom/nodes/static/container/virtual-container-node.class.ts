import { VirtualDOMNode } from '../../../virtual-dom-node.class';

export class VirtualContainerNode extends VirtualDOMNode {

  constructor() {
    super({
      isRoot: false,
      isLeaf: false,
    });
  }

  override getSelfDOMNodes(): readonly Node[] {
    return Array.from(this.getChildren() as Iterable<VirtualDOMNode>)
      .flatMap((child: VirtualDOMNode): readonly Node[] => {
        return child.getSelfDOMNodes();
      });
  }

  override getParentDOMNode(): Node | null {
    const parentNode: VirtualDOMNode | null = this.parentNode as VirtualDOMNode | null;
    return (parentNode === null)
      ? null
      : parentNode.getParentDOMNode();
  }

  override getReferenceDOMNode(): Node | null {
    const nextNode: VirtualDOMNode | null = this._nextNode as VirtualDOMNode | null;
    return (nextNode === null)
      ? null
      : nextNode.getParentDOMNode();
  }
}

