import { interval, IObservable, logState$$, map$$, merge, scan$$, single, timeout } from '@lirx/core';
import { HTML_NAMESPACE_URI_CONSTANT } from './misc/namespace-uri/html-namespace-uri.constant';
import {
  IVirtualCustomElementNodeOptions,
  IVirtualCustomElementNodeSlotsMap, IVirtualCustomElementNodeSlotTemplate,
  VirtualCustomElementNode,
} from './virtual-node/dom/nodes/reactive/custom-element/virtual-custom-element-node.class';
import { VirtualReactiveElementNode } from './virtual-node/dom/nodes/reactive/element/virtual-reactive-element-node.class';
import { VirtualReactiveIfNode } from './virtual-node/dom/nodes/reactive/if/virtual-reactive-if-node.class';
import { VirtualReactiveTextNode } from './virtual-node/dom/nodes/reactive/text/virtual-reactive-text-node.class';
import { VirtualContainerNode } from './virtual-node/dom/nodes/static/container/virtual-container-node.class';
import { VirtualTextNode } from './virtual-node/dom/nodes/static/text/virtual-text-node';
import { IVirtualDOMNodeTemplate } from './virtual-node/dom/types/virtual-dom-node-template.type';
import { IGenericVirtualReactiveDOMNodeTemplate } from './virtual-node/dom/types/virtual-reactive-dom-node-template.type';
import { VirtualDOMNode } from './virtual-node/dom/virtual-dom-node.class';
import { verifyVirtualNodeConsistency } from './virtual-node/functions/verify-virtual-node-consistency';
import { VirtualElementNode } from './virtual-node/dom/nodes/static/element/virtual-element-node.class';
import { VirtualRootNode } from './virtual-node/dom/nodes/static/root/virtual-root-node.class';

const ROOT = new VirtualRootNode(document.body);

function createTextObservable(
  name: string,
): IObservable<string> {
  return logState$$(map$$(interval(100), () => new Date().toISOString()), name);
}


function createConditionObservable(
  name: string,
): IObservable<boolean> {
  return logState$$(scan$$(interval(1000), (enabled: boolean) => !enabled, false), name);
  // return merge([false, map$$(timeout(1000), (enabled: boolean) => !enabled, false), name);
}

function createDummyTemplateFunction(
  name: string,
): IGenericVirtualReactiveDOMNodeTemplate {
  return (
    parentNode: VirtualDOMNode,
  ): void => {
    new VirtualTextNode(`template: ${name}`).attach(parentNode);
  };
}

/*-----------*/

function testReactiveTextNode(): void {
  const date$ = createTextObservable('date');
  const node = new VirtualReactiveTextNode(date$);

  node.attach(ROOT);

  setTimeout(() => node.detach(), 2000);
}

function testReactiveAttribute(): void {
  const date$ = createTextObservable('date');
  const node = VirtualReactiveElementNode.createHTML('div');
  node.setReactiveAttribute('attr', date$);

  node.attach(ROOT);

  setTimeout(() => node.detach(), 2000);
}


function testReactiveClass(): void {
  const enabled$ = createConditionObservable('enabled');
  const node = VirtualReactiveElementNode.createHTML('div');
  node.setReactiveClass('my-class', enabled$);

  node.attach(ROOT);

  // setTimeout(() => node.detach(), 2000);
}



function testReactiveIfNode(): void {
  // const enabled$ = createConditionObservable('enabled');
  // const enabled$ = single(true);

  const buttonNode = VirtualReactiveElementNode.createHTML('button');
  new VirtualTextNode('toggle').attach(buttonNode);
  buttonNode.attach(ROOT);

  const click$ = buttonNode.on$<MouseEvent>('click');
  const enabled$ = logState$$(merge([single(false), scan$$(click$, (enabled: boolean) => !enabled, false)]), 'enabled');

  const conditionalNode = new VirtualReactiveIfNode(
    enabled$,
    createDummyTemplateFunction('true'),
    createDummyTemplateFunction('false'),
  );
  conditionalNode.attach(ROOT);


  verifyVirtualNodeConsistency(ROOT);

  setTimeout(() => conditionalNode.detach(), 2000);
}


function testCustomElementNode(): void {

  // function createCustomElement(): VirtualCustomElementNode {
  //
  // }


  // class MatButtonComponent extends HTMLButtonElement {}
  //
  // customElements.define('mat-button', MatButtonComponent, { extends: 'button' });

  class MatButton extends VirtualCustomElementNode<HTMLButtonElement> {
    constructor(
      slots: IVirtualCustomElementNodeSlotsMap,
    ) {
      super({
        name: 'mat-button',
        parentName: 'button',
        slots,
      });

      slots.get('*')!(this);
    }
  }

  type GArguments = [
    $: any,
  ];

  const template: IVirtualDOMNodeTemplate<GArguments> = (
    parentNode: VirtualDOMNode,
    $: object,
  ): void => {
    const buttonTemplate: IVirtualCustomElementNodeSlotTemplate = (
      parentNode: VirtualDOMNode,
    ): void => {
      const node = new VirtualTextNode('toggle');
      node.attach(parentNode);
    };

    const node = new MatButton(new Map([['*', buttonTemplate]]));
    node.attach(parentNode);
  };

  template(ROOT, {});
}

/*-----------------*/

export type IComponentCreateFunctionReturn<GElement extends HTMLElement> =
  | VirtualCustomElementNode<GElement>
  | Promise<VirtualCustomElementNode<GElement>>
;

export interface IComponentCreateFunction<GElement extends HTMLElement> {
  (
    slots: IVirtualCustomElementNodeSlotsMap,
  ): IComponentCreateFunctionReturn<GElement>;
}

export type IComponent<GElement extends HTMLElement> = [
  name: string,
  create: IComponentCreateFunction<GElement>,
];

export type IGenericComponent = IComponent<HTMLElement>;


// export interface ICreateComponentOptionsInitFunctionReturn<GData> {
//   $: GData;
//   inputs: GData;
// }

export interface ICreateComponentOptionsInitFunction<GData> {
  (
    inputs: any[],
    slots: IVirtualCustomElementNodeSlotsMap,
  ): GData;
}

export interface ICreateComponentOptions<GData> extends Pick<IVirtualCustomElementNodeOptions, 'name' | 'parentName'> {
  // html: string;
  // childComponents: readonly IGenericComponent[];
  // styles: string[];
  inputs: readonly string[];
  init: ICreateComponentOptionsInitFunction<GData>;
  template?: IVirtualDOMNodeTemplate<[$: GData]>;
  styles?: readonly string[];
}

export function createComponent<GData, GElement extends HTMLElement>(
  {
    name,
    parentName,
    init,
    template,
    styles = [],
  }: ICreateComponentOptions<GData>,
): IComponent<GElement> {

  const create: IComponentCreateFunction<GElement> = (
    slots: IVirtualCustomElementNodeSlotsMap,
  ): IComponentCreateFunctionReturn<GElement> => {
    const node = new VirtualCustomElementNode<GElement>({
      name,
      parentName,
      slots,
    });

    const $: GData = init([], slots);

    if (template !== void 0) {
      template(node, $);
    }

    // styles.forEach((style: string) => {
    //   document.body.cre
    // });
    // slots.get('*')!(this);

    return node;
  };

  return [
    name,
    create,
  ];
}


// function testCustomElementNode2(): void {
//
//   // function createCustomElement(): VirtualCustomElementNode {
//   //
//   // }
//
//
//   // class MatButtonComponent extends HTMLButtonElement {}
//   //
//   // customElements.define('mat-button', MatButtonComponent, { extends: 'button' });
//
//   class MatButton extends VirtualCustomElementNode<HTMLButtonElement> {
//     constructor(
//       scopesMap: IVirtualCustomElementNodeSlotsMap,
//     ) {
//       super(
//         'button',
//         scopesMap,
//       );
//
//       this.setAttribute('mat-button', '');
//
//       scopesMap.get('*')!(this);
//     }
//   }
//
//   type GArguments = [
//     $: any,
//   ];
//
//   const template: IVirtualDOMNodeTemplate<GArguments> = (
//     parentNode: VirtualDOMNode,
//     $: object,
//   ): void => {
//     const buttonTemplate: IVirtualCustomElementNodeSlotTemplate = (
//       parentNode: VirtualDOMNode,
//     ): void => {
//       const node = new VirtualTextNode('toggle');
//       node.attach(parentNode);
//     };
//
//     const node = new MatButton(new Map([['*', buttonTemplate]]));
//     node.attach(parentNode);
//   };
//
//   template(ROOT, {});
// }

/*-----------*/

function debugVirtualNode(): void {
  const container = VirtualReactiveElementNode.createHTML('div');

  const date$ = logState$$(map$$(interval(1000), () => new Date().toISOString()), 'date');
  // const n3 = new VirtualTextNode('hello world !');
  const reactiveTextNode = new VirtualReactiveTextNode(date$);

  reactiveTextNode.attach(container);

  container.attach(ROOT);

  setTimeout(() => container.detach(), 2000);
}


function main(): void {
  // debugVirtualNode();
  // testReactiveAttribute();
  // testReactiveClass();
  // testReactiveTextNode();
  // testReactiveIfNode();
  testCustomElementNode();

}

window.onload = main;

